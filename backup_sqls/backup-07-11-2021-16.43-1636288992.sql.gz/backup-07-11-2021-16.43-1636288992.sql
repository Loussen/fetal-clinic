-- ---------------------------------------------------------
--
-- SIMPLE SQL Dump
--
-- nawa (at) yahoo (dot) com
--
-- Host Connection Info: localhost via TCP/IP
-- Generation Time: November 07, 2021 at 16:43 PM ( Asia/Baku )
-- Server version: 100413
-- PHP Version: 7.4.8
--
-- ---------------------------------------------------------



SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;


-- ---------------------------------------------------------
--
-- Table structure for table : `about`
--
-- ---------------------------------------------------------

CREATE TABLE `about` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name_en` varchar(255) NOT NULL,
  `name_ru` varchar(255) NOT NULL,
  `name_az` varchar(255) NOT NULL,
  `short_text_en` text NOT NULL,
  `short_text_ru` text NOT NULL,
  `short_text_az` text NOT NULL,
  `full_text_en` text NOT NULL,
  `full_text_ru` text NOT NULL,
  `full_text_az` text NOT NULL,
  `image` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `about`
--

INSERT INTO `about` (`id`, `name_en`, `name_ru`, `name_az`, `short_text_en`, `short_text_ru`, `short_text_az`, `full_text_en`, `full_text_ru`, `full_text_az`, `image`) VALUES
(1, '', 'Альголог Вусал Эйвазов, врач который лечит боль', 'Onkoloq-ginekoloq Könül Mərdanova', '', 'Кандидат медицинских наук, врач-альголог – болевой терпевт, доктор Вусал Эйвазов окончил Азербайджанский медицинский университет в 2000 году. С 2000 по 2005 годы прошел учебу в ординатуре и аспирантуре в Российской Федерации в городе Санкт-Петербург, и получил звание кандидата медицинских наук. Вернувшись в 2005 году в Азербайджан, начал работать анестезиологом в Центральной Больнице Нефтяников. С 2011 года он работает заведующим отделением анестезиологии и реанимации в «Baku Medical Plaza». Доктор медицинских наук Вусал Эйвазов получил специализацию по альгологии в Эгейском Медицинском Университете в городе Измир в Турции и получил звание врача альголога, который лечит боли. Он является участником многих научных конференций и курсов по альгологии. Доктор Вусал в 2017 году впервые в Азербайджане создал Центр лечения боли.', 'Onkoginekoloq Könül Mərdanova 2006 ci ildə Azərbaycan Tibb Unuversitetinin Müalicə işi fakultəsini fərqlənmə ilə bitirib. 2007 cildə Milli Onkologiya Mərkəzində Onkologiya ixtisasi üzrə internatura kursu keçib. 2009- cu ilin sentyabr ayından bu günə kimi Milli Onkologiya Mərkəzinin Şişönü xəstəliklərin diaqnostikası və müalicəsi şöbəsində həkim onkoginekoloq vəzifəsində çalışır. Bir çox elmi məqalələrin və “Vulvovaginal kandidozların mikrobioloji diaqnostikası” adlı metodik vəsaitin müəllifidir. 2020 ci ildə Azəbaycan səhiyyəsi üçün bir ilk olaraq elmi məqaləsi Akad. C. Əliyevin rəhbərliyi ilə Amerikada NCCN də dərc olunub.\n\nQatıldığı konfranslar və kurslar\n•	2009 cu il Türkiyə Ankara Hacettepe universitesi Kolposkopiya və histeroskopiya üzrə təkmilləşdirmə kursu\n•	2010 Türkiyə Antalya Kök hücrə konfransı', '', '<p style="text-align: justify;">Кандидат медицинских наук, врач-альголог &ndash; болевой терпевт, доктор Вусал Эйвазов окончил Азербайджанский медицинский университет в 2000 году. С 2000 по 2005 годы прошел учебу в ординатуре и аспирантуре в Российской Федерации в городе Санкт-Петербург, и получил звание кандидата медицинских наук. Вернувшись в 2005 году в Азербайджан, начал работать анестезиологом в Центральной Больнице Нефтяников. С 2011 года он работает заведующим отделением анестезиологии и реанимации в &laquo;Baku Medical Plaza&raquo;. Доктор медицинских наук Вусал Эйвазов получил специализацию по альгологии в Эгейском Медицинском Университете в городе Измир в Турции и получил звание врача альголога, который лечит боли. Он является участником многих научных конференций и курсов по альгологии. Доктор Вусал в 2017 году впервые в Азербайджане создал Центр лечения боли.</p>', '<p><span style="font-size: 18px;">Onkoginekoloq Könül Mərdanova 2006 ci ildə Azərbaycan Tibb Unuversitetinin Müalicə işi fakultəsini fərqlənmə ilə bitirib. 2007 cildə Milli Onkologiya Mərkəzində Onkologiya ixtisasi üzrə internatura kursu keçib. 2009- cu ilin sentyabr ayından bu günə kimi Milli Onkologiya Mərkəzinin Şişönü xəstəliklərin diaqnostikası və müalicəsi şöbəsində həkim onkoginekoloq vəzifəsində çalışır. Bir çox elmi məqalələrin və &ldquo;Vulvovaginal kandidozların mikrobioloji diaqnostikası&rdquo; adlı metodik vəsaitin müəllifidir. 2020 ci ildə Azəbaycan səhiyyəsi üçün bir ilk olaraq elmi məqaləsi Akad. C. Əliyevin rəhbərliyi ilə Amerikada NCCN də dərc olunub.</span></p>\n<p><span style="font-size: 18px;">Qatıldığı konfranslar və kurslar</span><br /><span style="font-size: 18px;">&bull; 2009 cu il Türkiyə Ankara Hacettepe universitesi Kolposkopiya və histeroskopiya üzrə təkmilləşdirmə kursu</span><br /><span style="font-size: 18px;">&bull; 2010 Türkiyə Antalya Kök hücrə konfransı</span></p>\n<p><span style="font-size: 18px;">Müalicə etdiyi qadın xəstəlikləri</span></p>\n<ul>\n<li><span style="font-size: 18px;">Uşaqlığın mioması</span></li>\n<li><span style="font-size: 18px;">Uşaqlığın adiomiozu</span></li>\n<li><span style="font-size: 18px;">Endometrionun polipi</span></li>\n<li><span style="font-size: 18px;">Yumurtalıq kistası</span></li>\n<li><span style="font-size: 18px;">Uşaqlıq boynunun polipi</span></li>\n<li><span style="font-size: 18px;">Uşaqlıq boynunun eroziyasi</span></li>\n<li><span style="font-size: 18px;">Uşaqlıq boynunun endometriosu</span></li>\n<li><span style="font-size: 18px;">Uşaqlıq boynunun kistləri</span></li>\n<li><span style="font-size: 18px;">Uşaqlıq yolunun kistləri</span></li>\n<li><span style="font-size: 18px;">Bartolin vəzinin kistləri</span></li>\n<li><span style="font-size: 18px;">Xarici tənasül orqanlarının popilomalari,kandilomaları, kistaları,</span></li>\n<li><span style="font-size: 18px;">Uşaqlıq boynunun xərçəngi</span></li>\n<li><span style="font-size: 18px;">Yumurtalıq xərçəngi</span></li>\n<li><span style="font-size: 18px;">Vulva xərcəngi</span></li>\n<li><span style="font-size: 18px;">Bütün ginekoloji xəstəliklər</span></li>\n</ul>\n<div>&nbsp;</div>\n<div><span style="font-size: 18px;">Müalicə metodları</span></div>\n<div>\n<ul>\n<li><span style="font-size: 18px;">Kolposkopiya</span></li>\n<li><span style="font-size: 18px;">Histeroskopiya</span></li>\n<li><span style="font-size: 18px;">Pap Smear</span></li>\n<li><span style="font-size: 18px;">Uşaqlıqda aparılan hər növ cərrahi əməliyyatlar (histerektomiya, kistektomiya, miomektomiya)</span></li>\n<li><span style="font-size: 18px;">Vaginoplastika</span></li>\n<li><span style="font-size: 18px;">Bartolin vəzi kistalarının ləğvi</span></li>\n<li><span style="font-size: 18px;">Uşaqlıq boynu eroziyalarının diaqnostikası və müvafiq müalicə</span></li>\n<li><span style="font-size: 18px;">Vulva, kondiloma və papillomaların lazer ilə tam ağrısız şəraitdə destruksiyası</span></li>\n<li><span style="font-size: 18px;">Uşaqlıq boynu poliplərinin lazer üsulu ilə ləğvi</span></li>\n<li><span style="font-size: 18px;">Endometrial biopsiyalar</span></li>\n<li><span style="font-size: 18px;">Laparoskopik əməliyyatlar</span></li>\n</ul>\n</div>', 'haqqinda-1634211897.jpg');



-- ---------------------------------------------------------
--
-- Table structure for table : `admin_roles`
--
-- ---------------------------------------------------------

CREATE TABLE `admin_roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `permissions` text NOT NULL,
  `position` int(11) NOT NULL,
  `active` tinyint(1) NOT NULL,
  `important` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `admin_roles`
--

INSERT INTO `admin_roles` (`id`, `name`, `permissions`, `position`, `active`, `important`) VALUES
(1, 'Baş admin', '{"index":{"see":1,"add":0,"edit":0,"delete":0,"position":0,"active":0},"admins":{"see":1,"add":1,"edit":1,"delete":1,"position":0,"active":0},"settings_inner":{"see":1,"add":1,"edit":1,"delete":1,"position":0,"active":0},"logout":{"see":1,"add":0,"edit":0,"delete":0,"position":0,"active":0},"home_page":{"see":1,"add":0,"edit":1,"delete":0,"position":0,"active":0},"streets":{"see":1,"add":1,"edit":1,"delete":1,"position":1,"active":1},"buildings":{"see":1,"add":1,"edit":1,"delete":1,"position":1,"active":1},"managers":{"see":1,"add":1,"edit":1,"delete":1,"position":1,"active":1},"contractors":{"see":1,"add":1,"edit":1,"delete":1,"position":1,"active":1},"banks":{"see":1,"add":1,"edit":1,"delete":1,"position":1,"active":1},"repair_types":{"see":1,"add":1,"edit":1,"delete":1,"position":1,"active":1},"licenses":{"see":1,"add":1,"edit":1,"delete":1,"position":1,"active":1},"sale_types":{"see":1,"add":1,"edit":1,"delete":1,"position":1,"active":1},"sales":{"see":1,"add":1,"edit":1,"delete":1,"position":0,"active":0},"list":{"see":1,"add":0,"edit":0,"delete":0,"position":0,"active":0},"payments":{"see":1,"add":1,"edit":0,"delete":1,"position":0,"active":0},"penals":{"see":1,"add":0,"edit":1,"delete":0,"position":0,"active":0},"cash_desks":{"see":1,"add":1,"edit":1,"delete":1,"position":1,"active":1},"admin_roles":{"see":1,"add":1,"edit":1,"delete":1,"position":1,"active":1}}', 1, 1, 1);



-- ---------------------------------------------------------
--
-- Table structure for table : `admins`
--
-- ---------------------------------------------------------

CREATE TABLE `admins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `login` varchar(50) NOT NULL,
  `pass` varchar(50) NOT NULL,
  `salt` varchar(50) NOT NULL,
  `important` tinyint(1) NOT NULL,
  `role_id` int(11) NOT NULL,
  `permissions` text NOT NULL,
  `active` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `login`, `pass`, `salt`, `important`, `role_id`, `permissions`, `active`) VALUES
(1, 'admin', '527ea2cdfa97dbaab0ea8be158d33873', 'C@oLQjxo/*mp', 0, 1, '{"index":{"see":1,"add":0,"edit":0,"delete":0,"position":0,"active":0},"admins":{"see":1,"add":1,"edit":1,"delete":1,"position":0,"active":0},"settings_inner":{"see":1,"add":1,"edit":1,"delete":1,"position":0,"active":0},"logout":{"see":1,"add":0,"edit":0,"delete":0,"position":0,"active":0},"home_page":{"see":1,"add":0,"edit":1,"delete":0,"position":0,"active":0},"streets":{"see":1,"add":1,"edit":1,"delete":1,"position":1,"active":1},"buildings":{"see":1,"add":1,"edit":1,"delete":1,"position":1,"active":1},"managers":{"see":1,"add":1,"edit":1,"delete":1,"position":1,"active":1},"contractors":{"see":1,"add":1,"edit":1,"delete":1,"position":1,"active":1},"banks":{"see":1,"add":1,"edit":1,"delete":1,"position":1,"active":1},"repair_types":{"see":1,"add":1,"edit":1,"delete":1,"position":1,"active":1},"licenses":{"see":1,"add":1,"edit":1,"delete":1,"position":1,"active":1},"sale_types":{"see":1,"add":1,"edit":1,"delete":1,"position":1,"active":1},"sales":{"see":1,"add":1,"edit":1,"delete":1,"position":0,"active":0},"list":{"see":1,"add":0,"edit":0,"delete":0,"position":0,"active":0},"payments":{"see":1,"add":1,"edit":0,"delete":1,"position":0,"active":0},"penals":{"see":1,"add":0,"edit":1,"delete":0,"position":0,"active":0},"cash_desks":{"see":1,"add":1,"edit":1,"delete":1,"position":1,"active":1},"admin_roles":{"see":1,"add":1,"edit":1,"delete":1,"position":1,"active":1}}', 1);



-- ---------------------------------------------------------
--
-- Table structure for table : `appointment`
--
-- ---------------------------------------------------------

CREATE TABLE `appointment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name_en` varchar(255) NOT NULL,
  `name_ru` varchar(255) NOT NULL,
  `name_az` varchar(255) NOT NULL,
  `full_text_en` text NOT NULL,
  `full_text_ru` text NOT NULL,
  `full_text_az` text NOT NULL,
  `image` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `appointment`
--

INSERT INTO `appointment` (`id`, `name_en`, `name_ru`, `name_az`, `full_text_en`, `full_text_ru`, `full_text_az`, `image`) VALUES
(1, '', 'Müayinəyə yazılın1', 'Müayinəyə yazıl', '', '', '<h2>Müayinəyə yazılmaq üçün zəhmət olmasa aşağıdakı formu doldurun.</h2>', 'konulhekimginekoloq-1621184903.jpg');



-- ---------------------------------------------------------
--
-- Table structure for table : `appointment_users`
--
-- ---------------------------------------------------------

CREATE TABLE `appointment_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `surname` varchar(50) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `message` text NOT NULL,
  `datetime` timestamp NOT NULL DEFAULT current_timestamp(),
  `seen_by_admin` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=140 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `appointment_users`
--

INSERT INTO `appointment_users` (`id`, `name`, `surname`, `phone`, `message`, `datetime`, `seen_by_admin`) VALUES
(138, 'Sevinc', 'Həsənzadə', 0703245092, 'Salam doktor mən ay yarımdır şüa terapiyası almışam yoxlamaya nə vaxt gele bilerem xaiş edirəm deyerdiz', '2021-09-15 22:50:06', 1),
(136, 'Həyat', 'Qazıyrva', '050 328 11 45', 'Könül xanımın iş vaxtlarını bilmək istəyirik', '2021-09-07 14:02:30', 1),
(137, 'Sevinc', 'Həsənzadə', 0703245092, 'Salam doktor mən ay yarımdır şüa terapiyası almışam yoxlamaya nə vaxt gele bilerem xaiş edirəm deyerdiz', '2021-09-15 22:37:01', 1),
(139, 'Fuad', 'Hasanli', +994506877836, 'SAlam salam', '2021-10-19 22:42:05', 0);



-- ---------------------------------------------------------
--
-- Table structure for table : `authors`
--
-- ---------------------------------------------------------

CREATE TABLE `authors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name_en` varchar(50) DEFAULT NULL,
  `name_ru` varchar(50) DEFAULT NULL,
  `name_az` varchar(255) NOT NULL,
  `text_en` text NOT NULL,
  `text_ru` text NOT NULL,
  `text_az` text NOT NULL,
  `image` varchar(100) NOT NULL,
  `last_post_time` int(11) NOT NULL,
  `active` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `authors`
--

INSERT INTO `authors` (`id`, `name_en`, `name_ru`, `name_az`, `text_en`, `text_ru`, `text_az`, `image`, `last_post_time`, `active`) VALUES
(8, '', '', '', '', '', '', '4914038-image-1511074689.jpg', 0, 1);



-- ---------------------------------------------------------
--
-- Table structure for table : `banks`
--
-- ---------------------------------------------------------

CREATE TABLE `banks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `percent` int(11) NOT NULL,
  `period` tinyint(1) NOT NULL COMMENT '0=>yearly,1=>montly,2=>daily',
  `position` int(11) NOT NULL,
  `active` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;



-- ---------------------------------------------------------
--
-- Table structure for table : `banners`
--
-- ---------------------------------------------------------

CREATE TABLE `banners` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name_en` varchar(255) NOT NULL,
  `name_ru` varchar(255) NOT NULL,
  `name_az` varchar(255) NOT NULL,
  `text_en` text NOT NULL,
  `text_ru` text NOT NULL,
  `text_az` text NOT NULL,
  `position` int(11) NOT NULL,
  `active` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `banners`
--

INSERT INTO `banners` (`id`, `name_en`, `name_ru`, `name_az`, `text_en`, `text_ru`, `text_az`, `position`, `active`) VALUES
(1, '', '', '', '', '', '', 1, 1);



-- ---------------------------------------------------------
--
-- Table structure for table : `cash_desks`
--
-- ---------------------------------------------------------

CREATE TABLE `cash_desks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `program_id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `payment_type` tinyint(1) NOT NULL COMMENT '0=>income,1=>out,2=>both',
  `important` tinyint(1) NOT NULL,
  `position` int(11) NOT NULL,
  `active` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;



-- ---------------------------------------------------------
--
-- Table structure for table : `categories`
--
-- ---------------------------------------------------------

CREATE TABLE `categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name_en` varchar(255) NOT NULL,
  `name_ru` varchar(255) NOT NULL,
  `name_az` varchar(255) NOT NULL,
  `text_en` text NOT NULL,
  `text_ru` text NOT NULL,
  `text_az` text NOT NULL,
  `position` int(11) NOT NULL,
  `active` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name_en`, `name_ru`, `name_az`, `text_en`, `text_ru`, `text_az`, `position`, `active`) VALUES
(3, 'Musculoskeletal System', 'Мышечная Система', '', '', '', '', 1, 1),
(4, 'Digestive System', 'Пищеварительная Система', '', '', '', '', 2, 1),
(5, 'Vitamin-Mineral Supplements', 'Витаминно-минеральные добавки', '', '', '', '', 3, 1),
(6, 'Respiratory System', 'Дыхательная Cистема', '', '', '', '', 4, 1),
(7, 'Immune System', 'Иммунная Cистема', '', '', '', '', 5, 1),
(8, 'Antioxidants', 'Антиоксиданты', '', '', '', '', 6, 1),
(9, 'Nervous System', 'Нервная Система', '', '', '', '', 7, 1),
(10, 'For Kids', 'Для Детей', '', '', '', '', 8, 1),
(11, 'Cosmetics & Dermocosmetics', 'Косметика и Дермокосметика', '', '', '', '', 9, 1),
(12, '', '', '', '', '', '', 10, 0),
(13, 'Eye Health', 'Здоровье Глаз', '', '', '', '', 11, 1),
(14, 'Sexual Health', 'Сексуальное Здоровье', '', '', '', '', 12, 1),
(15, 'Disinfectant & Antiseptic Products', 'Дезинфицирующие и Антисептические Средства', '', '', '', '', 13, 1),
(16, 'Medical Products', 'Изделия Медицинского Назначения', '', '', '', '', 14, 1),
(17, 'Special Products', 'Специальные Продукты', '', '', '', '', 15, 1),
(19, 'Urological products', 'Урологические продукты', '', '', '', '', 16, 1);



-- ---------------------------------------------------------
--
-- Table structure for table : `categories2`
--
-- ---------------------------------------------------------

CREATE TABLE `categories2` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name_en` varchar(255) NOT NULL,
  `name_ru` varchar(255) NOT NULL,
  `name_az` varchar(255) NOT NULL,
  `text_en` text NOT NULL,
  `text_ru` text NOT NULL,
  `text_az` text NOT NULL,
  `position` int(11) NOT NULL,
  `active` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;



-- ---------------------------------------------------------
--
-- Table structure for table : `comments`
--
-- ---------------------------------------------------------

CREATE TABLE `comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `information_id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `comment` text NOT NULL,
  `active` tinyint(1) NOT NULL,
  `datetime` int(11) NOT NULL,
  `table_name` varchar(255) NOT NULL,
  `seen_by_admin` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`id`, `information_id`, `name`, `comment`, `active`, `datetime`, `table_name`, `seen_by_admin`) VALUES
(2, 0, 'er', 'test', 1, 0, 'qweqwr', 0);



-- ---------------------------------------------------------
--
-- Table structure for table : `company_info`
--
-- ---------------------------------------------------------

CREATE TABLE `company_info` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `currency_id` tinyint(2) NOT NULL,
  `image_logo` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Proqramin satisi';



-- ---------------------------------------------------------
--
-- Table structure for table : `contacts`
--
-- ---------------------------------------------------------

CREATE TABLE `contacts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `text_en` text NOT NULL,
  `text_ru` text NOT NULL,
  `text_az` text NOT NULL,
  `footer_en` text NOT NULL,
  `footer_ru` text NOT NULL,
  `footer_az` text NOT NULL,
  `email` varchar(255) NOT NULL,
  `facebook` varchar(255) NOT NULL,
  `twitter` varchar(255) NOT NULL,
  `vkontakte` varchar(255) NOT NULL,
  `linkedin` varchar(255) NOT NULL,
  `digg` varchar(255) NOT NULL,
  `flickr` varchar(255) NOT NULL,
  `dribbble` varchar(255) NOT NULL,
  `vimeo` varchar(255) NOT NULL,
  `myspace` varchar(255) NOT NULL,
  `google` varchar(255) NOT NULL,
  `youtube` varchar(255) NOT NULL,
  `instagram` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `mobile` varchar(255) NOT NULL,
  `skype` varchar(255) NOT NULL,
  `fax` varchar(255) NOT NULL,
  `google_map` text NOT NULL,
  `opening_hours_az` varchar(255) NOT NULL,
  `opening_hours_en` varchar(255) NOT NULL,
  `opening_hours_ru` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `contacts`
--

INSERT INTO `contacts` (`id`, `text_en`, `text_ru`, `text_az`, `footer_en`, `footer_ru`, `footer_az`, `email`, `facebook`, `twitter`, `vkontakte`, `linkedin`, `digg`, `flickr`, `dribbble`, `vimeo`, `myspace`, `google`, `youtube`, `instagram`, `phone`, `mobile`, `skype`, `fax`, `google_map`, `opening_hours_az`, `opening_hours_en`, `opening_hours_ru`) VALUES
(1, '', 'Баку Медикал Плаза\nAZ1142, Проспект Бабека 92Н Хатаинский р-н', 'Bakı ş. H. Zərdabi küçəsi, 79B', '', '', 'Onkoginekoloq Könül Mərdanova 2006 ci ildə Azərbaycan Tibb Unuversitetinin Müalicə işi fakultəsini fərqlənmə ilə bitirib. 2007 cildə Milli Onkologiya Mərkəzində Onkologiya ixtisasi üzrə internatura kursu keçib. 2009- cu ilin sentyabr ayından bu günə kimi Milli Onkologiya Mərkəzinin Şişönü xəstəliklərin diaqnostikası və müalicəsi şöbəsində həkim onkoginekoloq vəzifəsində çalışır. Bir çox elmi məqalələrin və “Vulvovaginal kandidozların mikrobioloji diaqnostikası” adlı metodik vəsaitin müəllifidir. 2020 ci ildə Azəbaycan səhiyyəsi üçün bir ilk olaraq elmi məqaləsi Akad. C. Əliyevin rəhbərliyi ilə Amerikada NCCN də dərc olunub.', 'info@konulmardanova.az', 'https://www.facebook.com/onkoginekoloqkonulmardanova/', '', '', '', '', '', '', '', '', '', 'https://www.youtube.com/channel/UCO06zpVa_iKM2AAN6YbGeFg', 'https://www.instagram.com/onkoginekolog/?igshid=9pl33ts3yezi', +994505630189, '', '', '', '(40.37801404257197, 49.945913320539944)', 'Open Hours: Mon - Sat 9.00 - 18.00', '', 123213);



-- ---------------------------------------------------------
--
-- Table structure for table : `currency`
--
-- ---------------------------------------------------------

CREATE TABLE `currency` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `usd` varchar(255) NOT NULL,
  `eur` varchar(255) NOT NULL,
  `rub` varchar(255) NOT NULL,
  `gel` varchar(255) NOT NULL,
  `gbp` varchar(255) NOT NULL,
  `sar` varchar(255) NOT NULL,
  `try` varchar(255) NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `currency`
--

INSERT INTO `currency` (`id`, `usd`, `eur`, `rub`, `gel`, `gbp`, `sar`, `try`, `date`) VALUES
(1, 1.7001, 2.0346, 0.0298, 0, 0, 0, 0, '2018-01-09');



-- ---------------------------------------------------------
--
-- Table structure for table : `description`
--
-- ---------------------------------------------------------

CREATE TABLE `description` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title_en` varchar(255) NOT NULL,
  `title_ru` varchar(255) NOT NULL,
  `title_az` varchar(255) NOT NULL,
  `description_en` text NOT NULL,
  `description_ru` text NOT NULL,
  `description_az` varchar(255) NOT NULL,
  `keywords_en` text NOT NULL,
  `keywords_ru` text NOT NULL,
  `keywords_az` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `description`
--

INSERT INTO `description` (`id`, `title_en`, `title_ru`, `title_az`, `description_en`, `description_ru`, `description_az`, `keywords_en`, `keywords_ru`, `keywords_az`) VALUES
(1, 'Vusal Eyvazov', 'Альголог Вусал Эйвазов', 'Onkoloq - ginekoloq - Könül Mərdanova', 'Vusal Eyvazov', 'Альголог Вусал Эйвазов, врач который лечит боль', 'Onkoginekoloq Könül Mərdanova - Uşaqlıq boynunun kistləri, Uşaqlıq yolunun kistləri, uşaqlıq boynu xərçəngi, Vulva xərçəngi, popilomalar, yumurtalıq xərçəngi', 'Vusal Eyvazov', 'Альголог, Вусал Эйвазов', 'Pap Smear testi, Kolposkopiya,  Uşaqlıq boynunun kistləri, Uşaqlıq yolunun kistləri, uşaqlıq boynu xərçəngi, Vulva xərçəngi, popilomalar, yumurtalıq xərçəngi'),
(3, 'Vusal Eyvazov', 'Альголог Вусал Эйвазов', 'Onkoloq - ginekoloq - Könül Mərdanova', 'Vusal Eyvazov', 'Альголог Вусал Эйвазов, врач который лечит боль', 'Onkoginekoloq Könül Mərdanova - Uşaqlıq boynunun kistləri, Uşaqlıq yolunun kistləri, uşaqlıq boynu xərçəngi, Vulva xərçəngi, popilomalar, yumurtalıq xərçəngi', 'Vusal Eyvazov', 'Альголог, Вусал Эйвазов', 'Pap Smear testi, Kolposkopiya,  Uşaqlıq boynunun kistləri, Uşaqlıq yolunun kistləri, uşaqlıq boynu xərçəngi, Vulva xərçəngi, popilomalar, yumurtalıq xərçəngi'),
(2, 'Vusal Eyvazov', 'Альголог Вусал Эйвазов', 'Onkoloq - ginekoloq - Könül Mərdanova', 'Vusal Eyvazov', 'Альголог Вусал Эйвазов, врач который лечит боль', 'Onkoginekoloq Könül Mərdanova - Uşaqlıq boynunun kistləri, Uşaqlıq yolunun kistləri, uşaqlıq boynu xərçəngi, Vulva xərçəngi, popilomalar, yumurtalıq xərçəngi', 'Vusal Eyvazov', 'Альголог, Вусал Эйвазов', 'Pap Smear testi, Kolposkopiya,  Uşaqlıq boynunun kistləri, Uşaqlıq yolunun kistləri, uşaqlıq boynu xərçəngi, Vulva xərçəngi, popilomalar, yumurtalıq xərçəngi');



-- ---------------------------------------------------------
--
-- Table structure for table : `documents`
--
-- ---------------------------------------------------------

CREATE TABLE `documents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name_en` varchar(50) NOT NULL,
  `name_ru` varchar(50) NOT NULL,
  `name_az` varchar(255) NOT NULL,
  `text_en` text NOT NULL,
  `text_ru` text NOT NULL,
  `text_az` text NOT NULL,
  `document` varchar(255) NOT NULL,
  `datetime` int(11) NOT NULL,
  `position` int(11) NOT NULL,
  `active` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;



-- ---------------------------------------------------------
--
-- Table structure for table : `employees`
--
-- ---------------------------------------------------------

CREATE TABLE `employees` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL,
  `name_en` varchar(100) NOT NULL,
  `name_ru` varchar(100) NOT NULL,
  `name_az` varchar(255) NOT NULL,
  `profession_en` varchar(255) NOT NULL,
  `profession_ru` varchar(255) NOT NULL,
  `profession_az` varchar(255) NOT NULL,
  `full_text_en` text NOT NULL,
  `full_text_ru` text NOT NULL,
  `full_text_az` text NOT NULL,
  `image` varchar(100) NOT NULL,
  `link` varchar(255) NOT NULL,
  `position` int(11) NOT NULL,
  `active` int(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=27 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `employees`
--

INSERT INTO `employees` (`id`, `category_id`, `name_en`, `name_ru`, `name_az`, `profession_en`, `profession_ru`, `profession_az`, `full_text_en`, `full_text_ru`, `full_text_az`, `image`, `link`, `position`, `active`) VALUES
(25, 0, '', '', '', '', '', '', '', '', '', 'client-1-1561109234.jpg', '', 0, 1),
(26, 0, '', '', '', '', '', '', '', '', '', 'client-1-1561109251.jpg', '', 0, 1);



-- ---------------------------------------------------------
--
-- Table structure for table : `faq`
--
-- ---------------------------------------------------------

CREATE TABLE `faq` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `question_en` varchar(255) NOT NULL,
  `question_ru` varchar(255) NOT NULL,
  `question_az` varchar(255) NOT NULL,
  `answer_en` text NOT NULL,
  `answer_ru` text NOT NULL,
  `answer_az` text NOT NULL,
  `position` int(11) NOT NULL,
  `active` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `faq`
--

INSERT INTO `faq` (`id`, `question_en`, `question_ru`, `question_az`, `answer_en`, `answer_ru`, `answer_az`, `position`, `active`) VALUES
(1, '', 'Какие рискованные действия могут создать условия для образования грыжи в поясничном отделе спины?', 'Uşaqlıq boynu xərçəngi necə müayinə olunur?', '', 'Поднятие предметов с пола, не сгибая ноги в коленях, толкание и подъём тяжелых предметов, не сгибая ноги в коленях, поднятие груза на плечи и вытягивание вверх, а также перенос тяжелых грузов на большие расстояния может вызвать грыжу поясничного отдела спины.', 'Əvvəlcə detallı vajinal müayinə aparılır və uşaqlıq boynundan BRAŞ fırçaları vasitəsi ilə yaxma götürülür. Bu prosedur müayinə zamanı rahat olduğunuz müddətdə ağrısız bir prosedurdur. Uşaqlıq boynu xərçənginin skrininqi PAP smear / və ya HPV testingi ilə aparılır. Əgər aparılmış PAP smear testinin nəticəsi anormaldırsa, nə etməliyəm?\nNəticənizi gətirərək birbaşa Onkoginekoloqa müraciət etməyiniz məsləhətdir.', 1, 1),
(2, '', 'Есть ли возрастные ограничения для озонотерапии?', 'Kolposkopiya nədir?', '', 'Для озонотерапии нет возрастных ограничений.', 'Kolposkopiya uşaqlıq boynunun, uşaqlıq yolunun və xarici tənasül orqanlarının proflaktik müayinəsi məqsədilə və yaxud da anormal PAP smear nəticələri olan xəstələrə və yaxud da ki, HPV testdə, HPV aşkarlanan xanımlara aparılan instirumental müayinə metodudur. Ginekoloji müayinə zamanı ginekoloji masada aparılan ağrısız bir müayinə metodudur. Uşaqlıq boynu xüsusi məhlullarla işləndikdən sonra xüsusi mikroskop vasitəsi ilə uşaqlıq boynu detallı olaraq, böyüdülərək müayinə olunur. Lazım olduqda uşaqlıq boynundan- serviksdən eyni vaxtdan biopsi alınır.', 2, 1),
(9, '', '', 'Onkoginekologiya nədir ?', '', '', 'Onkoginekolgiya qadınlarda uşaqlıq ilə əlaqəli xərçəng və xərçəng öncəsi lezyonlarla məşğul olan bir tibb sahəsidir. Onkoginekoloqlar, diaqnoz qoyulduğu andan etibarən ginekoloji xəstəliyi və ya yumurtalıq, uşaqlıq boynu, vulva xərçəngi  və s. olanqadınlar üçün əməliyyat və kimyəviterapiya, və ya digər müalicələri həyata keçirərək, onları sağlamlıqlarına qovuşdururlar.', 3, 1),
(10, '', 'Есть ли возрастные ограничения для озонотерапии?', 'Kolposkopiya nədir?', '', 'Для озонотерапии нет возрастных ограничений.', 'Kolposkopiya uşaqlıq boynunun, uşaqlıq yolunun və xarici tənasül orqanlarının proflaktik müayinəsi məqsədilə və yaxud da anormal PAP smear nəticələri olan xəstələrə və yaxud da ki, HPV testdə, HPV aşkarlanan xanımlara aparılan instirumental müayinə metodudur. Ginekoloji müayinə zamanı ginekoloji masada aparılan ağrısız bir müayinə metodudur. Uşaqlıq boynu xüsusi məhlullarla işləndikdən sonra xüsusi mikroskop vasitəsi ilə uşaqlıq boynu detallı olaraq, böyüdülərək müayinə olunur. Lazım olduqda uşaqlıq boynundan- serviksdən eyni vaxtdan biopsi alınır.', 2, 1);



-- ---------------------------------------------------------
--
-- Table structure for table : `faq_categories`
--
-- ---------------------------------------------------------

CREATE TABLE `faq_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name_en` varchar(255) NOT NULL,
  `name_ru` varchar(255) NOT NULL,
  `name_az` varchar(255) NOT NULL,
  `text_en` text NOT NULL,
  `text_ru` text NOT NULL,
  `text_az` text NOT NULL,
  `position` int(11) NOT NULL,
  `active` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `faq_categories`
--

INSERT INTO `faq_categories` (`id`, `name_en`, `name_ru`, `name_az`, `text_en`, `text_ru`, `text_az`, `position`, `active`) VALUES
(7, '', '', '', '', '', '', 2, 1),
(9, '', '', '', '', '', '', 1, 1),
(10, '', '', '', '', '', '', 3, 1);



-- ---------------------------------------------------------
--
-- Table structure for table : `fb_admins`
--
-- ---------------------------------------------------------

CREATE TABLE `fb_admins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fb_id` bigint(20) NOT NULL,
  `aktivlik` int(11) NOT NULL,
  PRIMARY KEY (`id`,`fb_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `fb_admins`
--

INSERT INTO `fb_admins` (`id`, `fb_id`, `aktivlik`) VALUES
(1, 100000514690739, 1),
(3, 2147483647112, 1);



-- ---------------------------------------------------------
--
-- Table structure for table : `home_page`
--
-- ---------------------------------------------------------

CREATE TABLE `home_page` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `image_arge` varchar(255) NOT NULL,
  `image_kalite` varchar(255) NOT NULL,
  `image_marka` varchar(255) NOT NULL,
  `image_footer` varchar(255) NOT NULL,
  `image_about` varchar(255) NOT NULL,
  `image_about1` varchar(255) NOT NULL,
  `image_about2` varchar(255) NOT NULL,
  `image_about3` varchar(255) NOT NULL,
  `image_contact` varchar(255) NOT NULL,
  `image_sunar1` varchar(255) NOT NULL,
  `image_sunar2` varchar(255) NOT NULL,
  `image_sunar3` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `home_page`
--

INSERT INTO `home_page` (`id`, `image_arge`, `image_kalite`, `image_marka`, `image_footer`, `image_about`, `image_about1`, `image_about2`, `image_about3`, `image_contact`, `image_sunar1`, `image_sunar2`, `image_sunar3`) VALUES
(1, 'ar-ge-1561022361.png', '_kalite-1562423663.png', '__makalarimiz-01-1562646842.png', '___zavod-istehsalat-1810x380-1562646575.png', '____haqqinda-1634213055.jpg', '_____konulmerdanovapasiyentler-1619293886.jpg', '______konulhekimginekoloq-1619456676.jpg', '_______onkoginekoloqkonulhekim-1619455641.jpg', '________contact-us-1562653987.png', '_________konulmerdanovaginekoloq-1619626982.jpg', '__________dermokozmetik-kozmetik-1562423389.png', '___________fason-uretimi-1562423389.png');



-- ---------------------------------------------------------
--
-- Table structure for table : `image_cropper`
--
-- ---------------------------------------------------------

CREATE TABLE `image_cropper` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;



-- ---------------------------------------------------------
--
-- Table structure for table : `langs`
--
-- ---------------------------------------------------------

CREATE TABLE `langs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `full_name` varchar(255) NOT NULL,
  `position` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `active` int(11) NOT NULL,
  `flag` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `langs`
--

INSERT INTO `langs` (`id`, `name`, `full_name`, `position`, `status`, `active`, `flag`) VALUES
(2, 'en', 'En', 2, 0, 0, 'United-Kingdom-flag-64.png'),
(3, 'ru', 'Ru', 3, 0, 1, 'Russia-Flag-64.png'),
(20, 'az', 'AZ', 1, 1, 1, 'Azerbaijan-Flag-64.png');



-- ---------------------------------------------------------
--
-- Table structure for table : `letters`
--
-- ---------------------------------------------------------

CREATE TABLE `letters` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `subject` varchar(250) NOT NULL,
  `message` text NOT NULL,
  `datetime` timestamp NOT NULL DEFAULT current_timestamp(),
  `seen_by_admin` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;



-- ---------------------------------------------------------
--
-- Table structure for table : `links`
--
-- ---------------------------------------------------------

CREATE TABLE `links` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name_en` varchar(100) NOT NULL,
  `name_ru` varchar(100) NOT NULL,
  `name_az` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `target` varchar(255) NOT NULL,
  `position` int(11) NOT NULL,
  `active` int(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `links`
--

INSERT INTO `links` (`id`, `name_en`, `name_ru`, `name_az`, `url`, `target`, `position`, `active`) VALUES
(1, 'ghjghjghjg', 'ujfufcyuj', '', 'asd', 'asd', 1, 1);



-- ---------------------------------------------------------
--
-- Table structure for table : `logs`
--
-- ---------------------------------------------------------

CREATE TABLE `logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL COMMENT 'kim daxil olubsa onun ID sidir. yeni iwci daxil olsa iwcinin, mudur daxil olsa mudurun, admin daxil olsa adminin',
  `action` varchar(50) NOT NULL,
  `amount` double NOT NULL,
  `note` varchar(255) NOT NULL,
  `data_id` int(11) NOT NULL,
  `old_value` varchar(50) NOT NULL,
  `new_value` varchar(50) NOT NULL,
  `datetime` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;



-- ---------------------------------------------------------
--
-- Table structure for table : `menus`
--
-- ---------------------------------------------------------

CREATE TABLE `menus` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) NOT NULL,
  `name_en` varchar(255) NOT NULL,
  `name_ru` varchar(255) NOT NULL,
  `name_az` varchar(255) NOT NULL,
  `text_en` text NOT NULL,
  `text_ru` text NOT NULL,
  `text_az` text NOT NULL,
  `link` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL DEFAULT '0',
  `icon_code` varchar(255) NOT NULL,
  `important` tinyint(1) NOT NULL DEFAULT 0,
  `position` int(11) NOT NULL,
  `active` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=36 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `menus`
--

INSERT INTO `menus` (`id`, `parent_id`, `name_en`, `name_ru`, `name_az`, `text_en`, `text_ru`, `text_az`, `link`, `image`, `icon_code`, `important`, `position`, `active`) VALUES
(7, 0, 'HOME', 'Главная', 'Ana səhifə', '', '', '', 'home', 'rom7417-1511072377.jpg', '', 0, 1, 1),
(10, 0, 'About', 'О враче', 'Həkim haqqında', '', '', '<div><span style="font-size: 18px;">Onkoginekoloq Könül Mərdanova 2006 ci ildə Azərbaycan Tibb Unuversitetinin Müalicə işi fakultəsini fərqlənmə ilə bitirib. 2007 cildə Milli Onkologiya Mərkəzində Onkologiya ixtisasi üzrə internatura kursu keçib. 2009- cu ilin sentyabr ayından bu günə kimi Milli Onkologiya Mərkəzinin Şişönü xəstəliklərin diaqnostikası və müalicəsi şöbəsində həkim onkoginekoloq vəzifəsində çalışır. Bir çox elmi məqalələrin və &ldquo;Vulvovaginal kandidozların mikrobioloji diaqnostikası&rdquo; adlı metodik vəsaitin müəllifidir. 2020 ci ildə Azəbaycan səhiyyəsi üçün bir ilk olaraq elmi məqaləsi Akad. C. Əliyevin rəhbərliyi ilə Amerikada NCCN də dərc olunub.</span></div>\n<h1><span style="font-size: 18px;">Qatıldığı konfranslar və kurslar</span></h1>\n<p><span style="font-size: 18px;">&bull; 2009 cu il Türkiyə Ankara Hacettepe universitesi Kolposkopiya və histeroskopiya üzrə təkmilləşdirmə kursu</span></p>\n<p><span style="font-size: 18px;">&bull; 2010 Türkiyə Antalya Kök hücrə konfransı</span></p>\n<p><br /><strong></strong></p>\n<h1><span style="font-size: 18px;">Müalicə etdiyi qadın xəstəlikləri</span></h1>\n<ul>\n<li><span style="font-size: 18px;">Uşaqlığın mioması</span></li>\n<li><span style="font-size: 18px;">Uşaqlığın adiomiozu</span></li>\n<li><span style="font-size: 18px;">Endometrionun polipi</span></li>\n<li><span style="font-size: 18px;">Yumurtalıq kistası</span></li>\n<li><span style="font-size: 18px;">Uşaqlıq boynunun polipi</span></li>\n<li><span style="font-size: 18px;">Uşaqlıq boynunun eroziyasi</span></li>\n<li><span style="font-size: 18px;">Uşaqlıq boynunun endometriosu</span></li>\n<li><span style="font-size: 18px;">Uşaqlıq boynunun kistləri</span></li>\n<li><span style="font-size: 18px;">Uşaqlıq yolunun kistləri</span></li>\n<li><span style="font-size: 18px;">Bartolin vəzinin kistləri</span></li>\n<li><span style="font-size: 18px;">Xarici tənasül orqanlarının popilomalari,kandilomaları, kistaları,</span></li>\n<li><span style="font-size: 18px;">Uşaqlıq boynunun xərçəngi</span></li>\n<li><span style="font-size: 18px;">Yumurtalıq xərçəngi</span></li>\n<li><span style="font-size: 18px;">Vulva xərcəngi</span></li>\n<li><span style="font-size: 18px;">Bütün ginekoloji xəstəliklər</span></li>\n</ul>\n<div>&nbsp;</div>\n<h1><span style="font-size: 18px;">Müalicə metodları</span></h1>\n<div>\n<ul>\n<li><span style="font-size: 18px;">Kolposkopiya</span></li>\n<li><span style="font-size: 18px;">Histeroskopiya</span></li>\n<li><span style="font-size: 18px;">Pap Smear</span></li>\n<li><span style="font-size: 18px;">Uşaqlıqda aparılan hər növ cərrahi əməliyyatlar (histerektomiya, kistektomiya, miomektomiya)</span></li>\n<li><span style="font-size: 18px;">Vaginoplastika</span></li>\n<li><span style="font-size: 18px;">Bartolin vəzi kistalarının ləğvi</span></li>\n<li><span style="font-size: 18px;">Uşaqlıq boynu eroziyalarının diaqnostikası və müvafiq müalicə</span></li>\n<li><span style="font-size: 18px;">Vulva, kondiloma və papillomaların lazer ilə tam ağrısız şəraitdə destruksiyası</span></li>\n<li><span style="font-size: 18px;">Uşaqlıq boynu poliplərinin lazer üsulu ilə ləğvi</span></li>\n<li><span style="font-size: 18px;">Endometrial biopsiyalar</span></li>\n<li><span style="font-size: 18px;">Laparoskopik əməliyyatlar</span></li>\n</ul>\n</div>', 'haqqimizda', 'onkoloqginekoloqonkoginekoloqkonulmerdanova-1618987421.jpg', '', 0, 2, 1),
(30, 0, 'Qalereya', 'Галерея', 'Qalereya', '', '', '', '#', 'konulhekimginekoloq-1619626350.jpg', '', 0, 4, 1),
(15, 33, 'Ağrılar', 'Излечимые боли', 'Qadın xəstəlikləri', '', '', '', 'xidmetler', 'konulhekimginekoloq-1619545837.jpg', '', 0, 1, 1),
(29, 0, 'Əlaqə', 'Контакты', 'Əlaqə', '', '', '', 'elaqe', 'konulhekimginekoloq-1619626013.jpg', '', 0, 7, 1),
(21, 33, 'Müalicə üsulları', 'Процедуры', 'Müalicələr', '', '', '', 'metodlar', 'konulhekimginekoloq-1619545859.jpg', '', 0, 2, 1),
(25, 0, 'Rəylər', 'Комментарии', 'Rəylər', '', '', '', 'reyler', 'konulhekimginekoloq-1619626421.jpg', '', 0, 5, 1),
(26, 30, 'Videoqalereya', 'Видеогалерея', 'Videoqalereya', '', '', '', 'videoqalereya', 'konulhekimginekoloq-1619626373.jpg', '', 0, 1, 1),
(28, 30, 'Fotoqalereya', 'Фотогалерея', 'Fotoqalereya', '', '', '', 'albom', 'konulhekimginekoloq-1619626404.jpg', '', 0, 2, 1),
(33, 0, '', 'Центр лечения боли', 'Onkoginekologiya', '', '', '', '#', 'konulhekimginekoloq-1619626055.jpg', '', 0, 2, 1),
(35, 0, '', 'Блог', 'Xanımlar üçün', '', '', '', 'bloq', 'konulhekimginekoloq-1619626461.jpg', '', 0, 6, 1);



-- ---------------------------------------------------------
--
-- Table structure for table : `methods`
--
-- ---------------------------------------------------------

CREATE TABLE `methods` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name_en` varchar(100) NOT NULL,
  `name_ru` varchar(100) NOT NULL,
  `name_az` varchar(255) NOT NULL,
  `short_text_en` text NOT NULL,
  `short_text_ru` text NOT NULL,
  `short_text_az` text NOT NULL,
  `full_text_en` text NOT NULL,
  `full_text_ru` text NOT NULL,
  `full_text_az` text NOT NULL,
  `image` varchar(100) NOT NULL DEFAULT '0',
  `position` int(11) NOT NULL,
  `active` int(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `methods`
--

INSERT INTO `methods` (`id`, `name_en`, `name_ru`, `name_az`, `short_text_en`, `short_text_ru`, `short_text_az`, `full_text_en`, `full_text_ru`, `full_text_az`, `image`, `position`, `active`) VALUES
(1, '', '', 'Kolposkopiya nədir?', '', '', 'Kolposkopiya uşaqlıq boynunun, uşaqlıq yolunun və xarici tənasül orqanlarının proflaktik müayinəsi məqsədi ilə və yaxud anormal Pap Smear testi nəticələri olan xəstələrə və ya HPV aşkarlanan xanımlara aparılan instirumental müayinə metodudur. Ginekoloji müayinə zamanı, ginekoloji masada aparılan ağrısız bir müayinə metodudur. Uşaqlıq boynu xüsusi məhlullarla işləndikdən sonra xüsusi mikroskop vasitəsi ilə uşaqlıq boynu detallı olaraq, böyüdülərək müayinə olunur. Lazım gələrsə, uşaqlıq boynundan, serviksdən eyni vaxtda biopsi alınır.', '', '', '<p><br /><span style="color: #000000;"><span style="font-size: 16px;">Kolposkopiya uşaqlıq boynunun, uşaqlıq yolunun və xarici tənasül orqanlarının proflaktik müayinəsi məqsədi ilə və yaxud anormal Pap Smear testi nəticələri olan xəstələrə və ya HPV aşkarlanan xanımlara aparılan instirumental müayinə metodudur. Ginekoloji müayinə zamanı, ginekoloji masada aparılan ağrısız bir müayinə metodudur. Uşaqlıq boynu xüsusi məhlullarla işləndikdən sonra xüsusi mikroskop vasitəsi ilə uşaqlıq boynu detallı olaraq, böyüdülərək müayinə olunur. Lazım gələrsə, uşaqlıq boynundan, serviksdən eynı vaxtda biopsi alınır.<br /><br /><br />Uşaqlıq boynunun, yəni serviksin müayinəsində istifadə edilən (qeyri-invaziv) üsul olan "kolposkopiya" 1900-cü illərin əvvəllərindən etibarən tətbiq olunmağa başlamışdır. Kolposkopiya<iframe allowFullScreen="allowFullScreen" src="http://www.youtube.com/embed/GzDryYioDaE" frameborder="0" align="right" width="425" height="350"></iframe> nədir? Kolposkopiya proseduru nə qədər davam edir? Kolposkopiya nəticəsinə əsasən biopsiya edildikdə cavab dərhal çıxa bilərmi? Nəyə görə kolposkopiya edilir? Kolposkopiya ağrılı prosedurdurmu? Kolposkopiya zamanı anesteziyaya ehtiyyac varmı? Kolposkopiya üçün göstəricilər hansılardır? Hamiləlik zamanı kolposkopiya edilə bilərmi? kimi ən çox maraqlanılan sualların cavabını məqaləmizdə tapa biləcəksiniz.<br /><br /></span><strong><span style="font-size: 18px;">Mündəricat</span></strong></span></p>\n<ul>\n<li><span style="color: #000000;"><strong><span style="font-size: 18px;">Kolposkopiya nədir?</span></strong></span></li>\n<li><span style="color: #000000;"><strong><span style="font-size: 18px;">Kolposkopiya hansı xəstəliklər zamanı edilir?</span></strong></span></li>\n<li><span style="color: #000000;"><strong><span style="font-size: 18px;">Kolposkopiya ilə bağlı tez-tez verilən suallar<br /><br /></span></strong><strong style="font-size: 18px;">KOLPOSKOPİYA NƏDİR?</strong></span></li>\n</ul>\n<p><span style="font-size: 16px; color: #000000;">Kolposkopiya həkimlərə uşaqlıq boynunu müayinə etməyə imkan verən qeyri-invaziv bir üsuldur. Uşaqlıq boynunu 6-40 dəfə daha böyük göstərəbilən kolposkop adlı işıqlı alət ilə serviksi daha aydın şəkildə görmək və daha dəqiq qiymətləndirmək mümkündür.</span></p>\n<p><span style="font-size: 16px; color: #000000;">Kliniki prosedur olan kolposkopiya metodunda istifadə edilən kolposkop işıqlı lupadan ibarət olan və durbinə bənzəyən bir alətdir. Adi qaydada edilən ginekoloji müayinənin kolposkopiya metodu ilə böyüdərək edilməsi başda uşaqlıq boynu xərçənginin aşkar edilməsi və eyni zamanda vaginanın da dəqiq müayinəsinə imkan verir.</span></p>\n<p><span style="color: #000000;"><span style="font-size: 16px;">Kolposkopiya müayinəsi zamanı şübhəli bir şey nəzərə çarpdığı zaman kolposkopik biopsiya edilərək şübhəli bölgənin incələnməsi mümkündür.<br /><br /></span><strong style="font-size: 18px;">KOLPOSKOPİYA HANSI XƏSTƏLİKLƏR ZAMANI İSTİFADƏ OLUNUR?</strong></span></p>\n<p><span style="font-size: 16px; color: #000000;">Kolposkopiya uşaqlıq boynu xərçəngini (serviks xərçəngi) erkən mərhələdə, xüsusilə klinik əlamətlər olmadan aşkar etməyə kömək edir. Kolposkopiya sitologiya nəticələrində və smear testində normadan kənar göstəriciləri olan, HPV testində HPV 16 və ya 18 göstəriciləri müsbət çıxan xəstələrdə isitfadə olunur. Uşaqlıq boynu xərçəngi yavaş irəliləyən xərçəng olduğu üçün ginekoloji müayinələr zamanı baş verən dəyişikliklər kolposkopiya ilə daha dəqiq dəyərləndirilə bilir.</span></p>\n<p><span style="font-size: 16px; color: #000000;">Uşaqlıq boynu xərçənginin erkən diaqnozunda həyati rolu olan kolposkopiyanın istifadəsi sadəcə bununla məhdudlaşmır. "Kolposkopiya nə üçün edilir?" sualın əsas cavabı uşaqlıq boynu xərçənginin erkən diaqnozudur. Bununla yanaşı bir çox qadın xəstəliyin təqibində və diaqnozunda da istifadə edilə bilər.</span></p>\n<p><span style="font-size: 16px; color: #000000;">"Nəyə görə kolposkopiya edilir?", "Kolposkopiya üçün göstəricilər hansılardır?" və ya "Kolposkopiya nə zaman edilməlidir?" suallarına cavabları aşağıdakı kimi sıralaya bilərik:</span></p>\n<ul>\n<li><span style="color: #000000;"><strong><span style="font-size: 16px;">Uşaqlıq boynu xərçənginin diaqnozunda,</span></strong></span></li>\n<li><span style="color: #000000;"><strong><span style="font-size: 16px;">Vulvada olan şübhəli lezyonların dəyərləndirilməsi zamanı,</span></strong></span></li>\n<li><span style="color: #000000;"><strong><span style="font-size: 16px;">Qadınların cinsiyyət orqanının xarici hissəsi olan vulvada görünən xərçəng öncəsi dəyişikliklərin diaqnozu zamanı,</span></strong></span></li>\n<li><span style="color: #000000;"><strong><span style="font-size: 16px;">Vulvada uzun müddət davam edən qaşınmaların səbəbinin araşdırılması zamanı,</span></strong></span></li>\n<li><span style="color: #000000;"><strong><span style="font-size: 16px;">Servikal toxumada xərçəng öncəsi yəni hələ xərçəng olmamış amma xərçəngin inkişaf edəbiləcəyi dəyişikliklərin diaqnozu zamanı</span></strong></span></li>\n</ul>\n<p><span style="font-size: 16px; color: #000000;">Kolposkopiya, vajinal toxumadakı prekanseröz, yəni xərçəng hələ meydana gəlməmiş, lakin xərçəng inkişaf etdirə bilən dəyişiklikləri təyin etmək üçün edilə bilər.</span></p>\n<p><span style="font-size: 16px; color: #000000;">Bunlara əlavə olaraq kolposkopiya aşağıdakı hallarda da edilə bilər:</span></p>\n<ul>\n<li><span style="color: #000000;"><strong><span style="font-size: 16px;">hamiləlik dövründə</span></strong></span></li>\n<li><span style="color: #000000;"><strong><span style="font-size: 16px;">Sonsuzluğun səbəbinin aşkar edilməsi zamanı</span></strong></span></li>\n<li><span style="color: #000000;"><strong><span style="font-size: 16px;">Uşaqlıq boynunda ediləcək hər hansı bir əməliyyatdan əvvəl<br /><br /></span></strong><span style="font-size: 18px;"><strong style="font-size: 16px;">KOLPOSKOPİYA İLƏ BAĞLI TEZ-TEZ VERİLƏN SUALLAR</strong></span></span></li>\n</ul>\n<ul>\n<li><span style="color: #000000;"><strong><span style="font-size: 16px;">Kolposkopiyaya hazırlanma prosesi nəcədir?</span></strong></span></li>\n</ul>\n<p>&nbsp;</p>\n<p><span style="font-size: 16px; color: #000000;">Kolposkopiya müayinəsi etdirmək qadınlarda qorxu hissi yarada bilər. Kolposkopiya proseduru əslində ağrısız və demək olar ki, risksiz bir prosedur olsa da, qorxular xəstədə narahatlığa səbəb ola bilər. Kolposkopiyanın yaratdığı narahatlığı azaltmaq üçün prosedurla bağlı bütün detalları öyrənmək vacibdir.</span></p>\n<p>&nbsp;</p>\n<ul>\n<li><span style="font-size: 16px; color: #000000;"><strong>Kolposkopiya proseduru;</strong></span></li>\n<li><span style="font-size: 16px; color: #000000;">Dəqiq nəticə əldə etmək üçün aybaşı dövründə kolposkopiya edilmir.</span></li>\n<li><span style="font-size: 16px; color: #000000;">Kolposkopiyadan bir vəya iki gün əvvəl cinsi əlaqə olmamalıdır.</span></li>\n<li><span style="font-size: 16px; color: #000000;">Kolposkopiyadan bir vəya iki gün əvvəl tampon istifadə edilməməlidir.</span></li>\n<li><span style="font-size: 16px; color: #000000;">Kolposkopiyadan əvvəlki iki gün vajina üçün dərmanlardan istifadə edilməməlidir.</span></li>\n<li><span style="font-size: 16px; color: #000000;">Kolposkopiyadan əvvəl vajinal duş edilməməlidir.</span></li>\n<li><span style="font-size: 16px; color: #000000;">Kolposkopiya prosedurundan əvvəl yalnız həkimin tövsiyə etdiyi ağrıkəsicilərdən istifadə etmək olar.</span></li>\n<li><span style="color: #000000;"><span style="font-size: 16px;">Kolposkopiyadan əvvəl yaşanan narahatlığı azaltmaq üçün idman, meditasiya və ya yaxın dostunuzla vaxt keçirərək stresinizi azalda bilərsiniz. Prosedur zamanı musiqi dinləmək və bənzər fəaliyyətlər də yaşana biləcək narahatlığı azalda bilər<br /><br /></span><strong style="font-size: 16px;">Kolposkopiya proseduru necə olur?</strong></span></li>\n</ul>\n<p><span style="font-size: 16px; color: #000000;">Kolposkopiya klinik şəraitdə edilən prosedurdur.</span></p>\n<p><span style="font-size: 16px; color: #000000;">Xəstə, çanaq müayinəsi və yaxma (smear) testi zamanı olduğu kimi ayaqları dəstəkləyən bir masada arxası üstə uzanır.</span></p>\n<p><span style="font-size: 16px; color: #000000;">Vajinal divarın açılmasına kömək edən bir spekulum aparatı vajinaya qoyulur və serviksə daha rahat baxılmağına şərait yaradılır.</span></p>\n<p><span style="font-size: 16px; color: #000000;">Daha rahat və aydın bir görüntü üçün serviks xüsusi maddə ilə yuyulur.</span></p>\n<p><span style="font-size: 16px; color: #000000;">Anormal hüceyrələrin görünməsini asanlaşdıran bu yuma prosesi bəzən yanma hissinə səbəb ola bilər.</span></p>\n<p><span style="font-size: 16px; color: #000000;">Kolposkopiya aləti vajinanın bir neçə sm önünə yerləşdirilir. Kolposkopiya aləti xəstəyə toxunmur və vajinaya girmir.</span></p>\n<p><span style="font-size: 16px; color: #000000;">Toxumaları 6-40 dəfə böyüdən kolposkopiya cihazı ilə vajinanın iç tərəfi işıqlandırılaraq daha aydın bir görüntü əldə edilir.</span></p>\n<p><span style="color: #000000;"><span style="font-size: 16px;">Şübhəli bir lezyonun göründüyü hallarda Kolposkopik biopsiya edilir.<br /><br /></span><strong style="font-size: 16px;">Kolposkopik biopsiya necə aparılır?</strong></span></p>\n<p><span style="font-size: 16px; color: #000000;">Kolposkopiya müayinəsi zamanı şübhəli toxumalar aşkar edildikdə, biopsiya forsepsli ilə bütün şübhəli lezyonlardan kolposkopik biopsiya edilə bilər.</span></p>\n<p><span style="font-size: 16px; color: #000000;">Kolposkopik biopsiya zamanı birdən çox bölgədən biopsiya götürülə bilər.</span></p>\n<p><span style="color: #000000;"><span style="font-size: 16px;">Kolposkopik biopsiya aparmaq üçün xüsusi bir alətdən istifadə olunur və alınacaq hissənin ölçüsü patoloji müayinəyə kifayət edəcək böyüklükdə olmalıdır.<br /><br /></span><strong style="font-size: 16px;">Kolposkopiya proseduru nə qədər davam edir?</strong></span></p>\n<p><span style="color: #000000;"><span style="font-size: 16px;">Kolposkopiya prosedurunun müddəti kolposkopik biopsiyanın edilib edilməyəcəyinə uyğun olaraq dəyişə bilər. Ümumilikdə proses 5 -15 dəqiqə arasında davam edir.<br /><br /></span><strong style="font-size: 16px;">Kolposkopiya proseduru ağrılıdırmı?</strong></span></p>\n<p><span style="font-size: 16px; color: #000000;">Prosedur zamanı kolposkopiya vajinaya daxil olmadığı üçün ağrı hiss olunmur.</span></p>\n<p><span style="font-size: 16px; color: #000000;">Uşaqlıq boynunu açıq tutmaq üçün vajinal spekulumdan istifadə edildiyi üçün vaginada yüngül təzyiq hiss oluna bilər.</span></p>\n<p><span style="font-size: 16px; color: #000000;">Daha dəqiq görüntü əldə etmək üçün uşaqlıq boynunun yuyulduğu maddə sancma və ya yanma hissinə səbəb ola bilər.</span></p>\n<p><span style="font-size: 16px; color: #000000;">Bununla birlikdə, ağrı, həkimin şübhəli gördüyü və kolposkopik biopsiyaya ehtiyacı duyduğu zaman parçanın alındığı bölgəyə görə də dəyişə bilər.</span></p>\n<p>&nbsp;</p>\n<p><span style="font-size: 16px; color: #000000;">Servikal bölgədə sinirlər çox olmadığı üçün bu bölgədə aparılan biopsiyalar ümumiyyətlə ağrılı olmur. Serviks nahiyəsindən biopsiya götürüldüyü zaman xəstə yüngül təzyiq və ağrı hiss edə bilər.</span></p>\n<p><span style="color: #000000;"><span style="font-size: 16px;">Vagina və vulvanın aşağı hissəsində aparılan biopsiya ağrıya səbəb ola bilər. Bəzən birdən çox hissədən parça götürülməsinin tələb olunduğu hallarda lokal anesteziya tətbiq oluna bilər.<br /><br /></span><strong style="font-size: 16px;">Kolposkopiya və kolposkopik biopsiyanın riskləri nələrdir?</strong></span></p>\n<p><span style="font-size: 16px; color: #000000;">Kolposkopiya təhlükəsiz bir üsuldur və təhlükəsiz bir prosedur olduğu üçün də dəfələrlə təkrarlana bilər.</span></p>\n<p><span style="font-size: 16px; color: #000000;">Kolposkopik biopsiya zamanı nadir hallarda:</span></p>\n<ul>\n<li><span style="color: #000000;"><strong><span style="font-size: 16px;">Qanaxma</span></strong></span></li>\n<li><span style="color: #000000;"><strong><span style="font-size: 16px;">İnfeksiya</span></strong></span></li>\n<li><span style="color: #000000;"><strong><span style="font-size: 16px;">Yüksək tempratur və ya üşütmə</span></strong></span></li>\n<li><span style="color: #000000;"><strong><span style="font-size: 16px;">Vaginadan tünd, sarı və pis qoxulu axıntı</span></strong></span></li>\n<li style="text-align: left;"><span style="color: #000000;"><strong><span style="font-size: 16px;">Qarın alt hissəsində ağrı yarana bilər.<br /><br /></span></strong></span></li>\n</ul>\n<p><span style="color: #000000;"><strong><span style="font-size: 16px;">K</span></strong><strong style="font-size: 16px;">olposkopiyadan sonra qanaxma ola bilərmi?</strong></span></p>\n<p><span style="color: #000000;"><span style="font-size: 16px;">Kolposkopiya zamanı kolposkap aləti vaginaya toxunmadığı üçün ağrı və ya qanaxma halları müşahidə olunmur. Lakin, lazım görüldüyü zaman edilən kolposkopiya biopsiyası zamanı yüngül qanaxma yaşana bilər. Qanaxma miqdarı biopsiya ediləcək bölgəyə və biopsiya üçün alınacaq parçaların çoxluğuna görə dəyişə bilər. Kolposkopik biopsiya zamanı baş verən qanaxmalar qısa müddətdə dayandırılabilən sadə qanaxmalar şəklində olur.<br /><br /></span><strong style="font-size: 16px;">Kolposkopiyadan sonra axıntılar olabilərmi?</strong></span></p>\n<p><span style="color: #000000;"><span style="font-size: 16px;">Kolposkopiya və kolposkopik biopsiyadan sonra axıntı yaşana bilər. Kolposkopiya proseduru zamanı serviksin dəqiq görünməyi və ya biopsiya zamanı kiçik qanaxmaların qarşısını almaq məqsədilə istifadə edilən maye məhsullar daha sonra axıntıya səbəb ola bilər. Kolposkopiyadan sonra axıntılar izlənilməli əgər tünd, sarı rəngli və pis qoxulu axıntı olarsa həkimə müraciət edilməlidir.<br /><br /></span><strong style="font-size: 16px;">Kolposkopiyanın nəticəsi dərhal verilirmi?</strong></span></p>\n<p><span style="color: #000000;"><span style="font-size: 16px;">Əgər kolposkopik biopsiya edilərsə nəticələrin çıxmağı bir neçə gün gecikə bilər.<br /><br /></span><strong style="font-size: 16px;">Hamiləlik zamanı kolposkopiya edilə bilərmi?</strong></span></p>\n<p><span style="color: #000000;"><span style="font-size: 16px;">Hamilə xanımlar "Hamiləlik zamanı kolposkopiya edilə bilərmi?&rdquo; sualının tez-tez soruşurlar. Kolposkopiya tamamilə təhlükəsiz bir prosedurdur və hamiləlik zamanı da edilə bilər. Kolposkopik biopsiya edilməsi zəruri olduğu hallarda isə diqqətli olmaq lazımdır. Hamiləlik zamanı kolposkopiya sadəcə bu sahədə mütəxəssis olan həkimlər tərəfindən edilməlidir. Aşağı dərəcəli lezyonlar üçün hamilə olmayan qadınlarda biopsiya edildiyi halda, hamilə qadınlarda sadəcə xərçəng şübhəsinə səbəb olan lezyonlarda edilə bilər. Xərçəng şübhəsi olmayan lezyonların incələnməsi doğuşdan sonra edilməlidir. Hamilə olmayan xəstələrə edilən uşaqlıq kanalının qaşınaraq təmizlənməsi proseduru hamilə qadınlara tətbiq olunmur.<br /><br /></span><strong style="font-size: 16px;">Kolposkopiya zamanı anesteziya edilmi?</strong></span></p>\n<p><span style="color: #000000;"><span style="font-size: 16px;">Kolposkopiya ümumilikdə anesteziyaya ehtiyyac olmadan edilən prosedurdur. Vaginanın və vulvanın aşağı hissəsində kolposkopik biopsiya zamanı lokal anesteziyadan istifadə edilə bilər.<br /><br /></span><strong style="font-size: 16px;">Kolposkopiyadan sonra nələrə diqqət yetirilməlidir?</strong></span></p>\n<p><span style="font-size: 16px; color: #000000;">Kolposkopiya zamanı biopsiya edilmirsə gündəlik işlərinizi məhdudlaşdırmağınıza ehtiyac yoxdur. Prosedur sonrası bir neçə gün ərzində çox yüngül qanaxma və ya axıntı ola bilər.</span></p>\n<p><span style="font-size: 16px; color: #000000;">Kolposkopik biopsiyadan sonra</span></p>\n<p><span style="font-size: 16px; color: #000000;">Duş qəbul etməyin hərhansı bir ziyanı yoxdur.</span></p>\n<p><span style="font-size: 16px; color: #000000;">Bir müddət cinsi əlaqədən çəkinmək lazımdır.</span></p>\n<p><span style="color: #000000;"><span style="font-size: 16px;">İstifadə olunan dərmanlar həkimdən soruşularaq davam etdirilə bilər.<br /><br /></span><strong style="font-size: 16px;">Kolposkopiyadan sonra menstruasiyada gecikmə olurmu?</strong></span></p>\n<p><span style="color: #000000;"><span style="font-size: 16px;">Çox nadir olsa da, bəzi xəstələrdə kolposkopiyadan sonra aybaşı gecikməsi ola bilər.<br /><br /></span><strong style="font-size: 16px;">Kolposkopiyadan sonra cinsi əlaqə necə olmalıdır?</strong></span></p>\n<p><span style="color: #000000;"><span style="font-size: 16px;">Kolposkopiyadan sonra cinsi əlaqəni kəsməyə ehtiyac yoxdur. Lakin kolposkopik biopsiya aparılırsa, 2-3 gün ərzində cinsi əlaqədən çəkinmək lazımdır.<br /><br /></span><strong style="font-size: 16px;">Kolposkopiyadan sonra qasıq ağrısı ola bilərmi?</strong></span></p>\n<p><span style="color: #000000;"><span style="font-size: 16px;">Kolposkopiya prosedurundan sonra qasıq ağrısına rast gəlinmir. Bununla birlikdə, kolposkopik biopsiya edilən xəstələrdə yüngül qasıq ağrısı ola bilər.<br /><br /></span><strong style="font-size: 16px;">Kolposkopiya hamilə qalmağa təsir edə bilərmi?</strong></span></p>\n<p><span style="color: #000000;"><span style="font-size: 16px;">Kolposkopiya və kolposkopik biopsiya hamiləliyə təsir göstərmir. Biopsiya zamanı alınan toxuma nümunələri çox kiçik olduğundan hamiləliyə mənfi təsir göstərmir.<br /><br /></span><span style="font-size: 18px;"><strong style="font-size: 16px;">Kolposkopiya hansı şöbə və həkim tərəfindən aparılır?</strong></span></span></p>\n<p><span style="font-size: 18px; color: #000000;"><span style="font-size: 16px;">Kolposkopiya ginekologiya şöbəsinin həkimləri tərəfindən aparılır</span><br /><br /><strong style="font-size: 16px;">LEEP nedir?</strong></span></p>\n<p><span style="font-size: 16px; color: #000000;">&ldquo;Kolposkopik biopsi sonuçları anormal çıkan hastalarda anestezi altında rahim ağzının bir miktar tam kat çıkarılma işlemidir. İşlem sonrasında lezyonun rahmin içine doğru devamlılığı ve yaygınlığı araştırılır. Biyopsi sonucuna karşı tedavi ve takip açısından daha etkin bir yöntemdir.</span></p>\n<p><span style="font-size: 16px; color: #000000;">Kolposkopik biopsiya zamanı şübhəli nəticə olan xəstələrdə anesteziya ilə serviksin bir hissəsinin çıxarılması prosedurudur. Prosedurdan sonra lezyonun uşaqlığın içərisinə tərəf olan davamlılığı və yayılma dərəcəsi araşdırılır. Biopsiya nəticəsinə əsasən xəstəliyin müalicəsi və incələnməsi zamanı daha təsirli bir üsuldur.</span></p>', 'about-breadcrumb-1634630495.jpg', 1, 1),
(3, '', '', 'Histeroskopiya nədir?', '', '', 'Histeroskopiya Qadın sağlamlığının qorunmasında son dərəcə əhəmiyyətli bir prosedur olan histeroskopiya uşaq sahibi olmaq istəyənlərin müayinəsi və ya ginekoloji problemlər zamanı istifadə edilən bir üsuldur. Bu üsul mütəxəssis həkimlər tərəfindən edilməlidir.', '', '', '<p align="center">&nbsp;</p>\n<p style="text-align: left;" align="center"><span style="font-size: 18px; color: #000000;"><strong>HİSTEROSKOPİYA HANSI XƏSTƏLİKLƏR ZAMANI İSTİFADƏ OLUNUR?</strong></span></p>\n<p style="text-align: left;"><span style="font-size: 18px; color: #000000;"><strong>Histeroskopiya </strong></span></p>\n<p><span style="color: #000000;">Qadın sağlamlığının qorunmasında son dərəcə əhəmiyyətli bir prosedur olan histeroskopiya uşaq sahibi olmaq istəyənlərin müayinəsi və ya ginekoloji problemlər zamanı istifadə edilən bir üsuldur. Bu üsul mütəxəssis həkimlər tərəfindən edilməlidir.</span></p>\n<p>&nbsp;</p>\n<p><span style="color: #000000; font-size: 18px;"><strong>Mündəricat</strong></span></p>\n<p><span style="color: #000000; font-size: 18px;"><strong>Histeroskopiya nədir?</strong></span></p>\n<p><span style="color: #000000; font-size: 18px;"><strong>Hansı xəstəliklər zamanı istifadə olunur?</strong></span></p>\n<p><span style="color: #000000; font-size: 18px;"><strong>Histeroskopiya proseduru necə həyata keçirilir?</strong></span></p>\n<p><span style="color: #000000; font-size: 18px;"><strong>Histeroskopiya proseduru ilə bağlı tez-tez verilən suallar</strong></span></p>\n<p>&nbsp;</p>\n<p><span style="color: #000000; font-size: 18px;"><strong>HİSTEROSKOPİYA NƏDİR? </strong></span></p>\n<p><span style="color: #000000;">Hystero və Scopy sözlərindən yaranan histeroskopiya uşaqlıq və görüntüləmə sözlərinin birləşməsidir. Histeroskopiya optic bir cihazla uşaqlıq boynundan içəri girərək uşaqlığın içini və boruların uşaqlıq yoluna açılan hissəsini yoxlamaq üçün istifadə edilən üsuldur. Histeroskopiya iki məqsəd üçün istifadə olunur: diaqnostika (diaqnostik) və cərrahi (operativ).</span></p>\n<p>&nbsp;</p>\n<p><span style="color: #000000; font-size: 18px;"><strong>HANSI XƏSTƏLİKLƏR ZAMANI İSTİFADƏ EDİLİR?</strong></span></p>\n<p><span style="color: #000000;">Histeroskopiya; qanaxma, menstruasiya pozğunluğu, ağrı, uşaqlıq mioması, polip, uşaqlığın anadangəlmə anormallığı, təkrarlanan açılışlar, ucu itmiş spiralların çıxarılması və uşaqlıqda pərdə olması kimi xəstəliklər zamanı həm diaqnostik, həm də terapevtik məqsədlər üçün istifadə olunur. Bundan əlavə histeroskopiya ilə uşaqlıq divarı (endometrial) patologiiyalarıni təyin etmək üçün nümunələr də götürülə bilər.</span></p>\n<p>&nbsp;</p>\n<p><span style="color: #000000; font-size: 18px;"><strong>HİSTEROSKOPİYA PROSEDURU NECƏ HƏYATA KEÇİRİLİR? </strong></span></p>\n<p><span style="color: #000000;">Histeroskopiya vaginal yolla servikal kanaldan xüsusi alətlərlə uşaqlıq yoluna girərək edilir. Bəzən cərrahi histeroskopiya prosedurlarından əvvəl xəstəyə dərman verərək uşaqlıq boynunu açmaq lazım ola bilər. Açıldıqdan sonra kamera və lens sistemindən ibarət olan borulu histeroskop vaginadan və uşaqlıq boynundan keçir və uşaqlığa doğru irəliləyir. Uterusun içinin aydın görülməyi üçün uşaqlığa xüsusi mayelər yeridilir və görüntü monitorda mütəxəssis tərəfindən izlənilir. Həkimlər lazım olduqda histeroskopun ucundakı kəsici və lazer effektli alətlərlə əməliyyat da edəbilər.</span></p>\n<p><span style="color: #000000;">Histeroskopiya proseduru həm həkim otağında, həm də əməliyyatxana şəraitində edilə bilər. Həkim otağında edilən histeroskopiya ümumi anesteziya olmadan yalnız lokal anesteziya ilə aparılan və diaqnoz məqsədilə edilən histeroskopiyadır. Otaq şəraitində istifadə edilən histeroskopiyada bəzi kiçik alətlərin istifadəsinə imkan verən girişlər mövcuddur. Texnoloji yeniliklərlə birlikdə histeroskopiya həm daha incə və daha kiçik alətlərlə edilir, həm də çox kicik ölçüdəki alətlərin uşaqlıq yoluna yerləşdirilməsinə imkan verir. Bu yeniliklərin gətirdiyi imkanlarla otaq şəraitində edilən hisoeroskopiya zamanı kiçik poliplər və ya uşaqlıqda qalan və ucu görünməyən spiralları çixarmaq mümkündür. Beləliklə, xəstələr daha rahat, daha az riskli və daha az xərclə otaq şəraitində edilən hisoeroskopiyanı rahatlıqla seçə bilərlər.</span></p>\n<p><span style="color: #000000;">Millimetr fərqlə daha qalın olan əməliyyat (cərrahi) histeroskopiyasının da iş mexanizmi diaqnostik histeroskopiya ilə eyni şəkildədir. Bununla birlikdə, operativ histeroskopiyada cərrahi tətbiq üçün lazım olan kiçik alətlərin istifadəsinə imkan yaradan girişlər var. Bu kiçik alətlər vasitəsilə daha böyük miyomalar və poliplər çıxarılaraq müalicə olunur.</span></p>\n<p>&nbsp;</p>\n<p><span style="color: #000000; font-size: 18px;"><strong>HİSTEROSKOPİYA PROSEDURU İLƏ BAĞLI TEZ-TEZ VERİLƏN SUALLAR</strong></span></p>\n<p><span style="color: #000000; font-size: 18px;"><strong>Diaqnostik histeroskopiya nədir?</strong></span></p>\n<p><span style="color: #000000;">Diaqnostik histeroskopiya uşaqlıqdakı lezyonları və ya doğuşdan gələn anormallıqları təyin etmək üçün; cərrahi histeroskopiya isə prosedur zamanı görülən lezyon və ya anormallıqların götürülməsi üçün isitifadə edilir.</span></p>\n<p>&nbsp;</p>\n<p><span style="color: #000000; font-size: 18px;"><strong>Histeroskopiya nə vaxt edilə bilər?</strong></span></p>\n<p><span style="color: #000000;">Mensturasiyadan dərhal sonra uşaqlıq qalınlaşmağa başladığı üçün yaranan qalınlıq bəzi patologiyaların görülməsinin qarşısını ala bilər və bu da histeroskopiyadan doğru nəticə əldə edilməməsinə səbəb ola bilər. Bu səbəblə histeroskopiya proseduru daha çox menstruasiya bitdikdən bir həftə sonra edilir.</span></p>\n<p>&nbsp;</p>\n<p><span style="color: #000000; font-size: 18px;"><strong>Hansı hallarda histeroskopiya edilir?</strong></span></p>\n<p><span style="color: #000000;">İlk öncə xəstə bir ginekoloq və ya mama ginekoloq tərəfindən müayinə edilməlidir. Ultrasəs müayinədən sonra hər hansı bir lezyon və ya patologiyadan şübhələnildiyi zaman histeroskopiya edilməsinə qərar verilir. Histeroskopiya birbaşa edilən bir prosedur deyil.</span></p>\n<p>&nbsp;</p>\n<p><span style="color: #000000; font-size: 18px;"><strong>Bu prosedur üçün kimlər uyğundur?</strong></span></p>\n<p><span style="color: #000000;">Bu prosedur müayinə kimi qəbul edilməməlidir. Polip və miomalar zamanı, həddindən artıq çox qanaxma hallarında, uşaqlıqdakı yapışqanlıqlar zamanı, uşaqlıqda olan pərdə zamanı, uşaqlıqda ucu itən spiralları tapmaq və uşaqlıqda olan anadangəlmə anormallıqlar zamanı bu prosedurdan istifadə edilir. Bununla birlikdə, menopoz sonrası qanaxma olan xəstələrdə və focal lezyonlardan şübhələnilən xəstələrdə də histeroskopiya edilə bilər.</span></p>\n<p>&nbsp;</p>\n<p><span style="color: #000000; font-size: 18px;"><strong>Histeroskopiya edəcək xəstələr nələrə nələrə diqqət etməlidir?</strong></span></p>\n<p><span style="color: #000000;">Bu proseduru etmək istəyən qadınlar hamilə olmadıqlarına əmin olmalıdırlar.</span></p>\n<p>&nbsp;</p>\n<p><span style="color: #000000; font-size: 18px;"><strong>Histeroskopiya riskli bir prosedurdur?</strong></span></p>\n<p><span style="color: #000000;">Histeroskopiya çox az riskli prosedurdur.</span></p>\n<p>&nbsp;</p>\n<p><span style="color: #000000; font-size: 18px;"><strong>Histeroskopiyadan sonra nələrə diqqət yetirilməlidir?</strong></span></p>\n<p><span style="color: #000000;">Histeroskopiya əməliyyatından sonra bir həftə və ya 10 gün ərzində cinsi əlaqədən çəkinmək lazımdır.</span></p>\n<p>&nbsp;</p>\n<p><span style="color: #000000; font-size: 18px;"><strong>Histeroskopiyadan sonra qanaxma olabilərmi?</strong></span></p>\n<p><span style="color: #000000;">Histeroskopiyadan sonra ləkələnmə şəklində qanaxma görünə bilər. Eyni zamanda yüngül qasıq ağrısı da ola bilər. Bu şikayətlər növbəti 2-3 gün ərzində keçir. Ancaq prosedurdan sonra ağrı və yüksək tempratur olarsa həkimə müraciət edilməlidir.</span></p>\n<p>&nbsp;</p>\n<p><span style="color: #000000; font-size: 18px;"><strong>Histeroskopiya prosedurunun üstünlükləri nələrdir?</strong></span></p>\n<p><span style="color: #000000;">Histeroskopiyanın ən böyük üstünlüyü, təbii olaraq vaginal yoldan edildiyi üçün uşaqlığın içərisini heç bir kəsik olmadan incələməyin mümkün olmasıdır. Prosedur günü xəstəxanadan çıxan xəstələr çox qısa müddətdə gündəlik həyatlarına qayıda bilərlər. Bununla birlikdə, xəstələr əlavə bir kəsik olmadan mioma və polip kimi lezyonlardan xilas ola bilərlər.</span></p>\n<p>&nbsp;</p>\n<p><span style="color: #000000; font-size: 18px;"><strong>Histeroskopiya ağrılı prosedurdur?</strong></span></p>\n<p><span style="color: #000000;">Histeroskopiya çox ağrılı bir prosedur deyil. Diaqnostik histeroskopiya hətta ağrıya dözümlü olan xəstələrdə anesteziya olmadan da həyata keçirilə bilər. Eyni zamanda xəstələr əvvəlcədən ağrı kəsici ilə premedikasiya edilə bilər. Cərrahi histeroskopiya anesteziya ilə aparıldığı üçün ümumiyyətlə ağrı olmur.</span></p>\n<p>&nbsp;</p>\n<p><span style="color: #000000; font-size: 18px;"><strong>Histeroskopiya təhlükəsiz prosedurdur? </strong></span></p>\n<p><span style="color: #000000;">Histeroskopiya təhlükəsiz bir prosedurdur. Lakin əməliyyat zamanı cərrah vaxta diqqət etməli və əməliyyat müddətini normaldan çox uzatmamalıdır. Zəruri hallarda lezyonu aradan qaldırmaq üçün histeroskopiya bir neçə dəfə təkrar edilməli bir dəfəyə çıxarılmamalıdır. Çünki uzunmüddət davam edən histeroskopiya zamanı istifadə olunan maye səbəbilə istənməyən vəziyyətlər yarana bilər. Xəstələr əməliyyata girmədən öncə bilməlidirlər ki,yarana biləcək komplikasiyaları azaltmaq üçün bəzi hallarda histeroskopik əməliyyatlar tək bir seansda edilə bilməz, bəzən bir neçə seans tələb oluna bilər.</span></p>\n<p><span style="color: #000000; font-size: 18px;"><strong>Histeroskopiyadan sonra hamiləlik şansı artırmı?</strong></span></p>\n<p><span style="color: #000000;">Əgər uşaqlıqda lezyon yoxdursa histeroskopiya hamiləliyə təsir göstərmir. Hamiləlik açılmalarına səbəb olan poliplərin, uşaqlıq miomasının götürülməsi və ya hamiləlik açılışına səbəb olan bir digər problem uşaqlıq pərdəsini histeroskopiya ilə kəsilməsi ilə normal hamiləlik şansı artırıla bilər.</span></p>\n<p>&nbsp;</p>\n<p><span style="color: #000000; font-size: 18px;"><strong>Histeroskopiyada istifadə olunan mayenin tərkibi nədir? </strong></span></p>\n<p><span style="color: #000000;">Diaqnostik histeroskopiyada daha çox sistemlər zamanı vurulan ringerdən istifadə edildiyi halda, cərrahi histeroskopiya zamanı tərkibində elektrolit olmayan mayelərdən istifadə olunur. Hansı mayenin istifadə ediləcəyi histeroskopun bipolyar və ya monopolyar elektrik enerjisindən hansını istifadə etdiyinə görə dəyişir.</span></p>\n<p>&nbsp;</p>\n<p><span style="color: #000000; font-size: 18px;"><strong>Histeroskopiya nə qədər vaxt aparır?</strong></span></p>\n<p><span style="color: #000000;">Diaqnostik histeroskopiya prosesi bir neçə dəqiqə, cərrahi histeroskopiya isə əməliyyat prosedurundan asılı olaraq 5-20 dəqiqə arasında dəyişilir.</span></p>\n<p>&nbsp;</p>\n<p><span style="color: #000000; font-size: 18px;"><strong>Qövslü uşaqlıq nədir?</strong></span></p>\n<p><span style="color: #000000;">Qövslü uşaqlıq, uşaqlığın yuxarı hissəsinin daxilə doğru çökək olmağı halıdır. Qövslü uşaqlığının diaqnozu ultrasəs müayinə, MRI, histeroskopiya və laparoskopiya ilə edilə bilər.</span></p>\n<p>&nbsp;</p>\n<p><span style="color: #000000; font-size: 18px;"><strong>Histeroskopiyadan sonra menstrual qanaxmalarda nizamsızlıq olablərmi?</strong></span></p>\n<p><span style="color: #000000;">Histeroskopiyadan sonra menstruasiya qanaması zamanı nizamsızlıq gözlənilmir. Yalnız prosedurdan sonrakı ilk mensturasiyanın zamanı dəyişə bilər.</span></p>\n<p>&nbsp;</p>\n<p><span style="color: #000000; font-size: 18px;"><strong>Histeroskopiyadan nə qədər sonra hamilə qalmaq olar?</strong></span></p>\n<p><span style="color: #000000;">Diaqnostik histeroskopiyadan sonra gözləmək üçün əlavə vaxta ehyiyyac yoxdur və prosedurdan sonra dərhal hamiləlik planlamaq mümkündür. Cərrahi histeroskopiyadan sonra edilən prosedura bağlı olaraq ən çox 3 ay gözlədikdən sonra hamiləlik planlamaq olar.</span></p>\n<p>&nbsp;</p>\n<p><span style="color: #000000; font-size: 18px;"><strong>Histeroskopiya ilə edilən uşaqlıqda polip əməliyyatı nə qədər davam edir?</strong></span></p>\n<p><span style="color: #000000;">Poliplərin histereskopik rezeksiyası təxminən 5-10 dəqiqə çəkir.</span></p>\n<p>&nbsp;</p>\n<p><span style="color: #000000; font-size: 18px;"><strong>Histeroskopiya ilə polip əməliyyatından sonra təkrarlanma riski varmı?</strong></span></p>\n<p><span style="color: #000000;">Poliplərin təkrarlanma ehtimalı yüksəkdir. Təkrarlanma riski histeroskopiya ilə əlaqəli deyil. Xəstədə polip meydana gəlməsinə təsir edən şərtlər davam etdikcə, yenidən polip inkişaf edə bilər.</span></p>', 'histeroskopiyanedir-1619546245.jpg', 2, 1),
(4, '', '', 'Pap Smear testi nədir?', '', '', 'Pap Smear testi uşaqlıq boynu xərçəgi və xərçəngönü xəstəliklərinin erkə diaqnostikası üçün həyata keçirilən bir testdir. Pap smear testi prekanseröz və ya xərçəngli lezyonların hələ müalicə oluna biləcəyi mərhələlərdə aşkara çıxarılmasına imkan verir.', '', '', '<p><span style="font-size: 16px;">Pap Smear testi uşaqlıq boynu xərçəgi və xərçəngönü xəstəliklərinin erkə diaqnostikası üçün həyata keçirilən bir testdir. Pap smear testi prekanseröz və ya xərçəngli lezyonların hələ müalicə oluna biləcəyi mərhələlərdə aşkara çıxarılmasına imkan verir.</span></p>\n<p>&nbsp;</p>\n<p align="center"><span style="font-size: 18px;"><strong>PAP SMEAR TESTİ NƏDİR? TEST NECƏ EDİLİR?</strong></span></p>\n<p><span style="font-size: 16px;">Uşaqlıq boynu xərçəngi qadınlardakı xərçəng xəstəliyi arasında 6-cı sırada, ölüm səbəbi olan<iframe allowFullScreen="allowFullScreen" src="http://www.youtube.com/embed/MIHgInNRKHc" frameborder="0" align="right" width="425" height="350"></iframe> xərcənglər arasında isə 10-cu sıradadır. Cinsi əlaqəyə erkən yaşda başlamaq,cinsi partnyorların çoxluğu, sosial-iqtisadi səviyyənin aşağı olmağı, HPV infeksiyası, A vitamini səviyyəsinin aşağı olmağı və siqaret çəkmək uşaqlıq boynu xərçəngi riskini artıran amillərdəndir. Smear testi (Pap smear) uşaqlıq boynu xərçənginin müayinəsi üçün istifadə olunan və bir çox ölkədə istifadə edilən sadə bir testdir.</span></p>\n<p>&nbsp;</p>\n<p><span style="font-size: 18px;"><strong>MÜNDƏRİCAT</strong></span></p>\n<p><span style="font-size: 18px;"><strong>&bull; Pap smear testi nədir?</strong></span></p>\n<p><span style="font-size: 18px;"><strong>&bull; Pap smear testi necə edilir?</strong></span></p>\n<p><span style="font-size: 18px;"><strong>&bull; Pap smear testi etdirməyə nə vaxt başlamaq lazımdır?</strong></span></p>\n<p><span style="font-size: 18px;"><strong>&bull; Pap smear testini hansı hallarda təkrarlamağa ehtiyyac yoxdur?</strong></span></p>\n<p><span style="font-size: 18px;"><strong>&bull; Pap smear testinin nəticəsi necə dəyərləndirilir?</strong></span></p>\n<p><span style="font-size: 18px;"><strong>&bull; HPV peyvəndi edildiyi halda smear testinə ehtiyyac varmı?</strong></span></p>\n<p><span style="font-size: 18px;"><strong>&bull; Pap smear testinin nəticəsi şübhəli olduqda başqa testlərə ehtiyyac varmı?</strong></span></p>\n<p><span style="font-size: 18px;"><strong>&bull; Smear testinin nəticəsi normal olmayan xəstələr necə müalicə olunur?</strong></span></p>\n<p><span style="font-size: 18px;"><strong>&bull; Uşaqlıq boynu xərçəngi nədir?</strong></span></p>\n<p><span style="font-size: 18px;"><strong>&bull; Uşaqlıq boynu xərçənginin qarşısını almaq olarmı?</strong></span></p>\n<p><span style="font-size: 18px;"><strong>&bull; Uşaqlıq boynu xərçənginin əlamətləri hansılardır?</strong></span></p>\n<p>&nbsp;</p>\n<p><span style="font-size: 16px;"><strong>Pap smear testi nədir?</strong></span></p>\n<p><span style="font-size: 16px;">Pap smear (Pap test) qadınlarda uşaqlıq boynu xərçəngi (serviks) və ya prekanser (xərçəng öncəsi) müayinəsində istifadə edilən metoddur. Pap smear xərçəng öncəsi və ya xərçəngli lezyonları müalicə ediləbilən mərhələlərdə diaqnozun qoyulmağına kömək edən testdir.</span></p>\n<p>&nbsp;</p>\n<p>&nbsp;</p>\n<p><span style="font-size: 16px;"><strong>Pap smear testi necə edilir?</strong></span></p>\n<p><span style="font-size: 16px;">Pap smear testi sadə və ağrısızdır. Test mensturasiya zamanı edilməməlidir. Test üçün ən yaxşı vaxt menstruasiyadan 10-20 gün sonrasıdır.</span></p>\n<p><span style="font-size: 16px;">Əvvəlcə uşaqlıq boynunun rahat görülməyi üçün vaginaya müayinə aləti yerləşdirilir. Daha sonra kiçik bir fırça ilə uşaqlıq boynundan hüceyrə nümunələri yığılır və bu hüceyrələr şüşə üzərinə yayılır. Götürülmüş hüceyrələr patoloq tərəfindən mikroskop altında müayinə edilərək hər hansı bir anormal inkişafın var olub olmadığı yoxlanılır. Testin əsas məqsədi xərçəngi aşkarlamaqla bərabər, xərçəngə çevrilmə potensialı olan və müalicə ediləbilən "prekanseröz" lezyonların aşkar edilməsidir.Testin nəticələrinin müsbət olduğu hallarda (yəni anormal hüceyrələr aşkar edildiyi zaman) həkim HPV testi vəya kolposkopiya edilməsini tələb edə bilər.</span></p>\n<p><span style="font-size: 16px;">Pap smear testi edəcəyiniz gündən əvvəl:</span></p>\n<p>&nbsp;</p>\n<ul>\n<li>\n<p><span style="font-size: 16px;">48 saat ərzində cinsi əlaqədə olmamalı</span></p>\n</li>\n<li>\n<p><span style="font-size: 16px;">vagina yuyulmamalı</span></p>\n</li>\n<li><span style="font-size: 16px;">vaginanın içərisinə heç bir dərman və ya krem ​​tətbiq edilməməlidir.</span></li>\n</ul>\n<p><span style="font-size: 16px;">Cinsiyyət orqanında infeksiya olduğu hallarda müalicə olunmalı və daha sonra pap smear testi edilməlidir.</span></p>\n<p>&nbsp;</p>\n<p><span style="font-size: 16px;"><strong>Pap smear testi etdirməyə nə vaxt başlamaq lazımdır?</strong></span></p>\n<p><span style="font-size: 16px;">Uşaqlıq boynu xərçənginin müayinəsi zamanı həyata keçirilən Pap smear testi erkən diaqnoz üçün çox vacibdir. Ümumiyyətlə cinsi həyatı olan qadınlara Pap smear testindən keçmək məsləhət görülür. Uşaqlıq boynunun skrininqi &ndash; müayinəsi üçün 25 yaşdan etibarən Pap smear testi həyata keçirilə bilər. Bu testin 3 ildən bir edilməsi tövsiyyə olunur. Uşaqlıq boynu xərçənginin skrininqi üçün həyata keçirilən digər testlərdən biri olan HPV testi isə 5 ildən bir həyata keçirilir.</span></p>\n<p>&nbsp;</p>\n<p><span style="font-size: 16px;"><strong>Pap smear testini hansı hallarda təkrarlamağa ehtiyyac yoxdur?</strong></span></p>\n<p><span style="font-size: 16px;">ü Xoş xassəli şiş zamanı Total Laparoskopik Histerektomiya (Uşaqlığın çıxarılması) əməliyyatı etdirənlər</span></p>\n<p><span style="font-size: 16px;">ü Servikal lezyon olduğu və 3 smear testi nəticəsi mənfi olduğu halda Histerektomiya (Uşaqlığın çıxarılması) əməliyyatı etdirənlər</span></p>\n<p><span style="font-size: 16px;">ü Son 10 ildə 3 dəfə mənfi smear testi keçirmiş 70 yaşdan yuxarı qadınlar</span></p>\n<p>&nbsp;</p>\n<p>&nbsp;</p>\n<p><span style="font-size: 16px;"><strong>Pap smear testinin nəticəsi necə dəyərləndirilir?</strong></span></p>\n<p><span style="font-size: 16px;">Pap smear testinin nəticələrini dəyərləndirmə zamanı Bethesta sistemindən istifadə edirlər.</span></p>\n<p><span style="font-size: 16px;"><strong>Negativ:</strong> Pap smear testində heç bir anormal, prekanseröz və ya xərçəng hüceyrəsi aşkarlanmadığı zaman (intraepitelyal lezyon və ya malignite negtiv)</span></p>\n<p><span style="font-size: 16px;"><strong>Anormal nəticələr:</strong> Smear testində servikal hüceyrələrin anormal olmasının bir çox səbəbi ola bilər. Servikal infeksiyalar və ya prekanseröz hüceyrələr anormal hüceyrələrin görünməsinə səbəb ola bilər.</span></p>\n<p><span style="font-size: 16px;">Anormal bir nəticə olduğu halda infeksiya müalicəsi və / və ya xəstənin davamlı izlənilməsi və / və kolposkopiya + biopsiya tövsiyə edilə bilər.</span></p>\n<p><span style="font-size: 16px;">Bütün testlərdə olduğu kimi, Pap smear testinin də səhv çıxma ehtimalı var. Testin müntəzəm olaraq təkrar edilməsi səhv nəticə ehtimalını azaldır.</span></p>\n<p>&nbsp;</p>\n<p><span style="font-size: 16px;"><strong>HPV peyvəndi edildiyi halda smear testinə ehtiyyac varmı?</strong></span></p>\n<p><span style="font-size: 16px;">HPV virusunun bir çox fərqli növü var. Peyvənd sadəcə bəzi növlərə qarşı təsirlidir. Ən çox yayılmış növlər 6-11-16-18 peyvəndin təsir etdiyi növlərdəndir. Nadir hallarda digər növlərlə birlikdə lezyonlar meydana gələ bilər. Bu səbəblə, peyvənd olunmuş insanlara da Pap smear testi edilməlidir.</span></p>\n<p>&nbsp;</p>\n<p><span style="font-size: 16px;"><strong>Pap smear testinin nəticəsi şübhəli olduqda başqa testlərə ehtiyyac varmı?</strong></span></p>\n<p><span style="font-size: 16px;">Pap smear testi yoxlama xarakteri daşıdığı üçün şübhəli nəticə olduğu zaman kolposkopiya, biopsiya və servikal küretaj tələb oluna bilər. Kolposkopiya spekulum istifadə edərək vaginanın genişləndirilməsi və vaginayla serviksin yuxarı hissəsinin mikroskop köməyi ilə ətraflı incələnməsinə deyilir. Bu prosedurdan əvvəl xəstədən HPV testi etdirməsi istənilə bilər. Kolposkopiya zamanı servikste anormal bölgələr aşkar edildiyi halda biopsiya edilə bilər. Alınan biopsiya müayinə üçün patoloqa göndərilir.</span></p>\n<p>&nbsp;</p>\n<p><span style="font-size: 16px;"><strong>Smear testinin nəticəsi normal olmayan xəstələr necə müalicə olunur?</strong></span></p>\n<p><span style="font-size: 16px;">Kolposkopiya zamanı şübhəli hissələr dondurularaq və ya lazerlə çıxardılır. Bu müalicələr prekanseröz simptomları aradan qaldırmaq və xərçəngin qarşısını almaq üçün təsirlidir. Bu prosseslərdən sonra xəstə mütəmadi olaraq izlənilir.</span></p>\n<p>&nbsp;</p>\n<p><span style="font-size: 16px;"><strong>Uşaqlıq boynu xərçəngi nədir?</strong></span></p>\n<p><span style="font-size: 16px;">Uşaqlıq boynu xərçənginin (və ya serviks xərçəngi) harada yerləşdiyini anlamaq üçün uşaqlıq boynu haqqında məlumata sahib olmaq lazımdır. Serviks uşaqlığın aşağı hissəsinə verilən addır. Uşaqlıq və vaginanı birləşdirmə funksiyasını yerinə yetirir. Uşaqlıq boynu xərçəngi birdən-birə əmələ gəlmir. Sonradan xərçəngə çevrilmə ehtimalı olan bəzi xərçəngöncəsi dəyişikliklərdən sonra və əsasən də illər sonra ortaya çıxır. Bu prekanseröz dəyişikliklər üçün CIN (servikal intraepital neoplaziya) və ya skuamöz intraepital lezyon terminləri istifadə olunur. Qadınların çoxunda prekanseröz dəyişikliklər yox olur və ya heç vaxt xərçəngə çevrilmir. Bununla birlikdə, müalicə edildiyi zaman bütün uşaqlıq boynu xərçənglərinin qarşısının alınması mümkündür.</span></p>\n<p><span style="font-size: 16px;">Uşaqlıq boynu xərçəngi qadınlarda xərçəng ölümlərinin əsas səbəblərindən biridir. Bu xərçəngin müayinəsində istifadə olunan pap smear testinin tanınması və qadınlar tərəfindən mütəmadi edilməsi uşaqlıq boynu xərçəngindən ölüm hadisələrini əhəmiyyətli dərəcədə azalda bilər.</span></p>\n<p><span style="font-size: 16px;">Pap smear testinin davamlı olaraq istifadə edilmədiyi ölkələrdə servikal xərçənglərin faizi hələ də çox yüksəkdir. Uşaqlıq boynu xərçəngi müntəzəm müayinələr edilərək qarşısı alınabilən yeganə qadın ginekoloji xərçəngidir. Pap smear testi ilə serviksdə hələ xərçəngə çevrilməmiş, lakin prekanseroz(xərçəng öncəsi) hüceyrələr aşkar edilir.</span></p>\n<p><span style="font-size: 16px;">Uşaqlıq boynu xərçənginə orta hesabla 35-55 yaş arası qadınlarda daha çox rast gəlinir. 20 yaşdan aşağı qadınlarda çox nadir rast gəlinəbilər. Ancaq xəstəlik 65 yaşdan yuxarı qadınlarda da aşkar edildiyi üçün 70 yaşına qədər cinsi əlaqədə olan bütün qadınlar üçün müntəzəm Pap smear testi etdirmələri tövsiyə olunur. Uşaqlıq boynu xərçəngi olan bütün qadınların demək olar ki hamısında HPV virusu aşkar olunur. Bu virus cinsi yolla ötürülür. Bu virusa qarşı peyvənd mövcuddur.</span></p>\n<p><span style="font-size: 16px;">Serviks (uşaqlıq boynu xərçəngi) və lezyonları üçün risk faktorları nələrdir:</span></p>\n<ul>\n<li><span style="font-size: 16px;">Yuxarı yaş faktoru</span></li>\n<li><span style="font-size: 16px;">İrq (qara dərili qadınlar yüksək risk daşıyıcılarıdır)</span></li>\n<li><span style="font-size: 16px;">Asiya, Afrika və Latın Amerika mənşəli qadınlar</span></li>\n<li><span style="font-size: 16px;">Sosial-iqtisadi vəziyyətin aşağı olması</span></li>\n<li><span style="font-size: 16px;">Təhsil səviyyəsinin aşağı olması</span></li>\n<li><span style="font-size: 16px;">Özünün və ya qarşı tərəfin cinsi partnyorunun çoxluğu</span></li>\n<li><span style="font-size: 16px;">Erkən ilk cinsi əlaqə</span></li>\n<li><span style="font-size: 16px;">Siqaret çəkmək</span></li>\n<li><span style="font-size: 16px;">Hamiləlikdən qorunma həblərinin uzun müddətli istifadəsi</span></li>\n<li><span style="font-size: 16px;">Fol turşusu, A vitamini və C vitamininin azlığı</span></li>\n<li><span style="font-size: 16px;">Çox hamiləlik yaşamaq</span></li>\n<li><span style="font-size: 16px;">İlk hamiləliyin erkən yaşda olması</span></li>\n<li><span style="font-size: 16px;">Cinsi yolla keçirilən herpes virusu və HPV virusunun olması</span></li>\n<li><span style="font-size: 16px;">HİV infeksiyası</span></li>\n<li><span style="font-size: 16px;">Ana bətndə estrogen hormonuna məruz qalmaq</span></li>\n<li><span style="font-size: 16px;">Smear testini mütəmadi təkrarlamamaq</span></li>\n<li><span style="font-size: 16px;">İmmunitet çatışmazlığı</span></li>\n<li><span style="font-size: 16px;">Ana və ya bacıda serviks xərçəngi olmağı</span></li>\n<li><span style="font-size: 16px;">Meyvə və tərəvəzlərın az yeyilməsi</span></li>\n<li><span style="font-size: 16px;">Artıq çəki</span></li>\n</ul>\n<p><span style="font-size: 16px;"><strong>Uşaqlıq boynu xərçənginin qarşısını almaq olarmı?</strong></span></p>\n<p><span style="font-size: 16px;">Uşaqlıq boynu xərçəngi, bəzi risk faktorlarının nəzarət altında saxlanılması, pap smear testinin mütəmadi edilməsi və çox yayılmış HPV viruslarına qarşı peyvənd olunmaqla qarşısı alınabilən xərçəng növlərindən biridir.</span></p>\n<p><span style="font-size: 16px;">Bu xərçəngdən qorunmaq üçün risk faktorlarını yaxşı bilmək, mütəmadi olaraq müayinələrə getmək və smear testi etdirmək lazımdır. Bu testlər heç bir əlamət göstərməyən xərçəng xəstəliyinin diaqnoz edilməsi üçün istifadə olunur. Uşaqlıq boynu xərçənginin aşkar edilməsi üçün müayinələr son dərəcə vacibdir. Uşaqlıq boynu xərçənginin erkən diaqnoz etməyin ən yaxşı yolu müntəzəm olaraq pap smear testi etdirməkdir.</span></p>\n<p><span style="font-size: 16px;">Uşaqlıq boynu xərəçənginə qarşı görüləcək tədbirlər arasında:</span></p>\n<ul>\n<li><span style="font-size: 16px;">siqareti atmaq</span></li>\n<li><span style="font-size: 16px;">çox erkən cinsi əlaqədən qaçınmaq cinsi əlaqə zamanı prezervativ istifadə etmək</span></li>\n<li><span style="font-size: 16px;">kilolu olmamaq</span></li>\n<li><span style="font-size: 16px;">doğru bəslənmək</span></li>\n<li><span style="font-size: 16px;">cinsi partnyorların sayını azaltmaq kimi yaşam şəklinə diqqət etmək lazımdır.</span></li>\n</ul>\n<p>&nbsp;</p>\n<p><span style="font-size: 16px;"><strong>U</strong><strong>ş</strong><strong>aql</strong><strong>ı</strong><strong>q</strong><strong> </strong><strong>boynu</strong><strong> </strong><strong>x</strong><strong>ə</strong><strong>r</strong><strong>çə</strong><strong>nginin</strong><strong> </strong><strong>ə</strong><strong>lam</strong><strong>ə</strong><strong>tl</strong><strong>ə</strong><strong>ri</strong><strong> </strong><strong>hans</strong><strong>ı</strong><strong>lard</strong><strong>ı</strong><strong>r</strong><strong>?</strong></span></p>\n<p><span style="font-size: 16px;">Prekanseroz lezyonların heç bir əlaməti olmur. Bu vəziyyət pap smear testinin nə qədər vacib olduğunu göstərir. Xəstəlik xərçəngə çevrildikdən sonra artıq simptomlar özünü göstərməyə başlayır.</span></p>\n<ul>\n<li><span style="font-size: 16px;">Qanlı, pis qoxulu vaginal axıntı</span></li>\n<li><span style="font-size: 16px;">Cinsi əlaqə zamanı və ya iki menstruasiya arasında meydana gələn anormal qanamalar</span></li>\n<li><span style="font-size: 16px;">Uzun müddətli menstruasiya qanamasıCinsi əlaqə zamanı ağrı hissi əsas əlamətlər arasındadır.</span></li>\n</ul>\n<p><span style="font-size: 16px;">Mütəmadi olaraq edilən smear testləri servikal xərçəngin qarşısını almaq üçün böyük əhəmiyyət daşıyır.</span></p>', 'smeartesti-1619546487.jpg', 3, 1);



-- ---------------------------------------------------------
--
-- Table structure for table : `money_balance`
--
-- ---------------------------------------------------------

CREATE TABLE `money_balance` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cash_desk_id` int(11) NOT NULL,
  `sold_to_user_id` int(11) NOT NULL,
  `sold_program_id` int(11) NOT NULL,
  `client_name` varchar(255) NOT NULL,
  `amount` int(11) NOT NULL,
  `period` int(11) NOT NULL,
  `payment_type` tinyint(1) NOT NULL COMMENT '0=>income,1=>out',
  `note` varchar(255) NOT NULL,
  `datetime` int(11) NOT NULL,
  `admin_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;



-- ---------------------------------------------------------
--
-- Table structure for table : `namaz_time`
--
-- ---------------------------------------------------------

CREATE TABLE `namaz_time` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `subh` varchar(255) NOT NULL,
  `gun` varchar(255) NOT NULL,
  `zohr` varchar(255) NOT NULL,
  `esr` varchar(255) NOT NULL,
  `megrib` varchar(255) NOT NULL,
  `isha` varchar(255) NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `namaz_time`
--

INSERT INTO `namaz_time` (`id`, `subh`, `gun`, `zohr`, `esr`, `megrib`, `isha`, `date`) VALUES
(1, '05:15', 'aaa', '13:45', '', '21:36', '00:46', '2013-07-06');



-- ---------------------------------------------------------
--
-- Table structure for table : `news`
--
-- ---------------------------------------------------------

CREATE TABLE `news` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `datetime` int(11) NOT NULL,
  `name_en` varchar(255) NOT NULL,
  `name_ru` varchar(255) NOT NULL,
  `name_az` varchar(255) NOT NULL,
  `keywords_en` varchar(255) NOT NULL,
  `keywords_ru` varchar(255) NOT NULL,
  `keywords_az` varchar(255) NOT NULL,
  `short_text_en` varchar(500) NOT NULL,
  `short_text_ru` varchar(500) NOT NULL,
  `short_text_az` text NOT NULL,
  `full_text_en` text NOT NULL,
  `full_text_ru` text NOT NULL,
  `full_text_az` text NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `read_count` int(11) NOT NULL DEFAULT 0,
  `comment_count` int(11) NOT NULL DEFAULT 0,
  `flash` tinyint(1) NOT NULL,
  `active` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `kateqoriya` (`category_id`)
) ENGINE=MyISAM AUTO_INCREMENT=41 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `news`
--

INSERT INTO `news` (`id`, `category_id`, `author_id`, `datetime`, `name_en`, `name_ru`, `name_az`, `keywords_en`, `keywords_ru`, `keywords_az`, `short_text_en`, `short_text_ru`, `short_text_az`, `full_text_en`, `full_text_ru`, `full_text_az`, `image`, `read_count`, `comment_count`, `flash`, `active`) VALUES
(4, 0, 0, 1581933963, '', '', 'KOLPOSKOPİYA NƏDİR? NƏ ZAMAN KOLPOSKOPİYA EDİLƏ BİLƏR?', '', '', '', '', '', 'Uşaqlıq boynunun, yəni serviksin müayinəsində istifadə edilən (qeyri-invaziv) üsul olan "kolposkopiya" 1900-cü illərin əvvəllərindən etibarən tətbiq olunmağa başlamışdır. Kolposkopiya nədir? Kolposkopiya proseduru nə qədər davam edir? Kolposkopiya nəticəsinə əsasən biopsiya edildikdə cavab dərhal çıxa bilərmi? Nəyə görə kolposkopiya edilir? Kolposkopiya ağrılı prosedurdurmu? Kolposkopiya zamanı anesteziyaya ehtiyyac varmı? Kolposkopiya üçün göstəricilər hansılardır? Hamiləlik zamanı kolposkopiya edilə bilərmi? kimi ən çox maraqlanılan sualların cavabını məqaləmizdə tapa biləcəksiniz.', '', '', '<p><br /><span><span>Uşaqlıq boynunun, yəni serviksin müayinəsində istifadə edilən (qeyri-invaziv) üsul olan "kolposkopiya" 1900-cü illərin əvvəllərindən etibarən tətbiq olunmağa başlamışdır. Kolposkopiya nədir? Kolposkopiya proseduru nə qədər davam edir? Kolposkopiya nəticəsinə əsasən biopsiya edildikdə cavab dərhal çıxa bilərmi? Nəyə görə kolposkopiya edilir? Kolposkopiya ağrılı prosedurdurmu? Kolposkopiya zamanı anesteziyaya ehtiyyac varmı? Kolposkopiya üçün göstəricilər hansılardır? Hamiləlik zamanı kolposkopiya edilə bilərmi? kimi ən çox maraqlanılan sualların cavabını məqaləmizdə tapa biləcəksiniz.<br /><br /></span><strong><span>Mündəricat</span></strong></span></p>\n<ul>\n<li><span><strong><span>Kolposkopiya nədir?</span></strong></span></li>\n<li><span><strong><span>Kolposkopiya hansı xəstəliklər zamanı edilir?</span></strong></span></li>\n<li><span><strong><span>Kolposkopiya ilə bağlı tez-tez verilən suallar<br /><br /></span></strong><strong>KOLPOSKOPİYA NƏDİR?</strong></span></li>\n</ul>\n<p><span>Kolposkopiya həkimlərə uşaqlıq boynunu müayinə etməyə imkan verən qeyri-invaziv bir üsuldur. Uşaqlıq boynunu 6-40 dəfə daha böyük göstərəbilən kolposkop adlı işıqlı alət ilə serviksi daha aydın şəkildə görmək və daha dəqiq qiymətləndirmək mümkündür.</span></p>\n<p><span>Kliniki prosedur olan kolposkopiya metodunda istifadə edilən kolposkop işıqlı lupadan ibarət olan və durbinə bənzəyən bir alətdir. Adi qaydada edilən ginekoloji müayinənin kolposkopiya metodu ilə böyüdərək edilməsi başda uşaqlıq boynu xərçənginin aşkar edilməsi və eyni zamanda vaginanın da dəqiq müayinəsinə imkan verir.</span></p>\n<p><span><span>Kolposkopiya müayinəsi zamanı şübhəli bir şey nəzərə çarpdığı zaman kolposkopik biopsiya edilərək şübhəli bölgənin incələnməsi mümkündür.<br /><br /></span><strong>KOLPOSKOPİYA HANSI XƏSTƏLİKLƏR ZAMANI İSTİFADƏ OLUNUR?</strong></span></p>\n<p><span>Kolposkopiya uşaqlıq boynu xərçəngini (serviks xərçəngi) erkən mərhələdə, xüsusilə klinik əlamətlər olmadan aşkar etməyə kömək edir. Kolposkopiya sitologiya nəticələrində və smear testində normadan kənar göstəriciləri olan, HPV testində HPV 16 və ya 18 göstəriciləri müsbət çıxan xəstələrdə isitfadə olunur. Uşaqlıq boynu xərçəngi yavaş irəliləyən xərçəng olduğu üçün ginekoloji müayinələr zamanı baş verən dəyişikliklər kolposkopiya ilə daha dəqiq dəyərləndirilə bilir.</span></p>\n<p><span>Uşaqlıq boynu xərçənginin erkən diaqnozunda həyati rolu olan kolposkopiyanın istifadəsi sadəcə bununla məhdudlaşmır. "Kolposkopiya nə üçün edilir?" sualın əsas cavabı uşaqlıq boynu xərçənginin erkən diaqnozudur. Bununla yanaşı bir çox qadın xəstəliyin təqibində və diaqnozunda da istifadə edilə bilər.</span></p>\n<p><span>"Nəyə görə kolposkopiya edilir?", "Kolposkopiya üçün göstəricilər hansılardır?" və ya "Kolposkopiya nə zaman edilməlidir?" suallarına cavabları aşağıdakı kimi sıralaya bilərik:</span></p>\n<ul>\n<li><span><strong><span>Uşaqlıq boynu xərçənginin diaqnozunda,</span></strong></span></li>\n<li><span><strong><span>Vulvada olan şübhəli lezyonların dəyərləndirilməsi zamanı,</span></strong></span></li>\n<li><span><strong><span>Qadınların cinsiyyət orqanının xarici hissəsi olan vulvada görünən xərçəng öncəsi dəyişikliklərin diaqnozu zamanı,</span></strong></span></li>\n<li><span><strong><span>Vulvada uzun müddət davam edən qaşınmaların səbəbinin araşdırılması zamanı,</span></strong></span></li>\n<li><span><strong><span>Servikal toxumada xərçəng öncəsi yəni hələ xərçəng olmamış amma xərçəngin inkişaf edəbiləcəyi dəyişikliklərin diaqnozu zamanı</span></strong></span></li>\n</ul>\n<p><span>Kolposkopiya, vajinal toxumadakı prekanseröz, yəni xərçəng hələ meydana gəlməmiş, lakin xərçəng inkişaf etdirə bilən dəyişiklikləri təyin etmək üçün edilə bilər.</span></p>\n<p><span>Bunlara əlavə olaraq kolposkopiya aşağıdakı hallarda da edilə bilər:</span></p>\n<ul>\n<li><span><strong><span>hamiləlik dövründə</span></strong></span></li>\n<li><span><strong><span>Sonsuzluğun səbəbinin aşkar edilməsi zamanı</span></strong></span></li>\n<li><span><strong><span>Uşaqlıq boynunda ediləcək hər hansı bir əməliyyatdan əvvəl<br /><br /></span></strong><span><strong>KOLPOSKOPİYA İLƏ BAĞLI TEZ-TEZ VERİLƏN SUALLAR</strong></span></span></li>\n</ul>\n<ul>\n<li><span><strong><span>Kolposkopiyaya hazırlanma prosesi nəcədir?</span></strong></span></li>\n</ul>\n<p>&nbsp;</p>\n<p><span>Kolposkopiya müayinəsi etdirmək qadınlarda qorxu hissi yarada bilər. Kolposkopiya proseduru əslində ağrısız və demək olar ki, risksiz bir prosedur olsa da, qorxular xəstədə narahatlığa səbəb ola bilər. Kolposkopiyanın yaratdığı narahatlığı azaltmaq üçün prosedurla bağlı bütün detalları öyrənmək vacibdir.</span></p>\n<p>&nbsp;</p>\n<ul>\n<li><span><strong>Kolposkopiya proseduru;</strong></span></li>\n<li><span>Dəqiq nəticə əldə etmək üçün aybaşı dövründə kolposkopiya edilmir.</span></li>\n<li><span>Kolposkopiyadan bir vəya iki gün əvvəl cinsi əlaqə olmamalıdır.</span></li>\n<li><span>Kolposkopiyadan bir vəya iki gün əvvəl tampon istifadə edilməməlidir.</span></li>\n<li><span>Kolposkopiyadan əvvəlki iki gün vajina üçün dərmanlardan istifadə edilməməlidir.</span></li>\n<li><span>Kolposkopiyadan əvvəl vajinal duş edilməməlidir.</span></li>\n<li><span>Kolposkopiya prosedurundan əvvəl yalnız həkimin tövsiyə etdiyi ağrıkəsicilərdən istifadə etmək olar.</span></li>\n<li><span><span>Kolposkopiyadan əvvəl yaşanan narahatlığı azaltmaq üçün idman, meditasiya və ya yaxın dostunuzla vaxt keçirərək stresinizi azalda bilərsiniz. Prosedur zamanı musiqi dinləmək və bənzər fəaliyyətlər də yaşana biləcək narahatlığı azalda bilər<br /><br /></span><strong>Kolposkopiya proseduru necə olur?</strong></span></li>\n</ul>\n<p><span>Kolposkopiya klinik şəraitdə edilən prosedurdur.</span></p>\n<p><span>Xəstə, çanaq müayinəsi və yaxma (smear) testi zamanı olduğu kimi ayaqları dəstəkləyən bir masada arxası üstə uzanır.</span></p>\n<p><span>Vajinal divarın açılmasına kömək edən bir spekulum aparatı vajinaya qoyulur və serviksə daha rahat baxılmağına şərait yaradılır.</span></p>\n<p><span>Daha rahat və aydın bir görüntü üçün serviks xüsusi maddə ilə yuyulur.</span></p>\n<p><span>Anormal hüceyrələrin görünməsini asanlaşdıran bu yuma prosesi bəzən yanma hissinə səbəb ola bilər.</span></p>\n<p><span>Kolposkopiya aləti vajinanın bir neçə sm önünə yerləşdirilir. Kolposkopiya aləti xəstəyə toxunmur və vajinaya girmir.</span></p>\n<p><span>Toxumaları 6-40 dəfə böyüdən kolposkopiya cihazı ilə vajinanın iç tərəfi işıqlandırılaraq daha aydın bir görüntü əldə edilir.</span></p>\n<p><span><span>Şübhəli bir lezyonun göründüyü hallarda Kolposkopik biopsiya edilir.<br /><br /></span><strong>Kolposkopik biopsiya necə aparılır?</strong></span></p>\n<p><span>Kolposkopiya müayinəsi zamanı şübhəli toxumalar aşkar edildikdə, biopsiya forsepsli ilə bütün şübhəli lezyonlardan kolposkopik biopsiya edilə bilər.</span></p>\n<p><span>Kolposkopik biopsiya zamanı birdən çox bölgədən biopsiya götürülə bilər.</span></p>\n<p><span><span>Kolposkopik biopsiya aparmaq üçün xüsusi bir alətdən istifadə olunur və alınacaq hissənin ölçüsü patoloji müayinəyə kifayət edəcək böyüklükdə olmalıdır.<br /><br /></span><strong>Kolposkopiya proseduru nə qədər davam edir?</strong></span></p>\n<p><span><span>Kolposkopiya prosedurunun müddəti kolposkopik biopsiyanın edilib edilməyəcəyinə uyğun olaraq dəyişə bilər. Ümumilikdə proses 5 -15 dəqiqə arasında davam edir.<br /><br /></span><strong>Kolposkopiya proseduru ağrılıdırmı?</strong></span></p>\n<p><span>Prosedur zamanı kolposkopiya vajinaya daxil olmadığı üçün ağrı hiss olunmur.</span></p>\n<p><span>Uşaqlıq boynunu açıq tutmaq üçün vajinal spekulumdan istifadə edildiyi üçün vaginada yüngül təzyiq hiss oluna bilər.</span></p>\n<p><span>Daha dəqiq görüntü əldə etmək üçün uşaqlıq boynunun yuyulduğu maddə sancma və ya yanma hissinə səbəb ola bilər.</span></p>\n<p><span>Bununla birlikdə, ağrı, həkimin şübhəli gördüyü və kolposkopik biopsiyaya ehtiyacı duyduğu zaman parçanın alındığı bölgəyə görə də dəyişə bilər.</span></p>\n<p>&nbsp;</p>\n<p><span>Servikal bölgədə sinirlər çox olmadığı üçün bu bölgədə aparılan biopsiyalar ümumiyyətlə ağrılı olmur. Serviks nahiyəsindən biopsiya götürüldüyü zaman xəstə yüngül təzyiq və ağrı hiss edə bilər.</span></p>\n<p><span><span>Vagina və vulvanın aşağı hissəsində aparılan biopsiya ağrıya səbəb ola bilər. Bəzən birdən çox hissədən parça götürülməsinin tələb olunduğu hallarda lokal anesteziya tətbiq oluna bilər.<br /><br /></span><strong>Kolposkopiya və kolposkopik biopsiyanın riskləri nələrdir?</strong></span></p>\n<p><span>Kolposkopiya təhlükəsiz bir üsuldur və təhlükəsiz bir prosedur olduğu üçün də dəfələrlə təkrarlana bilər.</span></p>\n<p><span>Kolposkopik biopsiya zamanı nadir hallarda:</span></p>\n<ul>\n<li><span><strong><span>Qanaxma</span></strong></span></li>\n<li><span><strong><span>İnfeksiya</span></strong></span></li>\n<li><span><strong><span>Yüksək tempratur və ya üşütmə</span></strong></span></li>\n<li><span><strong><span>Vaginadan tünd, sarı və pis qoxulu axıntı</span></strong></span></li>\n<li><span><strong><span>Qarın alt hissəsində ağrı yarana bilər.<br /><br /></span></strong></span></li>\n</ul>\n<p><span><strong><span>K</span></strong><strong>olposkopiyadan sonra qanaxma ola bilərmi?</strong></span></p>\n<p><span><span>Kolposkopiya zamanı kolposkap aləti vaginaya toxunmadığı üçün ağrı və ya qanaxma halları müşahidə olunmur. Lakin, lazım görüldüyü zaman edilən kolposkopiya biopsiyası zamanı yüngül qanaxma yaşana bilər. Qanaxma miqdarı biopsiya ediləcək bölgəyə və biopsiya üçün alınacaq parçaların çoxluğuna görə dəyişə bilər. Kolposkopik biopsiya zamanı baş verən qanaxmalar qısa müddətdə dayandırılabilən sadə qanaxmalar şəklində olur.<br /><br /></span><strong>Kolposkopiyadan sonra axıntılar olabilərmi?</strong></span></p>\n<p><span><span>Kolposkopiya və kolposkopik biopsiyadan sonra axıntı yaşana bilər. Kolposkopiya proseduru zamanı serviksin dəqiq görünməyi və ya biopsiya zamanı kiçik qanaxmaların qarşısını almaq məqsədilə istifadə edilən maye məhsullar daha sonra axıntıya səbəb ola bilər. Kolposkopiyadan sonra axıntılar izlənilməli əgər tünd, sarı rəngli və pis qoxulu axıntı olarsa həkimə müraciət edilməlidir.<br /><br /></span><strong>Kolposkopiyanın nəticəsi dərhal verilirmi?</strong></span></p>\n<p><span><span>Əgər kolposkopik biopsiya edilərsə nəticələrin çıxmağı bir neçə gün gecikə bilər.<br /><br /></span><strong>Hamiləlik zamanı kolposkopiya edilə bilərmi?</strong></span></p>\n<p><span><span>Hamilə xanımlar "Hamiləlik zamanı kolposkopiya edilə bilərmi?&rdquo; sualının tez-tez soruşurlar. Kolposkopiya tamamilə təhlükəsiz bir prosedurdur və hamiləlik zamanı da edilə bilər. Kolposkopik biopsiya edilməsi zəruri olduğu hallarda isə diqqətli olmaq lazımdır. Hamiləlik zamanı kolposkopiya sadəcə bu sahədə mütəxəssis olan həkimlər tərəfindən edilməlidir. Aşağı dərəcəli lezyonlar üçün hamilə olmayan qadınlarda biopsiya edildiyi halda, hamilə qadınlarda sadəcə xərçəng şübhəsinə səbəb olan lezyonlarda edilə bilər. Xərçəng şübhəsi olmayan lezyonların incələnməsi doğuşdan sonra edilməlidir. Hamilə olmayan xəstələrə edilən uşaqlıq kanalının qaşınaraq təmizlənməsi proseduru hamilə qadınlara tətbiq olunmur.<br /><br /></span><strong>Kolposkopiya zamanı anesteziya edilmi?</strong></span></p>\n<p><span><span>Kolposkopiya ümumilikdə anesteziyaya ehtiyyac olmadan edilən prosedurdur. Vaginanın və vulvanın aşağı hissəsində kolposkopik biopsiya zamanı lokal anesteziyadan istifadə edilə bilər.<br /><br /></span><strong>Kolposkopiyadan sonra nələrə diqqət yetirilməlidir?</strong></span></p>\n<p><span>Kolposkopiya zamanı biopsiya edilmirsə gündəlik işlərinizi məhdudlaşdırmağınıza ehtiyac yoxdur. Prosedur sonrası bir neçə gün ərzində çox yüngül qanaxma və ya axıntı ola bilər.</span></p>\n<p><span>Kolposkopik biopsiyadan sonra</span></p>\n<p><span>Duş qəbul etməyin hərhansı bir ziyanı yoxdur.</span></p>\n<p><span>Bir müddət cinsi əlaqədən çəkinmək lazımdır.</span></p>\n<p><span><span>İstifadə olunan dərmanlar həkimdən soruşularaq davam etdirilə bilər.<br /><br /></span><strong>Kolposkopiyadan sonra menstruasiyada gecikmə olurmu?</strong></span></p>\n<p><span><span>Çox nadir olsa da, bəzi xəstələrdə kolposkopiyadan sonra aybaşı gecikməsi ola bilər.<br /><br /></span><strong>Kolposkopiyadan sonra cinsi əlaqə necə olmalıdır?</strong></span></p>\n<p><span><span>Kolposkopiyadan sonra cinsi əlaqəni kəsməyə ehtiyac yoxdur. Lakin kolposkopik biopsiya aparılırsa, 2-3 gün ərzində cinsi əlaqədən çəkinmək lazımdır.<br /><br /></span><strong>Kolposkopiyadan sonra qasıq ağrısı ola bilərmi?</strong></span></p>\n<p><span><span>Kolposkopiya prosedurundan sonra qasıq ağrısına rast gəlinmir. Bununla birlikdə, kolposkopik biopsiya edilən xəstələrdə yüngül qasıq ağrısı ola bilər.<br /><br /></span><strong>Kolposkopiya hamilə qalmağa təsir edə bilərmi?</strong></span></p>\n<p><span><span>Kolposkopiya və kolposkopik biopsiya hamiləliyə təsir göstərmir. Biopsiya zamanı alınan toxuma nümunələri çox kiçik olduğundan hamiləliyə mənfi təsir göstərmir.<br /><br /></span><span><strong>Kolposkopiya hansı şöbə və həkim tərəfindən aparılır?</strong></span></span></p>\n<p><span><span>Kolposkopiya ginekologiya şöbəsinin həkimləri tərəfindən aparılır</span><br /><br /><strong>LEEP nedir?</strong></span></p>\n<p><span>&ldquo;Kolposkopik biopsi sonuçları anormal çıkan hastalarda anestezi altında rahim ağzının bir miktar tam kat çıkarılma işlemidir. İşlem sonrasında lezyonun rahmin içine doğru devamlılığı ve yaygınlığı araştırılır. Biyopsi sonucuna karşı tedavi ve takip açısından daha etkin bir yöntemdir.</span></p>\n<p><span>Kolposkopik biopsiya zamanı şübhəli nəticə olan xəstələrdə anesteziya ilə serviksin bir hissəsinin çıxarılması prosedurudur. Prosedurdan sonra lezyonun uşaqlığın içərisinə tərəf olan davamlılığı və yayılma dərəcəsi araşdırılır. Biopsiya nəticəsinə əsasən xəstəliyin müalicəsi və incələnməsi zamanı daha təsirli bir üsuldur.</span></p>', 'kolposkopiyanedir-1620333881.png', 0, 0, 0, 1),
(19, 0, 0, 1624177153, '', '', 'HPV VİRUSU, HPV PEYVƏNDİ VƏ HPV TESTİ NƏDİR?', '', '', '', '', '', 'HPV testi, Pap smear testi zamanı ya da uşaqlıq boynundan götürülmüş toxuma nümunəsindən edilir. HPV testi edilməsinin səbəbi yüksək riskli lezyonların müəyyənləşdirilməsi məqsədi daşıyır. HPV testi adi testlər zamanı edilmir. Xüsusilə 30 yaşdan yuxarı qadınlara tətbiq olunur.', '', '', '<h1><span style="font-size: 18px;">HPV Testi nədir?</span></h1>\n<p><span style="font-size: 14px;">HPV testi, Pap smear testi zamanı ya da uşaqlıq boynundan götürülmüş toxuma nümunəsindən edilir. HPV testi edilməsinin səbəbi yüksək riskli lezyonların müəyyənləşdirilməsi məqsədi daşıyır. HPV testi adi testlər zamanı edilmir. Xüsusilə 30 yaşdan yuxarı qadınlara tətbiq olunur. </span></p>\n<h1><span style="font-size: 18px;">HPV( İnsan Papilloma Virusu) Peyvəndi Nədir?</span></h1>\n<p><span style="font-size: 14px;">Servikal xərçəngə səbəb ola biləcək HPV(İnsan papilloma virusu) virusunun xərçəng əmələ gətirən 15 fərqli növü mövcuddur. Tip 16 və Tip 18 HPV səbəbiylə yaranan xərçənglərin 75%-ni təşkil edir. HPV peyvəndi orqanizmdə Tip 16 və Tip 18-ə qarşı qoruma yaradır. Eyni zamanda ziyillərin əmələ gəlməsinə səbəb olan Tip 6 və Tip 11-ə qarşı da qorunma təmin edir.</span></p>\n<p><span style="font-size: 14px;">Peyvənddən əvvəl Tip 16 və ya Tip 18 və ya digər növlər orqanizmdə mövcuddursa peyvənd bu növlərdən qorumur. HPV peyvəndi müalicə məqsədilə edilən peyvənd deyil. Cinsi həyatı hələ başlamayan və ya əvvəllər HPV virusu olmayan bir qadına tətbiq olunan HPV peyvəndi, Tip 16 və Tip 18 olaraq bilinən və xərçəngə səbəb olan viruslardan 100% qoruyucu təsirə malikdir.</span></p>\n<p><span style="font-size: 14px;">HPV peyvəndi virusun növlərinə görə fərqlənir. Bunlar 2-li, 4-lü və 8-li olmaqla 3 doza şəklində tətbiq olunur. HPV peyvəndi həm qızlarda, həm də oğlanlarda 11-12 yaş arasında, qadınlarda isə yaş həddi olmadan tətbiq oluna bilər.</span></p>\n<p><span style="font-size: 14px;">Hər il 250 min qadın uşaqlıq boynu xərçəngindən vəfat edir. Təxminən 10 il əvvələ qədər bu virusdan qorunmaq üçün heç bir vasitə yox idi. Ancaq araşdırmalar nəticəsində HPV infeksiyasından yəni uşaqlıq boynu xərçəngindən qorunmanın mövcud olduğu ortaya çıxdı.</span></p>\n<p><span style="font-size: 14px;">HPV peyvəndi tətbiq edən ölkələrdən biri olan Avstraliyada, uşaqlıq boynu xərçəngi lezyonlarının və eyni zamanda müayinələr zamanı yüksək riskli HPV virusu olan insanların sayında əhəmiyyətli azalmalar olduğu meydana çıxdı.</span></p>\n<p><span style="font-size: 14px;">HPV ilə mübarizədə peyvənd xüsusi əhəmiyyət kəsb edir. Peyvənd; laboratoriya mühitində yaradılan və bu virusla 100% bənzərlik daşıyan içi boş bir quruluşa malikdir. Buna görə də virus xəstəlik əmələ gətirmə ehtimalı olmadan bədənə yeridilir və tanıdılır, bunun nəticəsində də immunitet sistemi bu virusa xas müdafiə sistemi inkişaf etdirir. Bədənin sonradan həqiqi virusla qarşılaşması zamanı artıq bu virusa qarşı özünü müdafiə sistemi mövcud olduğu üçün virusun orqanizmə təsir etmədən məhv edilməsi mümkün olur.</span></p>\n<p><span style="font-size: 14px;">Təxminən 14 yüksək riskli HPVvirusu növü var. Bunlardan, peyvəndin tərkibinə də daxil olan tip 16 və 18 növü xəstəliklərin 70%-ni əmələ gətirən növlərdəndir. Yerdə qalan 30%-lik növ üçün hələ də peyvənd ixtira edilmədiyi üçün uşaqlıq boynu xərçənginin nə vaxt yox olacağınını demək çətindir.</span></p>\n<p><span style="font-size: 14px;">Hal hazırda 3 fərqli qoruyucu HPV peyvəndi istifadə olunur. Bunlardan birincisi; ən çox uşaqlıq boynu xərçənginə səbəb olan yalnız iki HPV növünə qarşı qorunma təmin edən ikiqat peyvənddir.</span></p>\n<p><span style="font-size: 14px;">İkincisi, orqanizmi ikiqat peyvənddə mövcud olan növlərdən qoruyan, eyni zamanda kişilərdə və qadınlarda ziyillərə səbəb olan HPV növlərindən də qoruma gücünə malik olan dördqat peyvənddir. Dördqat peyvəndin qoruma gücünün olduğu HPV növlərinə servikal xərçənglərin yaranmasının təxminən 70%-nə səbəb olan HPV 16 və HPV 18-lə bərabər genital ziyillərin əmələ gəlməsinin təxminən 90%-nə səbəb olan və xərçənglə heç bir əlaqəsi olmayan HPV 6 və HPV 11 növlərindən də qoruma daxildir.</span></p>\n<p><span style="font-size: 14px;">Üçüncü növü isə qadınlarda və kişilərdə ziyillərin əmələ gəlməsinə səbəb olan HPV növünləri ilə birlikdə xərçəngə səbəb olan əlavə yeddi HPV növündən qoruma gücünə malik olan doqquz qatlı peyvənddir. Doqquz qatlı peyvənd hələ Azərbaycanda mövcüd deyil.</span></p>\n<p><span style="font-size: 14px;">HPV peyvəndinin həm oğlanlar həm də qızlara edilməsi tövsiyə olunur. Bütün dünya mütəxəssisləri uşaqlara 11-12 yaş arasında peyvənd vurulmasının vacibliyi mövzusunda həmfikirdirlər. Avstraliya, Kanada, Portuqaliya, Norveç, Finlandiya, Danimarka kimi inkişaf etmiş ölkələrdə məktəblərdə bu peyvəndlər pulsuz edilir. HPV peyvəndi uşaqlara doqquz yaşından etibarən vurula bilər. Uşaq dərsdə iştirak etmədiyi üçün peyvənd olunmadığı zaman oğlanlar üçün 21, qızlar üçün isə 25 yaşına qədər peyvənd edilmə müddəti mövcuddur.</span></p>\n<p>&nbsp;</p>\n<h1><span style="font-size: 18px;">Peyvəndin əlavə təsirləri olabilərmi?</span></h1>\n<p><span style="font-size: 14px;">HPV peyvəndinin tərkibində canlı və ya ölü mikrob olmadığı üçün HPV iltihabı, xərçəng və ya ölüm kimi yan təsirləri yoxdur. Uşaqlıq dövründə edilən peyvəndlər kimi, inyeksiya yerində yüngül ağrı, tempratur yüksəlməsi və qızarıqlıq kimi simptomlar yarana bilər.</span></p>\n<p>&nbsp;</p>\n<h1><span style="font-size: 18px;">Hamiləlik dövründə peyvənd edilə bilərmi?</span></h1>\n<p><span style="font-size: 14px;">Hamiləlik dövründə peyvənd edilməsi problem yaratmır ancaq hamilə qadınlara tətbiq edilməsinə üstünlük verilmir. Buna baxmayaraq, hamilə olduğunu bilmədən peyvənd olunan qadının uşağının götürülməyinə ehtiyac duyulmur.</span></p>\n<p>&nbsp;</p>\n<h1><span style="font-size: 18px;">HPV peyvəndi Kimlərə edilməməlidir? </span></h1>\n<p><span style="font-size: 14px;">Dördqat peyvənd maya allergiyası olan insanlara edilməməlidir. Çünki bu peyvənd maya içərisində istehsal olunur.</span></p>\n<p><span style="font-size: 14px;">İkiqat peyvənd isə istehsal texnikası səbəbilə lateks tərzindəki materiallara qarşı həssas olan şəxslərə edilmir.</span></p>\n<p><span style="font-size: 14px;">Peyvənd olunacaq şəxsin qızdırması, orta və ya ağır dərəcəli bir xəstəliyi varsa, xəstəliyi keçdikdən sonra peyvənd olunması məsləhət görülür.</span></p>\n<p><span style="font-size: 14px;">Hamilə qadınlarda peyvəndin edilməsi tövsiyə edilmir lakin, bu günə qədər peyvənd olunmuş analardan doğulan körpələrdə hərhansı bir mənfi təsir müşahidə olunmur.</span></p>\n<p>&nbsp;</p>\n<h1><span style="font-size: 18px;">Vaksinasiya edildikdən sonra Pap-smear testinə davam edilməlidir</span></h1>\n<p><span style="font-size: 14px;">Genital(cinsi) nahiyədə ziyillər bütün dünyada 1% nisbətində qarılaşılaşılan xəsətlik növüdür. Bu nisbət 20-li yaş dövründə yüzdə 7-ə yüksəlir. Uşaqlıq boynu xərçəngi peyvəndi edilmiş olsa da, müayinələr davam edilməlidir. 21 yaşından etibarən bütün qadınlara üç ildə bir dəfə PAP Smear testi edilməsi tövsiyə olunur.</span></p>\n<p><span style="font-size: 14px;">HPV və PAP smear testinin birlikdə edildiyi müayinənin yəni Co-Testin edilməsi isə 30 yaşından etibarən tövsiyə olunur. Əgər hər iki müayinənin nəticəsi də yaxşı çıxarsa, beş il ərzində uşaqlıq boynu xərçəngi və ya xərçəng öncəsi lezyonun inkişaf etmə faizi 0,08%-ə düşür.</span></p>\n<p>&nbsp;</p>\n<h1><span style="font-size: 18px;">HPV hansı xəstəliklərə səbəb olur?</span></h1>\n<p><span style="font-size: 14px;">Təxminən 30-40-a yaxın HPV növü cinsiyyət bölgəsində ziyillərin çıxmasına səbəb olur. Ziyillər vaginanın içində və ya kənarlarında, anusda vulvanın və ya kişilərdə penisin üzərində çıxa bilər. HPV virusu səbəbilə meydana gələn bu ziyillər müalicə olunmadığı zaman daha çox bölgəyə yayıla və gələcəkdə xərçəngə çevrilə bilər.</span></p>\n<p><span style="font-size: 14px;">Ən təhlükəli HPV növləri müalicə olunmadığı təqdirdə gələcəkdə penis, serviks, vulva, anus, uşaqlıq boynu kimi xərçəng növlərinin əmələ gəlməsinə səbəb ola bilər.</span></p>\n<p>&nbsp;</p>\n<h1><span style="font-size: 18px;">HPV virusu kişilərə təsir edirmi?</span></h1>\n<p><span style="font-size: 14px;">HPV virusu kişilərdə ziyillərin yaranmasına və müalicə olunmasa bu ziyillərin daha sonra penis və ya anal xərçənglərə çevrilməsinə səbəb ola bilər. Buna görə də kişilər də HPV peyvəndi olmalıdır. Bundan əlavə, kişidə olan HPV virusu cinsi əlaqədə olduğu qadının servikal xərçəng olmağına səbəb ola bilər.</span></p>\n<p>&nbsp;</p>', 'hpv-testi-nedir-1624177403.jpg', 0, 0, 0, 1),
(20, 0, 0, 1619973656, '', '', 'Onkoginekologiya nədir? onkoloq ginekoloq kimdir?', '', '', '', '', '', 'Onkoginekoloq Dr. Könül Mərdanova cavablayır!\n\nOnkoginekologiya nədir?', '', '', '<p>Onkoginekoloq Dr. Könül Mərdanova cavablayır!</p>\n<p>Onkoginekologiya nədir?</p>\n<p>&nbsp;</p>', 'onkoloqginekoloqkonulmardanova-1627749656.jpg', 0, 0, 0, 1),
(21, 0, 0, 1620232960, '', '', 'Uşaqlıq boynunun polipləri, polipin əlamətləri', '', '', '', '', '', 'Poliplər endometriumdan (uşaqlığın daxili qişası) inkişaf edib uşaqlıq boşluğuna doğru uzanan patoloji törəmədir. Poliplərin vaxtında aşkarlanıb müalicə olunması həm də ona görə lazımdır ki, bəzən bədxassəli şişə çevrilə bilirlər.', '', '', '<p><span style="font-size: 18px;">Poliplər endometriumdan (uşaqlığın daxili qişası) inkişaf edib uşaqlıq boşluğuna doğru uzanan patoloji törəmədir. Poliplərin vaxtında aşkarlanıb müalicə olunması həm də ona görə lazımdır ki, bəzən bədxassəli şişə çevrilə bilirlər.</span><br /><br /><span style="font-size: 18px;">Əlamətləri nələrdir?</span><br /><br /><span style="font-size: 18px;">Poliplərin ən əsas kliniki əlaməti mensturasiya pozğunluğunun əmələ gəlməsidir. Menstural pozğunluqlar özünü müxtəlif şəkildə göstərir. Belə ki, bu zaman mensturasiyanın tez&ndash;tez və düzənsiz olması, menstural qanın normadan çox olması, mensturasiyalar arası dövrdə qanaxmaların olması kimi əlamətlər ortaya çıxır. Bunlardan əlavə, sonsuzluq, menopauzada olan qadınlarda uşaqlıq qanaxması, polipin böyük ölçüsündə sancışəkilli ağrı əlamətləri də meydana çıxa bilər.</span></p>', 'usaqliqboynununpolipleri-1627749820.jpg', 0, 0, 0, 1),
(22, 0, 0, 1620417187, '', '', 'Uşaqlıq boynu xərçənginin müayinəsi', '', '', '', '', '', 'Uşaqlıq boynu xərçənginin müayinəsi zamanı həyata keçirilən Pap smear testi erkən diaqnoz üçün çox vacibdir.\nÜmumiyyətlə, cinsi həyatı olan qadınlara Pap smear testindən keçmək tövsiyə olunur.', '', '', '<p><br /><span style="font-size: 18px;">Uşaqlıq boynu xərçənginin müayinəsi zamanı həyata keçirilən Pap smear testi erkən diaqnoz üçün çox vacibdir.</span><br /><span style="font-size: 18px;">Ümumiyyətlə, cinsi həyatı olan qadınlara Pap smear testindən keçmək tövsiyə olunur. Uşaqlıq boynu xərçənginin skrininqi üçün 25 yaşdan etibarən Pap smear testi həyata keçirilə bilər. Bu testin 3 ildən bir edilməsi tövsiyyə olunur. Uşaqlıq boynu xərçənginin skrininqi üçün həyata keçirilən digər testlərdən biri olan HPV testi isə 5 ildən bir həyata keçirilir.</span></p>\n<div id="gtx-trans" style="position: absolute; left: 215px; top: 43px;">&nbsp;</div>', 'usaqliqboynuxercengi-1627761307.jpg', 0, 0, 0, 1),
(23, 0, 0, 1622490961, '', '', 'Kolposkopiya müayinəsi nədir?', '', '', '', '', '', 'Kolposkopiya uşaqlıq boynunun, uşaqlıq yolunun və xarici tənasül orqanlarının proflaktik müayinəsi məqsədi ilə və yaxud anormal Pap Smear testi nəticələri olan xəstələrə və ya HPV aşkarlanan xanımlara aparılan instirumental müayinə metodudur.', '', '', '<p><span style="font-size: 18px;">Kolposkopiya uşaqlıq boynunun, uşaqlıq yolunun və xarici tənasül orqanlarının proflaktik müayinəsi məqsədi ilə və yaxud anormal Pap Smear testi nəticələri olan xəstələrə və ya HPV aşkarlanan xanımlara aparılan instirumental müayinə metodudur. Ginekoloji müayinə zamanı, ginekoloji masada aparılan ağrısız bir müayinə metodudur. Uşaqlıq boynu xüsusi məhlullarla işləndikdən sonra xüsusi mikroskop vasitəsi ilə uşaqlıq boynu detallı olaraq, böyüdülərək müayinə olunur. Lazım gələrsə, uşaqlıq boynundan, serviksdən eyni vaxtda biopsi alınır.</span></p>\n<div id="gtx-trans" style="position: absolute; left: -20px; top: -20px;">&nbsp;</div>', 'kolposkopiyamuayinesi-1627761421.jpg', 0, 0, 0, 1),
(24, 0, 0, 1627761612, '', '', 'Ginekoloji xərçəng şübhəsi zamanı həyata keçirilən müayinələr', '', '', '', '', '', 'Ginekoloji xərçəng şübhəsi zamanı həyata keçirilən müayinələr', '', '', '', 'ginekolojixercenglerinmueyinesi-1627761672.jpg', 0, 0, 0, 1),
(25, 0, 0, 1621022520, '', '', 'Histeroskopiya  müayinəsi', '', '', '', '', '', 'Histeroskopiya optic bir cihazla uşaqlıq boynundan içəri girərək uşaqlığın içini və boruların uşaqlıq yoluna açılan hissəsini yoxlamaq üçün istifadə edilən üsuldur. Histeroskopiya iki məqsəd üçün istifadə olunur: diaqnostika və cərrahiyyə.', '', '', '<p><span style="font-size: 18px;">Histeroskopiya optic bir cihazla uşaqlıq boynundan içəri girərək uşaqlığın içini və boruların uşaqlıq yoluna açılan hissəsini yoxlamaq üçün istifadə edilən üsuldur. Histeroskopiya iki məqsəd üçün istifadə olunur: diaqnostika və cərrahiyyə.</span><br /><br /><span style="font-size: 18px;">Histeroskopiya; qanaxma, menstruasiya pozğunluğu, ağrı, uşaqlıq mioması, polip, uşaqlığın anadangəlmə anormallığı, təkrarlanan açılışlar, ucu itmiş spiralların çıxarılması və uşaqlıqda pərdə olması kimi xəstəliklər zamanı həm diaqnostik, həm də terapevtik məqsədlər üçün istifadə olunur. Bundan əlavə histeroskopiya ilə uşaqlıq divarı (endometrial) patologiyaları təyin etmək üçün nümunələr də götürülə bilər.</span></p>\n<div id="gtx-trans" style="position: absolute; left: 122px; top: -20px;">&nbsp;</div>', 'histeroskopiyamuayinesimillionkologiyamerkezi-1627761780.jpg', 0, 0, 0, 1),
(7, 0, 0, 1583256850, '', '', 'HİSTEROSKOPİYA NƏDİR? HİSTEROSKOPİYA HANSI XƏSTƏLİKLƏR ZAMANI İSTİFADƏ OLUNUR?', '', '', '', '', '', 'Qadın sağlamlığının qorunmasında son dərəcə əhəmiyyətli bir prosedur olan histeroskopiya uşaq sahibi olmaq istəyənlərin müayinəsi və ya ginekoloji problemlər zamanı istifadə edilən bir üsuldur. Bu üsul mütəxəssis həkimlər tərəfindən edilməlidir.', '', '', '<p style="text-align: left;" align="center"><span style="color: #000000;"><strong><span style="font-size: 18px;">HİSTEROSKOPİYA HANSI XƏSTƏLİKLƏR ZAMANI İSTİFADƏ OLUNUR?</span></strong></span></p>\n<p style="text-align: left;"><span style="color: #000000;"><strong><span style="font-size: 18px;">Histeroskopiya</span></strong></span></p>\n<p><span style="font-size: 16px; color: #000000;">Qadın sağlamlığının qorunmasında son dərəcə əhəmiyyətli bir prosedur olan histeroskopiya uşaq sahibi olmaq istəyənlərin müayinəsi və ya ginekoloji problemlər zamanı istifadə edilən bir üsuldur. Bu üsul mütəxəssis həkimlər tərəfindən edilməlidir.</span></p>\n<p>&nbsp;</p>\n<p><span style="font-size: 18px; color: #000000;"><strong>Mündəricat</strong></span></p>\n<p><span style="font-size: 18px; color: #000000;"><strong>Histeroskopiya nədir?</strong></span></p>\n<p><span style="font-size: 18px; color: #000000;"><strong>Hansı xəstəliklər zamanı istifadə olunur?</strong></span></p>\n<p><span style="font-size: 18px; color: #000000;"><strong>Histeroskopiya proseduru necə həyata keçirilir?</strong></span></p>\n<p><span style="font-size: 18px; color: #000000;"><strong>Histeroskopiya proseduru ilə bağlı tez-tez verilən suallar</strong></span></p>\n<p>&nbsp;</p>\n<p><span style="color: #000000;"><strong><span style="font-size: 18px;">HİSTEROSKOPİYA NƏDİR?</span></strong></span></p>\n<p><span style="font-size: 16px; color: #000000;">Hystero və Scopy sözlərindən yaranan histeroskopiya uşaqlıq və görüntüləmə sözlərinin<img style="margin: 10px; float: right;" src="/images/upload/image/Histeroskopiya_emeliyyati.png" alt="" width="400" height="400" /> birləşməsidir. Histeroskopiya optic bir cihazla uşaqlıq boynundan içəri girərək uşaqlığın içini və boruların uşaqlıq yoluna açılan hissəsini yoxlamaq üçün istifadə edilən üsuldur. Histeroskopiya iki məqsəd üçün istifadə olunur: diaqnostika (diaqnostik) və cərrahi (operativ).</span></p>\n<p>&nbsp;</p>\n<p><span style="color: #000000;"><strong><span style="font-size: 18px;">HANSI XƏSTƏLİKLƏR ZAMANI İSTİFADƏ EDİLİR?</span></strong></span></p>\n<p><span style="font-size: 16px; color: #000000;">Histeroskopiya; qanaxma, menstruasiya pozğunluğu, ağrı, uşaqlıq mioması, polip, uşaqlığın anadangəlmə anormallığı, təkrarlanan açılışlar, ucu itmiş spiralların çıxarılması və uşaqlıqda pərdə olması kimi xəstəliklər zamanı həm diaqnostik, həm də terapevtik məqsədlər üçün istifadə olunur. Bundan əlavə histeroskopiya ilə uşaqlıq divarı (endometrial) patologiiyalarıni təyin etmək üçün nümunələr də götürülə bilər.</span></p>\n<p>&nbsp;</p>\n<p><span style="font-size: 18px; color: #000000;"><strong>HİSTEROSKOPİYA PROSEDURU NECƏ HƏYATA KEÇİRİLİR?</strong></span></p>\n<p><span style="font-size: 16px; color: #000000;">Histeroskopiya vaginal yolla servikal kanaldan xüsusi alətlərlə uşaqlıq yoluna girərək edilir. Bəzən cərrahi histeroskopiya prosedurlarından əvvəl xəstəyə dərman verərək uşaqlıq boynunu açmaq lazım ola bilər. Açıldıqdan sonra kamera və lens sistemindən ibarət olan borulu histeroskop vaginadan və uşaqlıq boynundan keçir və uşaqlığa doğru irəliləyir. Uterusun içinin aydın görülməyi üçün uşaqlığa xüsusi mayelər yeridilir və görüntü monitorda mütəxəssis tərəfindən izlənilir. Həkimlər lazım olduqda histeroskopun ucundakı kəsici və lazer effektli alətlərlə əməliyyat da edəbilər.</span></p>\n<p><span style="font-size: 16px; color: #000000;">Histeroskopiya proseduru həm həkim otağında, həm də əməliyyatxana şəraitində edilə bilər. Həkim otağında edilən histeroskopiya ümumi anesteziya olmadan yalnız lokal anesteziya ilə aparılan və diaqnoz məqsədilə edilən histeroskopiyadır. Otaq şəraitində istifadə edilən histeroskopiyada bəzi kiçik alətlərin istifadəsinə imkan verən girişlər mövcuddur. Texnoloji yeniliklərlə birlikdə histeroskopiya həm daha incə və daha kiçik alətlərlə edilir, həm də çox kicik ölçüdəki alətlərin uşaqlıq yoluna yerləşdirilməsinə imkan verir. Bu yeniliklərin gətirdiyi imkanlarla otaq şəraitində edilən hisoeroskopiya zamanı kiçik poliplər və ya uşaqlıqda qalan və ucu görünməyən spiralları çixarmaq mümkündür. Beləliklə, xəstələr daha rahat, daha az riskli və daha az xərclə otaq şəraitində edilən hisoeroskopiyanı rahatlıqla seçə bilərlər.</span></p>\n<p><span style="font-size: 16px; color: #000000;">Millimetr fərqlə daha qalın olan əməliyyat (cərrahi) histeroskopiyasının da iş mexanizmi diaqnostik histeroskopiya ilə eyni şəkildədir. Bununla birlikdə, operativ histeroskopiyada cərrahi tətbiq üçün lazım olan kiçik alətlərin istifadəsinə imkan yaradan girişlər var. Bu kiçik alətlər vasitəsilə daha böyük miyomalar və poliplər çıxarılaraq müalicə olunur.</span></p>\n<p>&nbsp;</p>\n<p><strong><span style="font-size: 18px; color: #000000;">HİSTEROSKOPİYA PROSEDURU İLƏ BAĞLI TEZ-TEZ VERİLƏN SUALLAR</span></strong></p>\n<p><strong><span style="font-size: 18px; color: #000000;">Diaqnostik histeroskopiya nədir?</span></strong></p>\n<p><span style="font-size: 16px; color: #000000;">Diaqnostik histeroskopiya uşaqlıqdakı lezyonları və ya doğuşdan gələn anormallıqları təyin etmək üçün; cərrahi histeroskopiya isə prosedur zamanı görülən lezyon və ya anormallıqların götürülməsi üçün isitifadə edilir.</span></p>\n<p>&nbsp;</p>\n<p><strong><span style="font-size: 18px; color: #000000;">Histeroskopiya nə vaxt edilə bilər?</span></strong></p>\n<p><span style="font-size: 16px; color: #000000;">Mensturasiyadan dərhal sonra uşaqlıq qalınlaşmağa başladığı üçün yaranan qalınlıq bəzi patologiyaların görülməsinin qarşısını ala bilər və bu da histeroskopiyadan doğru nəticə əldə edilməməsinə səbəb ola bilər. Bu səbəblə histeroskopiya proseduru daha çox menstruasiya bitdikdən bir həftə sonra edilir.</span></p>\n<p>&nbsp;</p>\n<p><strong><span style="font-size: 18px; color: #000000;">Hansı hallarda histeroskopiya edilir?</span></strong></p>\n<p><span style="font-size: 16px; color: #000000;">İlk öncə xəstə bir ginekoloq və ya mama ginekoloq tərəfindən müayinə edilməlidir. Ultrasəs müayinədən sonra hər hansı bir lezyon və ya patologiyadan şübhələnildiyi zaman histeroskopiya edilməsinə qərar verilir. Histeroskopiya birbaşa edilən bir prosedur deyil.</span></p>\n<p>&nbsp;</p>\n<p><strong><span style="font-size: 18px; color: #000000;">Bu prosedur üçün kimlər uyğundur?</span></strong></p>\n<p><span style="font-size: 16px; color: #000000;">Bu prosedur müayinə kimi qəbul edilməməlidir. Polip və miomalar zamanı, həddindən artıq çox qanaxma hallarında, uşaqlıqdakı yapışqanlıqlar zamanı, uşaqlıqda olan pərdə zamanı, uşaqlıqda ucu itən spiralları tapmaq və uşaqlıqda olan anadangəlmə anormallıqlar zamanı bu prosedurdan istifadə edilir. Bununla birlikdə, menopoz sonrası qanaxma olan xəstələrdə və focal lezyonlardan şübhələnilən xəstələrdə də histeroskopiya edilə bilər.</span></p>\n<p>&nbsp;</p>\n<p><strong><span style="font-size: 18px; color: #000000;">Histeroskopiya edəcək xəstələr nələrə nələrə diqqət etməlidir?</span></strong></p>\n<p><span style="font-size: 16px; color: #000000;">Bu proseduru etmək istəyən qadınlar hamilə olmadıqlarına əmin olmalıdırlar.</span></p>\n<p>&nbsp;</p>\n<p><strong><span style="font-size: 18px; color: #000000;">Histeroskopiya riskli bir prosedurdur?</span></strong></p>\n<p><span style="font-size: 16px; color: #000000;">Histeroskopiya çox az riskli prosedurdur.</span></p>\n<p>&nbsp;</p>\n<p><strong><span style="font-size: 18px; color: #000000;">Histeroskopiyadan sonra nələrə diqqət yetirilməlidir?</span></strong></p>\n<p><span style="font-size: 16px; color: #000000;">Histeroskopiya əməliyyatından sonra bir həftə və ya 10 gün ərzində cinsi əlaqədən çəkinmək lazımdır.</span></p>\n<p>&nbsp;</p>\n<p><strong><span style="font-size: 18px; color: #000000;">Histeroskopiyadan sonra qanaxma olabilərmi?</span></strong></p>\n<p><span style="font-size: 16px; color: #000000;">Histeroskopiyadan sonra ləkələnmə şəklində qanaxma görünə bilər. Eyni zamanda yüngül qasıq ağrısı da ola bilər. Bu şikayətlər növbəti 2-3 gün ərzində keçir. Ancaq prosedurdan sonra ağrı və yüksək tempratur olarsa həkimə müraciət edilməlidir.</span></p>\n<p>&nbsp;</p>\n<p><strong><span style="font-size: 18px; color: #000000;">Histeroskopiya prosedurunun üstünlükləri nələrdir?</span></strong></p>\n<p><span style="font-size: 16px; color: #000000;">Histeroskopiyanın ən böyük üstünlüyü, təbii olaraq vaginal yoldan edildiyi üçün uşaqlığın içərisini heç bir kəsik olmadan incələməyin mümkün olmasıdır. Prosedur günü xəstəxanadan çıxan xəstələr çox qısa müddətdə gündəlik həyatlarına qayıda bilərlər. Bununla birlikdə, xəstələr əlavə bir kəsik olmadan mioma və polip kimi lezyonlardan xilas ola bilərlər.</span></p>\n<p>&nbsp;</p>\n<p><strong><span style="font-size: 18px; color: #000000;">Histeroskopiya ağrılı prosedurdur?</span></strong></p>\n<p><span style="font-size: 16px; color: #000000;">Histeroskopiya çox ağrılı bir prosedur deyil. Diaqnostik histeroskopiya hətta ağrıya dözümlü olan xəstələrdə anesteziya olmadan da həyata keçirilə bilər. Eyni zamanda xəstələr əvvəlcədən ağrı kəsici ilə premedikasiya edilə bilər. Cərrahi histeroskopiya anesteziya ilə aparıldığı üçün ümumiyyətlə ağrı olmur.</span></p>\n<p><strong><span style="font-size: 18px; color: #000000;">Histeroskopiya təhlükəsiz prosedurdur?</span></strong></p>\n<p><span style="font-size: 16px; color: #000000;">Histeroskopiya təhlükəsiz bir prosedurdur. Lakin əməliyyat zamanı cərrah vaxta diqqət etməli və əməliyyat müddətini normaldan çox uzatmamalıdır. Zəruri hallarda lezyonu aradan qaldırmaq üçün histeroskopiya bir neçə dəfə təkrar edilməli bir dəfəyə çıxarılmamalıdır. Çünki uzunmüddət davam edən histeroskopiya zamanı istifadə olunan maye səbəbilə istənməyən vəziyyətlər yarana bilər. Xəstələr əməliyyata girmədən öncə bilməlidirlər ki,yarana biləcək komplikasiyaları azaltmaq üçün bəzi hallarda histeroskopik əməliyyatlar tək bir seansda edilə bilməz, bəzən bir neçə seans tələb oluna bilər.</span></p>\n<p><span style="font-size: 18px;"><strong><span style="color: #000000;">Histeroskopiyadan sonra hamiləlik şansı artırmı?</span></strong></span></p>\n<p><span style="font-size: 16px; color: #000000;">Əgər uşaqlıqda lezyon yoxdursa histeroskopiya hamiləliyə təsir göstərmir. Hamiləlik açılmalarına səbəb olan poliplərin, uşaqlıq miomasının götürülməsi və ya hamiləlik açılışına səbəb olan bir digər problem uşaqlıq pərdəsini histeroskopiya ilə kəsilməsi ilə normal hamiləlik şansı artırıla bilər.</span></p>\n<p>&nbsp;</p>\n<p><strong><span style="font-size: 18px; color: #000000;">Histeroskopiyada istifadə olunan mayenin tərkibi nədir?</span></strong></p>\n<p><span style="font-size: 16px; color: #000000;">Diaqnostik histeroskopiyada daha çox sistemlər zamanı vurulan ringerdən istifadə edildiyi halda, cərrahi histeroskopiya zamanı tərkibində elektrolit olmayan mayelərdən istifadə olunur. Hansı mayenin istifadə ediləcəyi histeroskopun bipolyar və ya monopolyar elektrik enerjisindən hansını istifadə etdiyinə görə dəyişir.</span></p>\n<p>&nbsp;</p>\n<p><strong><span style="font-size: 18px; color: #000000;">Histeroskopiya nə qədər vaxt aparır?</span></strong></p>\n<p><span style="font-size: 16px; color: #000000;">Diaqnostik histeroskopiya prosesi bir neçə dəqiqə, cərrahi histeroskopiya isə əməliyyat prosedurundan asılı olaraq 5-20 dəqiqə arasında dəyişilir.</span></p>\n<p>&nbsp;</p>\n<p><strong><span style="font-size: 18px; color: #000000;">Qövslü uşaqlıq nədir?</span></strong></p>\n<p><span style="font-size: 16px; color: #000000;">Qövslü uşaqlıq, uşaqlığın yuxarı hissəsinin daxilə doğru çökək olmağı halıdır. Qövslü uşaqlığının diaqnozu ultrasəs müayinə, MRI, histeroskopiya və laparoskopiya ilə edilə bilər.</span></p>\n<p>&nbsp;</p>\n<p><strong><span style="font-size: 18px; color: #000000;">Histeroskopiyadan sonra menstrual qanaxmalarda nizamsızlıq olablərmi?</span></strong></p>\n<p><span style="font-size: 16px; color: #000000;">Histeroskopiyadan sonra menstruasiya qanaması zamanı nizamsızlıq gözlənilmir. Yalnız prosedurdan sonrakı ilk mensturasiyanın zamanı dəyişə bilər.</span></p>\n<p>&nbsp;</p>\n<p><strong><span style="font-size: 18px; color: #000000;">Histeroskopiyadan nə qədər sonra hamilə qalmaq olar?</span></strong></p>\n<p><span style="font-size: 16px; color: #000000;">Diaqnostik histeroskopiyadan sonra gözləmək üçün əlavə vaxta ehyiyyac yoxdur və prosedurdan sonra dərhal hamiləlik planlamaq mümkündür. Cərrahi histeroskopiyadan sonra edilən prosedura bağlı olaraq ən çox 3 ay gözlədikdən sonra hamiləlik planlamaq olar.</span></p>\n<p>&nbsp;</p>\n<p><strong><span style="font-size: 18px; color: #000000;">Histeroskopiya ilə edilən uşaqlıqda polip əməliyyatı nə qədər davam edir?</span></strong></p>\n<p><span style="font-size: 16px; color: #000000;">Poliplərin histereskopik rezeksiyası təxminən 5-10 dəqiqə çəkir.</span></p>\n<p>&nbsp;</p>\n<p><strong><span style="font-size: 18px; color: #000000;">Histeroskopiya ilə polip əməliyyatından sonra təkrarlanma riski varmı?</span></strong></p>\n<p><span style="font-size: 16px; color: #000000;">Poliplərin təkrarlanma ehtimalı yüksəkdir. Təkrarlanma riski histeroskopiya ilə əlaqəli deyil. Xəstədə polip meydana gəlməsinə təsir edən şərtlər davam etdikcə, yenidən polip inkişaf edə bilər.</span></p>', 'histeroskopiyanedirneucundur-1620318130.png', 0, 0, 0, 1),
(8, 0, 0, 1585476356, '', '', 'UŞAQLIQ POLİPLƏRİ NƏDİR? UŞAQLIQ POLİPLƏRİNİN YARANMA SƏBƏBLƏRİ, ƏLAMƏTLƏRİ VƏ MÜALİCƏSİ', '', '', '', '', '', 'UŞAQLIQ POLİPLƏRİ NƏDİR? UŞAQLIQ POLİPLƏRİNİN SƏBƏBLƏRİ, ƏLAMƏTLƏRİ VƏ MÜALİCƏSİ\n\nQadınlarda menstruasiya dövrünün pozulmasının vacib səbəblərindən biri olan uşaqlıq polipləri nədir? Uşaqlıq poliplərinin səbəbləri, simptomları və müalicəsi ilə bağlı bütün məlumatları məqaləmizdə oxuya bilərsiniz.', '', '', '<p><strong><span style="font-size: 18px;">UŞAQLIQ POLİPLƏRİ NƏDİR? UŞAQLIQ POLİPLƏRİNİN SƏBƏBLƏRİ, ƏLAMƏTLƏRİ VƏ MÜALİCƏSİ</span></strong></p>\n<p><span style="font-size: 16px;">Qadınlarda menstruasiya dövrünün pozulmasının vacib səbəblərindən biri olan uşaqlıq polipləri nədir? Uşaqlıq poliplərinin səbəbləri, simptomları və müalicəsi ilə bağlı bütün məlumatları məqaləmizdə oxuya bilərsiniz.</span></p>\n<p><span style="font-size: 16px;">Bu məqaləmizdə əksəriyyəti 1-2 sm böyüklüyündə olan bəzən isə böyüklüyü 10 sm-ə qədər böyüyən, xərçəngə çevrilmə ehtimalı demək olar ki olmayan və<img style="margin: 10px; float: right;" src="/images/upload/image/Usaqliqda_polip%20(1).png" alt="" width="400" height="400" /> ciddi sağlamlıq problemləri yaratmayan uşaqlıq polipləri haqqında bilməli olduğunuz məlumatları ətraflı şəkildə qeyd edəcəyik.</span></p>\n<p>&nbsp;</p>\n<p><span style="font-size: 18px;"><strong>UŞAQLIQ POLİPLƏRİ NƏDİR?</strong></span></p>\n<p><span style="font-size: 16px;">Uşaqlıq polipləri uşaqlığın daxili divarına və uşaqlıq boşluğuna doğru uzanan böyümələrdir. Uşaqlığın (endometriya) astarındakı hüceyrələrin həddindən artıq böyüməsi eyni zamanda endometrium polipləri olaraq da bilinən uşaqlıq poliplərinin meydana gəlməsinə səbəb olur. Bu poliplər çox zaman xərçəng riski daşımır (xoş xassəlidir), lakin bəziləri xərçənglı ola bilər və ya xərçəngə (prekanseroz poliplər) çevrilə bilər.</span></p>\n<p><span style="font-size: 16px;">Uşaqlıq poliplərinin ölçüsü bir-iki millimetrdən (susam toxumu qədər) bir neçə santimetrə qədər (golf topu övə ya daha böyük) ola bilər. Çox zaman uşaqlıq divarına nazik bir sapla bağlı olurlar.</span></p>\n<p><span style="font-size: 16px;">Xəstələrdə eyni anda bir və ya daha çox uşaqlıq polipi yarana bilər. Poliplər əsasən uşaqlıq daxilində qalırlar. Bəzi hallarda isə uşaqlıq boynundan (serviks) vaginaya doğru sürüşürlər. Uşaqlıq polipləri əsasən gənc qadınlarda görülsə də, menopoz dövrünə keçən qadınlarda da çox görülməkdədir.</span></p>\n<p>&nbsp;</p>\n<p><strong><span style="font-size: 18px;">UŞAQLIQ POLİPLƏRİNİN ƏLAMƏTLƏRİ:</span></strong></p>\n<p><span style="font-size: 16px;">Uşaqlıq poliplərinin əlamətləri aşağıdakılardır:</span></p>\n<ul>\n<li><span style="font-size: 16px;">Menstrual qanamaların nizamsızlığı</span></li>\n<li><span style="font-size: 16px;">İki menstruasiya müddəti arasında qanamalar</span></li>\n<li><span style="font-size: 16px;">Menstrual qanamaların həddindən artıq çoxluğu</span></li>\n<li><span style="font-size: 16px;">Menopoz dövründə olan vaginal qanamalar</span></li>\n<li><span style="font-size: 16px;">Sonsuzluq</span></li>\n</ul>\n<p><span style="font-size: 16px;">Poliplər bəzi qadınlarda sadəcə yüngül qanaxma və ya ləkələnmə şəklində, bəzilərində isə ümumiyyətlə heç bir əlamət olmadan yaranır.</span></p>\n<p>&nbsp;</p>\n<p><strong><span style="font-size: 18px;">UŞAQLIQ POLİPLƏRİNİN YARANMA SƏBƏBLƏRİ:</span></strong></p>\n<p><span style="font-size: 16px;">Uşaqlıq poliplərinin yaranmasında hormonal amillərin rolu böyükdür. Uşaqlıq polipləri estrogen hormonuna qarşı olduqca həssasdır, yəni qan dövranı zamanı qanda olan estrogenə cavab olaraq böyüyürlər.</span></p>\n<p>&nbsp;</p>\n<p><span style="font-size: 18px;"><strong>UŞAQLIQ POLİPLƏRİNİN MÜALİCƏSİ</strong></span></p>\n<p><span style="font-size: 16px;">Heç bir əlamət göstərməyən kiçik ölçülü poliplər müalicəsiz də yox ola bilərlər. Uşaqlıq xərçəngi yaranma riski yoxdursa, kiçik poliplərin müalicəsinə ehtiyyac yoxdur.</span></p>\n<p><span style="font-size: 16px;">Dərman</span></p>\n<p><span style="font-size: 16px;">Progestinlər və gonadotropin yaradan hormon agonistləri də daxil olmaqla bəzi hormonal dərmanlar polip əlamətlərini azalda bilərlər. Lakin, bu cür dərmanların qəbulu qısamüddətli həll yoludur. Dərman qəbul etmək dayandırıldığı zaman əlamətlər yenidən təkrarlanır.</span></p>\n<p><span style="font-size: 16px;">Cərrahi yolla müdaxilə</span></p>\n<p><span style="font-size: 16px;">Uşaqlıq poliplərinin müalicəsi "Histeroskopiya" adlı üsulla asanlıqla həyata keçirilir. Bu prosedur lokal və ya ümumi anesteziy ilə aparılır və təxminən 15-20 dəqiqə çəkir. Uşaqlığa bir kamera vasitəsilə vajinal yolla girilərək qarın nahiyəsinə kəsiyə ehtiyyac qalmadan polip kökü ilə birlikdə çıxarılır. Bu yolla alınan parça patoloji müayinə üçün götürülür. Əksər hallarda poliplərin patoloji dəyərləndirilməsinin nəticəsi xoşxassəli olur.</span></p>\n<p><span style="font-size: 16px;">Polip müalicəsi zamanı erkən diaqnoz qoyulması və müalicənin düzgün planlaşdırılaraq edilməsi menstrual pozğunluğu, cinsi əlaqədən sonra yaranan qanaxma və ağrı hallarını, sonsuzluq kimi problemləri aradan qaldıra bilər.</span></p>\n<p><span style="font-size: 16px;">Nadir hallarda, uşaqlıq poliplərinin təkrarlanma ehtimalı ola bilər. Belə bir vəziyyətlə qarşılaşardığınız zaman yenidən müalicə olunaraq problemi aradan qaldırmaq mümkündür.</span></p>', 'usaqliqpolipi-1620317009.jpg', 0, 0, 0, 1),
(26, 0, 0, 1627762979, '', '', 'Anormal vaginal qanamaların səbbləri', '', '', '', '', '', '', '', '', '<p><span style="font-size: 18px;">Qadınlarda süd vəzi, kolorektal, ağciyər xərçənglərindən sonra ən çox gördüyümüz Uşaqlıq cismi xərçəngi - Endometrium xərçəngidir. Endometrium xərçənginin əsas əlamətlərindən biri anormal vaginal qanamalardır. Bu xərçəng növü zamanı erkən diaqnoz qoyulduqda və müalicələri gecikdirmədikdə müsbət nəticələr əldə etmək şansı çox yüksəkdir.</span></p>', 'anormalvaginalqanamalar-1627762979.jpg', 0, 0, 0, 1),
(27, 0, 0, 1627763716, '', '', 'Uşaqlıq boynu xərçənginin skrininqi - Pap smear testi', '', '', '', '', '', '', '', '', '<p><br /><span style="font-size: 18px;">Pap smear testi üçün 5-10 saniyə ərzində fırça köməyi ilə serviksdən (uşaqlıq boynu) yaxma alınır. Xəstə ağrı və narahatlıq hiss etmir. Prosedur zamanı uşaqlıq boynuna daha asan çatmaq üçün spekulum deyilən alətlə uşaqlıq boynunu böyütmək lazım gəlir.</span><br /><br /><span style="font-size: 18px;">Servikal hüceyrələr, hər hüceyrəmiz kimi, müxtəlif səbəblərə görə dəyişikliklərə məruz qala bilər. Bu dəyişikliyə məruz qalan hüceyrələrə "xərçəng xəbərçisi hüceyrələri (hüceyrə displaziyası)" deyilir. Pap semar testi ilə bu proses ağır mərhələlərə keçid etməmiş xəstəliyi müəyyən etmək mümkündür. Xərçəng mərhələsi başlamazdan əvvəl bir qadın 100% bu xəstəliklərdən sağala bilər. Müalicədən sonra kimyəvi terapiya və ya radioterapiyaya ehtiyac yoxdur. Uşaqlıq qorunduğu üçün qadının prosedurdan sonra hamilə qala bilməsi mümkündür.</span></p>', 'usaqliqboynuxercengipaptest-1627763836.jpg', 0, 0, 0, 1),
(28, 0, 0, 1622493856, '', '', 'Yumurtalıq xərçəngindən sağalmaq mümkündür', '', '', '', '', '', '', '', '', '<p><span style="font-size: 18px;">Dəyərli xanımlar, bizə hədsiz sayda ünvanlanan suallarından biri də "yumurtalıq xərçəngindən tamamilə sağalmaq mümkündürmü?" sualı olur. Bəli, mümkündür! Ancaq hər zaman dönə-dönə qeyd etdiyimiz kimi erkən müayinə, erkən diaqnoz çox vacibdir və həyati önəm daşıyır!!!</span></p>', 'yumurtaliqxercengindensagalmaqmumkundur-1627764316.jpg', 0, 0, 0, 1),
(29, 0, 0, 1628362833, '', '', 'Müsbət HPV testi nə deməkdir?', '', '', '', '', '', 'Biz onkoginekoloqlara HPV(İnsan Popilloma Virusu) ilə bağlı çoxlu suallar gəlməyə davam edir.', '', '', '<p><span title="Edited"><span style="font-size: 18px;">Biz onkoginekoloqlara HPV(İnsan Popilloma Virusu) ilə bağlı çoxlu suallar gəlməyə davam edir.</span><br /><br /><span style="font-size: 18px;">Qeyd edək ki, HPV testinin nəticəsinin müsbət olmağı xərçəng xəstəsi olduğunuz mənasına gəlmir.</span><br /><br /><span style="font-size: 18px;">HPV virusu bulaşdıqdan sonra virusun qalıcı olmağı və xərçəng riski daşımağı sadəcə 2-3% təşkil edir.</span><br /><br /><span style="font-size: 18px;">HPV tip 16 və 18 virusun ən riskli növləridir.</span><br /><br /><span style="font-size: 18px;">Əgər bu növlərin cavabı müsbətdirsə, Pap smear testi və Kolposkopiya dediyimiz kameralı cihazla uşaqlıq boynunun müayinə olunması məsləhətdir. Qeyd edək ki, HPV testləri 5 ildən bir yüksək riskli (High-risk HPV) HPV-ləri təyin etmək üçün aparılır.</span><br /></span></p>\n<div id="gtx-trans" style="position: absolute; left: 399px; top: -20px;">&nbsp;</div>', '2108083163272637123321343392308602299715734n-1629572493.jpg', 0, 0, 0, 1),
(30, 0, 0, 1627672062, '', '', 'Uşaqlıq boynu xərçənginin skrininqi', '', '', '', '', '', 'Dəyərli xanımlar, erkən müayinənin, erkən diaqnozun, həyat qurtardığını unutmayaq!', '', '', '<p><span style="font-size: 18px;">Dəyərli xanımlar, erkən müayinənin, erkən diaqnozun, həyat qurtardığını unutmayaq!</span></p>', 'usaqliqboynuxercengininskrininqi-1629572880.jpg', 0, 0, 0, 1),
(31, 0, 0, 1626808347, '', '', 'Vulva xərçəngi nədir ? əlamətləri nələrdir?', '', '', '', '', '', 'Vulva xərçəngi - xarici cinsiyyət orqanının bədxassəli şişlərdir.', '', '', '<p><span style="font-size: 18px;">Vulva xərçəngi - xarici cinsiyyət orqanının bədxassəli şişlərdir. Statistik olaraq az rast gəlinən xərçəng növü olsa da, bu xəstəlikdən əziyyət çəkən pasiyentlərimiz gözlə görünən, əllə toxunan bir orqan olmasına baxmayaraq daha çox gecikmiş hallarda müraciət edirlər. Çox təəssüflər olsun ki, xanımlar xarici cinsiyyət orqanı olan vulvada hər hansı bir ağrı, qızartı, yara, qaşıntı və ya törəmə olduqda özləri müdaxilə edərək patalogiyanı daha da böyüdürlər.</span></p>\n<p><span style="font-size: 18px;">✔️Vulva xərçənginin əsas əlamətləri:</span><br /><span style="font-size: 18px;">♀️Normal olmayan qanamalar</span><br /><span style="font-size: 18px;">♀️Xarici cinsiyyət orqanında qaşıntı</span><br /><span style="font-size: 18px;">♀️Dəridə qabıqlanma</span><br /><span style="font-size: 18px;">♀️Sidiyə getmə zamanı ağrı</span><br /><span style="font-size: 18px;">♀️Cinsi əlaqə zamanı ağrı</span><br /><span style="font-size: 18px;">♀️Qasıq ağrısı</span><br /><span style="font-size: 18px;">♀️Sağalmayan yaralar</span><br /><span style="font-size: 18px;">♀️Vulva dərisində şişlik və yaxud da ələ gələn törəmə</span><br /><span style="font-size: 18px;">♀️Göynəmə</span><br /><span style="font-size: 18px;">♀️Dəridə qalınlaşma və s.</span></p>\n<p><span style="font-size: 18px;">Əgər bu əlamətlər və əsasən də törəmə olduğunu hiss edisinizə, mütləq onkoginekoloqun müayinəsindən keçin. Qeyd edək ki, bütün ginekoloji xərçənglərdə olduğu kimi Vulva xərçəngində də erkən diaqnoz həyati önəm daşıyır.</span></p>', 'vulvaxercenginedir-1629573216.jpg', 0, 0, 0, 1),
(33, 0, 0, 1627845665, '', '', 'Onkoloji xəstəliklərin müalicəsində D vitaminin rolu', '', '', '', '', '', 'Ölkəmizdə və bütün dünyada D vitamini çatışmazlığı diqqət edilməsi vacib olan sağlamlıq problemlərindəndir. Bəs D Vitaminin xüsusilə bəzi sistem xəstəliklərinə və onkoloji xəstəliklərə faydalı olduğunu bilirsinizmi?', '', '', '<p><span style="font-size: 18px;">Ölkəmizdə və bütün dünyada D vitamini çatışmazlığı diqqət edilməsi vacib olan sağlamlıq problemlərindəndir. Bəs D Vitaminin xüsusilə bəzi sistem xəstəliklərinə və onkoloji xəstəliklərə faydalı olduğunu bilirsinizmi? </span><br /><span style="font-size: 18px;">Əziz izləyicilər, qeyd edim ki, D vitaminin ən vacib qaynağı günəş şüalarıdır. Xalq dili ilə desək ğünəş vannası ilə gündəlik D vitamini ehtiyaclarınızın 80 %-ni qarşılaya bilərsiniz. D vitamini immunitet sisteminin gücləndirilməsi üçün vacibdir. </span></p>\n<p><span style="font-size: 18px;">Günəş şüalarının təsirindən dəridə yaranan D vitamini onkoloji xəstəliklərdə və ümumiyyətlə xəstəliklərin proflaktikasında, immun sisteminin möhkəmləndirilməsində danılmaz rola malikdir. </span><br /><span style="font-size: 18px;">Araşdırmalar göstərir ki , D vitamini Kalsium və fosfor mübadiləsini tənzimləyir, sümükləri və dişləri kalsiumla gücləndirir. Hüceyrələrin böyüməsində, əzələ və sinir sistemlərinin nizamlı fəaliyyətində mühüm rol oynayır. Qan təzyiqinin tənzimlənməsində və immunitet sisteminin gücləndirilməsində də əhəmiyyətli bir rola sahibdir. Son illərdə aparılan araşdırmalar sübut edir ki, D vitamini yoğun bağırsaq, sümük, dəri , süd vəzi xərçəngi, ümumiyyətlə onkoloji xəstəliklər üzərində qoruyucu təsirə malikdir.</span></p>\n<p><span style="font-size: 18px;">Qeyd edək ki, D vitaminini günəş şüaları ilə qəbul etmək üçün düzgün saatlara diqqət etmək vacibdir. Əgər D vitamini Onkoloji xəstəliklər zamanı həm profilaktika, həm də remissiya dövründə dərman şəkilində qəbul ediləcəksə, mütləqdir ki, qanda D vitamini səviyyəsi yoxlanılsın və D vitamini həkim tərəfindən təyin edilsin.</span></p>', 'd-vitamini-xercengin-sagalmasinda-rolu-1629573762.jpg', 0, 0, 0, 1),
(32, 0, 0, 1626894956, '', '', 'Endometrial xərçəngin əlamətləri', '', '', '', '', '', 'Endometrial xərçəngi ilə bağlı ən çox qarşılaşdığımız şikayətlər postmenopozal vajinal qanaxmalardır.', '', '', '<p><span style="font-size: 18px;">Endometrial xərçəngi ilə bağlı ən çox qarşılaşdığımız şikayətlər postmenopozal vajinal qanaxmalardır. Menopoz sonrası qanamaları olan xəstələrin gecikdirmədən bir ginekoloqun müayinəsindən keçmələri tövsiyə olunur. Menopozdan əvvəl isə şiddətli qanamalar varsa, aybaşı dövrü uzun çəkirsə, iki aybaşı arası qanaxma olursa, endometrial biopsi götürülməsi məsləhətdir. Xüsusilə də də 40 yaş+ xəstələrdə qeyd edilən əlamətlər olduqda biopsi alınaraq patoloji dəyərləndirilmə edilməli və endometrial xərçəng və ya xərçəng öncəsi lezyonların (endometrial hiperplazi-uşaqlıq divarının qalınlaşması) olub olmadığı aşkarlanmalıdır.</span></p>\n<p><span style="font-size: 18px;">Dəyərli xanımlar, erkən müayinənin, erkən diaqnozun, həyat qurtardığını unutmayaq!</span></p>\n<div id="gtx-trans" style="position: absolute; left: -68px; top: -20px;">&nbsp;</div>', 'endometrial-xercengin-elametleri-1629573356.jpg', 0, 0, 0, 1),
(34, 0, 0, 1627932243, '', '', 'Ginekoloji xərçənglərin müayinə və müalicəsi', '', '', '', '', '', 'Ginekoloji xərçənglərin müayinə və müalicəsi', '', '', '<p><span style="font-size: 18px;">Ginekoloji xərçənglərin müayinə və müalicəsi</span></p>', 'ginekoloji-xercenglerin-mualicesi-1629573903.jpg', 0, 0, 0, 1),
(35, 0, 0, 1628623545, '', '', 'çəhrayi rəng dünyada sürətlə yayılan süd vəzi xərçəngi ilə mübarizə aparmığın və bu barədə məlumatlanmağın simvoludur', '', '', '', '', '', 'Bilirsinizmi çəhrayi rəng dünyada sürətlə yayılan süd vəzi xərçəngi ilə mübarizə aparmığın və bu barədə məlumatlanmağın simvoludur.', '', '', '<p><span style="font-size: 18px;">Bilirsinizmi çəhrayi rəng dünyada sürətlə yayılan süd vəzi xərçəngi ilə mübarizə aparmığın və bu barədə məlumatlanmağın simvoludur.</span><br /><span style="font-size: 18px;">Burada əsas mesaj süd vəzi xərçənginin erkən diaqnozunun vacibliyini vurğulamaqdır.</span><br /><span style="font-size: 18px;">Qeyd edim ki, süd vəzi xərçəngi qadın orqanizmində olan xərçənglər arasında dünyada birinci yerdədir. Reproduktiv orqanların patologiaları ilə əlaqəli ola bilir. Ginekoloji orqanlarda olan hər hansı hormonal dəyişikliklər və patologiyalar süd vəzi xərçəngini tətikləyə bilir. Həmçinin süd vəzi xərçəngi olan xanımların gələcəkdə qadın cinsiyyət orqanlarında patalogiyalar formalaşa, endometrial xərçəng və ya metastatik yumurtalıq xərçəngi əmələ gələ bilər‼️ Bu səbəbdən də ginekoloji müayinələr və süd vəzi müayinələri bir yerdə, vaxtlı vaxtında aparılmalıdır</span><br /><br /><span style="font-size: 18px;">Əziz xanımlar, sağlam olmaq hamımızın haqqıdır. Sağlamlığımızı qorumaq və günümüzün bəlasına çevrilən qadın orqanizmi xərçənglərindən müayinələrimizi gecikdirmədən və erkən qoyulan diaqnozla xilas olmaq isə öz əlimizdədir.</span></p>', 'cehrayi-reng-ve-xerceng-1629574047.jpg', 0, 0, 0, 1),
(38, 0, 0, 1629142651, '', '', 'Erkən müayinənin, erkən diaqnozun, həyat qurtardığını unutmayaq!', '', '', '', '', '', 'Erkən müayinənin, erkən diaqnozun, həyat qurtardığını unutmayaq!', '', '', '<p>Erkən müayinənin, erkən diaqnozun, həyat qurtardığını unutmayaq!</p>', 'yumurtaliq-xercengleri-ucun-ilde-bir-defe-muayine-vacibdir-1629574696.jpg', 0, 0, 0, 1),
(36, 0, 0, 1628018983, '', '', 'Sağlam həyat tərzi xərçəng riskini azaldır', '', '', '', '', '', 'Sağlam bir həyat tərzi ilə xərçəng riskini azaltmaq mümkündür. Bəs bunun üçün nələrə diqqət etməliyik?', '', '', '<p><span style="font-size: 18px;">Sağlam bir həyat tərzi ilə xərçəng riskini azaltmaq mümkündür. Bəs bunun üçün nələrə diqqət etməliyik?</span><br /><span style="font-size: 18px;">Xərçəng riskini azaltmaq üçün gündə ən az 30 dəqiqə idman etmək və fiziki aktivliyi artırmaq lazımdır.</span><br /><span style="font-size: 18px;">Bundan əlavə artıq çəki , piylənmə bağırsaq, qaraciyər, böyrək, qadın xərçəngləri də daxil olmaqla bir çox xərçəng növlərini tətikləyə bilir.</span><br /><span style="font-size: 18px;">Qeyd edim ki, əziz xanımlar, sağlam həyat tərzi dedikdə eyni zamanda rutin müayinələr də nəzərdə tutulur. Nə qədər aktiv bir həyat tərziniz olsa da, nə qədər idmanla məşğul olsanız da, digər səbəblərdən də xərçəng riski yarana bilər. Rutin müayinələr və erkən diaqnozla bu xəstəliyin öhtəsindən gəlmək və həyat keyfiyyətini daim yüksək səviyyədə tutmaq mümkündür.</span></p>', 'saglam-heyat-terzi-xerceng-riskini-azaldir-1629574243.jpg', 0, 0, 0, 1),
(37, 0, 0, 1629055967, '', '', 'Qız uşaqlarında yumurtalıq disfunksiyaları', '', '', '', '', '', 'Yumurtalıqların fəaliyyətində baş verən dəyişikliklər fonunda qadın orqanizmində müxtəlif tipli pozulmalar ola bilir.', '', '', '<p><span style="font-size: 18px;">Yumurtalıqların fəaliyyətində baş verən dəyişikliklər fonunda qadın orqanizmində müxtəlif tipli pozulmalar ola bilir. Qadın cinsiyyət orqanlarının əsas ifrazat mənbəyi olan yumurtalıqlar qadın orqanizmində vacib vəzlərdən biridir. Bu vəzlərin fəaliyyəti pozulduqda orqanizmdə hormonal disfunksiyalar yaranır. Bu özünü bir çox şikayətlərlə biruzə verir. Bəzi hallarda menstruasiya dövrü fazaların xarakterində dəyişikliklər ola bilir. Belə ki, xanımlar güclü, uzunmüddət davam edən, ağrılı aybaşı keçirirlər. Digər hallarda isə aybaşı fazasının qısalması, (ayda iki dəfə və daha çox), və ya aybaşı dövrü fazaları arasındakı dövrün uzanması baş verir. Normalda qadın 28 gündən bir 5-7 gün davam edən aybaşı görməlidir. Yuvenil, reproduktiv və premenopozal dövrlərdə olan qadınların yumurtalıq disfunksiyaları kimi problemləri ola bilər.</span><br /><span style="font-size: 18px;">Bu gün ilk olaraq sizə yuvenil dövrdə olan yumurtalıq disfunksiyası haqqında ətraflı məlumat verməyi düşündüm.</span><br /><span style="font-size: 18px;">Belə ki, menarxi dövründə - (qızlarda ilk aybaşı dövrü. Orta statistikaya əsasən bu dövr 11-13 yaşlarında başlayır) cinsi yetişkənlik dövründə olan qızlarda bu dövr 16-18 yaşa qədər davam edir. Hansı ki, artıq reproduktiv sistem tam formalaşmış olur və hamiləlik üçün orqanizm hazır olur. Yəni İlk başlanılan menarxi dövründən 16-18 yaşa kimi olan dövrdə yumurtalıq disfunksiyaları yuvenil desfunksiaları adlanır.</span><br /><span style="font-size: 18px;">Məhz bu dövrdə qızlar qeyri reguliar, ağrılı və güclü (hətta qanaxmaya səbəb olacaq dərəcədə) aybaşılarla rastlaşırlar. Çox təəssüf ki, bu yaşda olan qızlarımız heç bir müayinələrdən keçmədən yersiz hormonal preparatlarla müalicə olunurlar. Yuvinil dövrdə olan yumurtalıq disfunksiyaları ciddi problemlərə, hətta sonsuzluğa da gətirib çıxarır. Bu dövrdə Yumurtalıq disfunksiyasının digər əlamətləri piylənmə və həddindən artıq tüklənmə də ola bilər. Bu səbəblərdən ginekoloji müayinələr gecikdirilməməli, düzgün müayinə və müalicələr təyin olunmalıdır. Hormonal, ultrason, qalxanvari vəzin müayinəsi, ehtiyac olarsa, baş-beyin MRT-si həyata keçirilməlidir. Adətən bir il ərzində ümumi səhətinə mənfi təsir edən heç bir əlamət yoxdursa, yuvenil dövrdə olan qızlara heç bir müalicə təyin olunmamalı, sadəcə dinamik nəzarət edilməlidir.</span></p>', 'qiz-usaqlarinda-yumurtaliqlarin-formalasmasi-1629574527.jpeg', 0, 0, 0, 1),
(39, 0, 0, 1629229183, '', '', 'Sağlam qidalanmanın onkoloji xəstəliklərin müalicəsində rolu', '', '', '', '', '', 'Hamımız bilirik ki, sağlam həyat sürmək üçün, sağlam qidalanma da çox vacibdir. Bəs, sağlam qida dedikdə nəyi nəzərdə tuturuq?', '', '', '<p><span style="font-size: 18px;">Hamımız bilirik ki, sağlam həyat sürmək üçün, sağlam qidalanma da çox vacibdir. Bəs, sağlam qida dedikdə nəyi nəzərdə tuturuq?</span></p>\n<p><span style="font-size: 18px;">Sağlam qidalanma, insanın böyüməsi, inkişafı, sağlam və məhsuldar həyatı üçün lazım olan qida maddələrinin kifayət miqdarda istifadəsidir. Fiziki olaraq aktiv olmaq, normadaxili çəkini saxlamaq, siqaret çəkməmək, spirt istehlakını mümkün qədər məhdudlaşdırmaq və sağlam qidalanmaq bədəninizin güclü və dinamik qalması üçün vacib amillərdir.</span></p>\n<p><span style="font-size: 18px;">Sağlam pəhriz saxlamaq xərçəng xəstələri üçün çox vacibdir. Zülal, karbohidratlar, yağlar, vitaminlər və minerallar kimi ehtiyac duyduğunuz qidaları əldə etmək bu xəstəliklə mübarizə aparmağa kömək edəcək. Bir çox insan xərçəng müalicəsindən sonra uzun illər sağlam həyat sürür. Bu səbəblə, sağlam qidalanma və fiziki aktiv olmaq, daha dinamik və sağlam həyat yaşamaq üçün vacibdir.</span></p>\n<p><span style="font-size: 18px;">Xərçəng xəstələrində böyük əhəmiyyət kəsb edən qidalanma anlayışı, digər insanların tətbiq etməli olduğu pəhrizdən çox da fərqlənmir. Burada vacib olan amil müalicənin yan təsirlərindən asılı olaraq fərdin adekvat və balanslı bir pəhrizə davam etməsidir.</span></p>\n<p><span style="font-size: 18px;">Müalicədən əvvəl xəstələrə aşağıdakı müxtəlif sağlam qidalanma tövsiyələri verilir.</span></p>\n<p><span style="font-size: 18px;">✅Gündə ən az 5 porsiya müxtəlif rəngli tərəvəz və meyvələr istehlak edin.</span><br /><span style="font-size: 18px;">✅Kəpəkli taxıl məhsullarına üstünlük verin.</span><br /><span style="font-size: 18px;">✅Xüsusilə yağlı ət istehlakını azaldın.</span><br /><span style="font-size: 18px;">✅Protein istehlakınızı artırın.</span><br /><span style="font-size: 18px;">✅Kimyaterapiyanın zərərli təsirlərini minimuma endirmək üçün xüsusilə müalicə zamanı ən az 2 litr su için</span><br /><span style="font-size: 18px;">✅ Qidalandırıcı təsiri olmayan və ya az olan, tərkibində həddindən artıq şəkər və yağ olan qidalardan çəkinin.</span></p>', 'about-breadcrumb-1634558905.jpg', 0, 0, 0, 1),
(40, 0, 0, 1632509672, '', '', 'Uşaqlıq boynu xərçənginin əlamətləri', '', '', '', '', '', 'Uşaqlıq boynu xərçəngi qadınlarda ən çox görülən 5 xərçəng növündən biridir. Erkən stadiyalarda hər hansı bir xüsusi əlamətlə özünü biruzə verməsə də, araşıdırmalara və təcrübələrə əsasən qeyd edək ki,', '', '', '<p><span style="font-size: 14px;">Uşaqlıq boynu xərçəngi qadınlarda ən çox görülən 5 xərçəng növündən biridir. Erkən stadiyalarda hər hansı bir xüsusi əlamətlə özünü biruzə verməsə də, araşıdırmalara və təcrübələrə əsasən qeyd edək ki,</span></p>\n<ul>\n<li><span style="font-size: 14px;">Uşaqlıq yolu qanamaları və kontakt, postkoital qanamalar ( cinsi əlaqədən sonra)</span></li>\n<li><span style="font-size: 14px;">Qeyri-requlyar vaginal qanamalar</span></li>\n<li><span style="font-size: 14px;">Pis qoxulu və qanlı ifrazatların gəlməsi uşaqlıq yolu xərçənginin yaranmasından xəbər verə bilər.</span></li>\n</ul>\n<p><br /><span style="font-size: 14px;">Şiş yuxarı hissədə uşaqlıqarası boşluğa, aşağı hissədə vaginaya, yanlara doğru isə qasıq divarına doğru yayıla bilər.</span><br /><span style="font-size: 14px;">Şişin yayılmasına əsasən:</span></p>\n<ul>\n<li><span style="font-size: 14px;">Ayaq və qasıq ağrıları</span></li>\n<li><span style="font-size: 14px;">Fistulaların yaranması (serviko-vaginal ,veziko-vaginal ,serviko-rektal, rekto-vaginal)</span></li>\n<li><span style="font-size: 14px;">Hidronefroz və böyrək funksiyasının pozğunluğu</span></li>\n<li><span style="font-size: 14px;">Anemiya</span></li>\n<li><span style="font-size: 14px;">Aşağı ətraflarda ödəm kimi şikayətlərlə də qarşılaşmaq mümkündür.</span></li>\n</ul>\n<p><br /><span style="font-size: 14px;">HPV infeksiyaları uşaqlıq boynunda meydana gələn hüceyrə dəyişikliklərinin ən əsas səbəbidir. HPV virusu cinsi əlaqədən sonra servikal hüceyrələrin içərisinə yerləşir. Qadınların 50-80%-i nə vaxtsa HPV infeksiyası ilə qarşılaşa bilərlər. İmmunitet sistemimiz 12-18 ay ərzində 90% ehtimalla bu cür infeksiyaları yox edə biləcək gücdədir. HPV infeksiyasına yoluxmaq uşaqlıq boynu xərçəngi olmaq demək deyil.</span><br /><br /><span style="font-size: 14px;">HPV infeksiyasının xərçəng tipli olanları servikal hüceyrələrdə genetik dəyişikliklər yaradaraq kanserogen dəyişikliklərə səbəb ola bilərlər. Bu təxminən 10-15 illik bir müddətdə baş verir. Bu səbəblə həkimlər müayinələr zamanı xərçəngə çevrilmədən əvvəl bu xəstəliyi aşkarlayıb qarşısını ala bilərlər.</span></p>', 'usaqliqboynuxercengi-1632509792.jpg', 0, 0, 0, 1);



-- ---------------------------------------------------------
--
-- Table structure for table : `news_gallery`
--
-- ---------------------------------------------------------

CREATE TABLE `news_gallery` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) NOT NULL,
  `name_en` varchar(255) NOT NULL,
  `name_ru` varchar(255) NOT NULL,
  `name_az` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `video_url` varchar(255) NOT NULL,
  `position` int(11) NOT NULL,
  `active` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;



-- ---------------------------------------------------------
--
-- Table structure for table : `our_cash_desks`
--
-- ---------------------------------------------------------

CREATE TABLE `our_cash_desks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `payment_type` tinyint(1) NOT NULL COMMENT '0=>income,1=>out,2=>both',
  `important` tinyint(1) NOT NULL,
  `position` int(11) NOT NULL,
  `active` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;



-- ---------------------------------------------------------
--
-- Table structure for table : `partners`
--
-- ---------------------------------------------------------

CREATE TABLE `partners` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name_en` varchar(255) NOT NULL,
  `name_ru` varchar(255) NOT NULL,
  `name_az` varchar(255) NOT NULL,
  `short_text_en` varchar(500) NOT NULL,
  `short_text_ru` varchar(500) NOT NULL,
  `short_text_az` text NOT NULL,
  `full_text_en` text NOT NULL,
  `full_text_ru` text NOT NULL,
  `full_text_az` text NOT NULL,
  `image` varchar(255) NOT NULL,
  `link` varchar(255) NOT NULL,
  `position` int(11) NOT NULL,
  `active` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `partners`
--

INSERT INTO `partners` (`id`, `name_en`, `name_ru`, `name_az`, `short_text_en`, `short_text_ru`, `short_text_az`, `full_text_en`, `full_text_ru`, `full_text_az`, `image`, `link`, `position`, `active`) VALUES
(1, '', 'Partner 1', 'Partner 1', '', '', '', '', '', '', 'client-03-1635530420.png', 'https://zohremesiyeva.az/az/', 1, 1),
(2, '', '', 'Partner 2', '', '', '', '', '', '', 'client-03-1635530459.png', 'https://zohremesiyeva.az/az/', 2, 1);



-- ---------------------------------------------------------
--
-- Table structure for table : `patients`
--
-- ---------------------------------------------------------

CREATE TABLE `patients` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name_en` varchar(255) NOT NULL,
  `name_ru` varchar(255) NOT NULL,
  `name_az` varchar(255) NOT NULL,
  `title_en` varchar(255) NOT NULL,
  `title_ru` varchar(255) NOT NULL,
  `title_az` varchar(255) NOT NULL,
  `video_url` varchar(255) NOT NULL,
  `position` int(11) NOT NULL,
  `active` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=31 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `patients`
--

INSERT INTO `patients` (`id`, `name_en`, `name_ru`, `name_az`, `title_en`, `title_ru`, `title_az`, `video_url`, `position`, `active`) VALUES
(24, '', '', 'Onkoginekoloq Dr. Könül Mərdanova', '', '', 'Sentyabr Ginekoloji xərçənglər haqqında maariflərdirmə ayı kimi - Onkoginekoloq Könül Mərdanova', 'https://www.youtube.com/watch?v=KEjXMjSau-Q&t=315s', 14, 1),
(25, '', '', 'Onkoginekoloq Dr. Könül Mərdanova', '', '', 'Uşaqlıq boynunda eroziya', 'https://www.youtube.com/watch?v=-3svJbJhcj0', 15, 1),
(26, '', '', 'Onkoginekoloq Dr. Könül Mərdanova', '', '', 'Şəkər xəstələri ginekoloji xərçənglərin risk qruplarına daxildirlərmi?', 'https://www.youtube.com/watch?v=u2XF6tWytec&t=4s', 16, 1),
(22, '', '', 'Onkoginekoloq Dr. Könül Mərdanova', '', '', 'Milli Onkologiya Mərkəzinin Ginekologiya bölməsində gündəlik iş prosesi', 'https://www.youtube.com/watch?v=Qeir4NvoqZU', 12, 0),
(23, '', '', 'Onkoginekoloq Dr. Könül Mərdanova', '', '', 'Milli Onkologiya Mərkəzi - Ginekologiya bölməsi', 'https://www.youtube.com/watch?v=IMRSO1BNYKA', 13, 1),
(3, '', 'Износ хряща тазобедренного сустава', 'Onkoginekoloq Dr. Könül Mərdanova', '', 'Отзыв Ирады ханум, страдающей от износа хряща тазобедренного сустава, о стволовых клетках', 'Onkoginekoloq Dr. Könül Mərdanova', 'https://www.youtube.com/watch?v=4ChVuRXcgkc', 6, 1),
(20, '', '', 'Onkoginekoloq Dr. Könül Mərdanova', '', '', 'Uşaqlığın patoloji qanaxmaları - Onkoginekoloq Dr. Könül Mərdanova', 'https://www.youtube.com/watch?v=inBPSawvjYg&t=1s', 10, 1),
(21, '', '', 'Onkoginekoloq Dr. Könül Mərdanova', '', '', 'Uşaqlıq boynunun xoşxassəli patologiyaları nələrdir?', 'https://www.youtube.com/watch?v=UXqHEPALoYc&t=18s', 11, 1),
(17, '', '', 'Onkoginekoloq Dr. Könül Mərdanova', '', '', 'Histeroskopiya polipektomiya əməliyyatı', 'https://www.youtube.com/watch?v=-j8tux8qZ_I', 7, 1),
(18, '', '', 'Onkoginekoloq Dr. Könül Mərdanova', '', '', 'ONKOGINEKOLOQA NƏ VAXT MÜRACİƏT EDİLMƏLİDİR? - Onkoloq Dr. Könül Mərdanova', 'https://www.youtube.com/watch?v=uCAGJRS3Tt4', 8, 0),
(19, '', '', 'Onkoginekoloq Dr. Könül Mərdanova', '', '', 'Histeroskopiya müayinəsi nədir? Hansı hallarda histeroskopiya müayinəsi həyata keçirilir?', 'https://www.youtube.com/watch?v=CqMK4gTRC4w', 9, 1),
(11, '', 'Процедура с применением стволовых клеток', 'Onkoginekoloq Dr. Könül Mərdanova', '', 'Отзыв Тамары ханум, пациентки получившей пользу от процедур с применением стволовых клеток', 'Pap smear testi nədir?', 'https://www.youtube.com/watch?v=MIHgInNRKHc', 1, 1),
(12, '', 'Диагностический фаcетный блок', 'Onkoginekoloq Dr. Könül Mərdanova', '', 'Отзыв пациента, страдающего болями в области головы и шеи, после процедуры', 'Uşaqlıq boynunun xoşxassəli xəstəlikləri zamanı nələrə diqqət etməliyik?', 'https://www.youtube.com/watch?v=PMgv_o-Lh_I', 2, 1),
(13, '', 'Эпидуральный катетер с перманентной помпой (туннельный эпидуральный катетер)', 'Onkoginekoloq Dr. Könül Mərdanova', '', 'Отзыв пациента, страдающего от раковых болей, после процедуры', 'Yumurtalıq xərçənginin əlamətləri və müayinə metodları', 'https://www.youtube.com/watch?v=UCQjwCKKEdU', 3, 1),
(15, '', '', 'Onkoginekoloq Dr. Könül Mərdanova', '', '', 'Kolposkopiya nədir? Kolposkopiya Ginekoloji müayinələrdə nə üçün vacibdir?', 'https://www.youtube.com/watch?v=GzDryYioDaE&t=5s', 4, 1),
(16, '', '', 'Onkoginekoloq Dr. Könül Mərdanova', '', '', 'Onkoginekoloq Dr. Könül Mərdanova', 'https://www.youtube.com/watch?v=4ChVuRXcgkc', 5, 1),
(27, '', '', 'Onkoginekoloq Dr. Könül Mərdanova', '', '', 'Onkoloji xəstəlik şübhəsi zamanı kolposkopiya müayinəsi', 'https://www.youtube.com/watch?v=tdpPJR2oEHg', 17, 1),
(28, '', '', 'Onkoginekoloq Dr. Könül Mərdanova', '', '', 'Onkoginekoloji xəstəlik səbəbilə vaxtında həkimə müraciət edərək sağalan xəstəmiz', 'https://www.youtube.com/watch?v=_okz_LWlVeA&t=39s', 18, 1),
(29, '', '', 'Onkoginekoloq Dr. Könül Mərdanova', '', '', 'Uşaqlıq boynunun xərçəngi -Milli Onkologiya Mərkəzinin Onkoginekoloqu Könül Mərdanova', 'https://www.youtube.com/watch?v=my9laZzEYbw', 19, 0),
(30, '', '', 'Onkoginekoloq Dr. Könül Mərdanova', '', '', 'Uşaqlıq boynunun bədxassəli törəmələri', 'https://www.youtube.com/watch?v=IhFFYyEz54g', 20, 1);



-- ---------------------------------------------------------
--
-- Table structure for table : `payments`
--
-- ---------------------------------------------------------

CREATE TABLE `payments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `worker_id` int(11) NOT NULL,
  `program_id` int(11) NOT NULL,
  `cash_desk_id` int(11) NOT NULL,
  `client_name` varchar(255) NOT NULL,
  `amount` double NOT NULL,
  `payment_type` tinyint(1) NOT NULL COMMENT '0=>income,1=>out',
  `note` varchar(255) NOT NULL,
  `datetime` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;



-- ---------------------------------------------------------
--
-- Table structure for table : `photo_albums`
--
-- ---------------------------------------------------------

CREATE TABLE `photo_albums` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name_en` varchar(255) NOT NULL,
  `name_ru` varchar(255) NOT NULL,
  `name_az` varchar(255) NOT NULL,
  `text_en` text NOT NULL,
  `text_ru` text NOT NULL,
  `text_az` text NOT NULL,
  `image` varchar(255) NOT NULL DEFAULT '0',
  `position` int(11) NOT NULL,
  `datetime` int(11) NOT NULL DEFAULT 0,
  `active` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=22 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `photo_albums`
--

INSERT INTO `photo_albums` (`id`, `name_en`, `name_ru`, `name_az`, `text_en`, `text_ru`, `text_az`, `image`, `position`, `datetime`, `active`) VALUES
(20, '', '', 'adssadsa', '', '', '<p>dasdadad</p>', '25717e1410cc39d4b2832542cbb93bed--rip-paul-walker-cody-walker-1634650539.jpg', 1, 0, 1),
(21, '', '', 'wqqweqwe', '', '', '<p>weqweqwe</p>', 'home-3-welcome-bg-1-1634577760.jpg', 2, 0, 1);



-- ---------------------------------------------------------
--
-- Table structure for table : `photo_albums_gallery`
--
-- ---------------------------------------------------------

CREATE TABLE `photo_albums_gallery` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) NOT NULL,
  `name_en` varchar(255) NOT NULL,
  `name_ru` varchar(255) NOT NULL,
  `name_az` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL DEFAULT '0',
  `video_url` varchar(255) NOT NULL DEFAULT '0',
  `position` int(11) NOT NULL,
  `active` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=64 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `photo_albums_gallery`
--

INSERT INTO `photo_albums_gallery` (`id`, `parent_id`, `name_en`, `name_ru`, `name_az`, `image`, `video_url`, `position`, `active`) VALUES
(17, 10, '', '', 'Ramazan ayına özəl keçirilən pulsuz müayinə kampaniyasından fotolar.', '610052433723837533730668617988953305251840o-1581597205.jpg', 0, 1, 1),
(18, 10, '', '', 'Ramazan ayına özəl keçirilən pulsuz müayinə kampaniyasından fotolar.', '611981633723839067063842842669236373946368o-1581597383.jpg', 0, 14, 1),
(19, 10, '', '', 'Ramazan ayına özəl keçirilən pulsuz müayinə kampaniyasından fotolar.', '61223503372383926706382234667229117939712o-1581597383.jpg', 0, 13, 1),
(20, 10, '', '', 'Ramazan ayına özəl keçirilən pulsuz müayinə kampaniyasından fotolar.', '614273863723838600397226320647101709549568o-1581597383.jpg', 0, 12, 1),
(21, 10, '', '', 'Ramazan ayına özəl keçirilən pulsuz müayinə kampaniyasından fotolar.', '614366723723839800397103588721973565325312o-1581597383.jpg', 0, 11, 1),
(22, 10, '', '', 'Ramazan ayına özəl keçirilən pulsuz müayinə kampaniyasından fotolar.', '614768323723838100397277494152937162145792o-1581597383.jpg', 0, 10, 1),
(23, 10, '', '', 'Ramazan ayına özəl keçirilən pulsuz müayinə kampaniyasından fotolar.', '615169573723835700397512117145884511698944o-1581597383.jpg', 0, 9, 1),
(24, 10, '', '', 'Ramazan ayına özəl keçirilən pulsuz müayinə kampaniyasından fotolar.', 'pulsuzmuayinekampaniyasi-1581597383.jpg', 0, 8, 1),
(25, 10, '', '', 'Ramazan ayına özəl keçirilən pulsuz müayinə kampaniyasından fotolar.', 'pulsuzmuayinekampaniyasi1-1581597383.jpg', 0, 7, 1),
(26, 10, '', '', 'Ramazan ayına özəl keçirilən pulsuz müayinə kampaniyasından fotolar.', 'pulsuzmuayinekampaniyasi2-1581597383.jpg', 0, 6, 1),
(27, 10, '', '', 'Ramazan ayına özəl keçirilən pulsuz müayinə kampaniyasından fotolar.', 'pulsuzmuayinekampaniyasi3-1581597383.jpg', 0, 5, 1),
(28, 10, '', '', 'Ramazan ayına özəl keçirilən pulsuz müayinə kampaniyasından fotolar.', 'pulsuzmuayinekampaniyasi4-1581597383.jpg', 0, 4, 1),
(29, 10, '', '', 'Ramazan ayına özəl keçirilən pulsuz müayinə kampaniyasından fotolar.', 'pulsuzmuayinekampaniyasi5-1581597383.jpg', 0, 3, 1),
(30, 10, '', '', 'Ramazan ayına özəl keçirilən pulsuz müayinə kampaniyasından fotolar.', 'xronikiagrilarinmualicesi-1581597383.jpg', 0, 2, 1),
(31, 11, '', '', 'Kök hüceyrə prosedurundan fotolar', 'kokhuceyreproseduru-1581597810.jpg', 0, 15, 1),
(32, 11, '', '', 'Kök hüceyrə prosedurundan fotolar', 'kokhuceyreproseduru1-1581597810.jpg', 0, 16, 1),
(33, 16, '', '', 'Ağrı həkimi - Alqoloq Vüsal Eyvazov Mingəçevirdə xroniki ağrılardan əziyyət çəkən xəstələri qəbul etdi', 'agrihekimialqoloq-1583234858.jpg', 0, 1, 1),
(34, 16, '', '', 'Ağrı həkimi - Alqoloq Vüsal Eyvazov Mingəçevirdə xroniki ağrılardan əziyyət çəkən xəstələri qəbul etdi', 'agrihekimivusaleyvazov-1583234858.jpg', 0, 1, 1),
(35, 16, '', '', 'Ağrı həkimi - Alqoloq Vüsal Eyvazov Mingəçevirdə xroniki ağrılardan əziyyət çəkən xəstələri qəbul etdi', 'ciyinagrilarininmuayinesi-1583234858.jpg', 0, 1, 1),
(36, 16, '', '', 'Ağrı həkimi - Alqoloq Vüsal Eyvazov Mingəçevirdə xroniki ağrılardan əziyyət çəkən xəstələri qəbul etdi', 'dizagrilarininmuayinesi-1583234858.jpg', 0, 1, 1),
(37, 16, '', '', 'Ağrı həkimi - Alqoloq Vüsal Eyvazov Mingəçevirdə xroniki ağrılardan əziyyət çəkən xəstələri qəbul etdi', 'dizbelagrilarininmuayinesi-1583234858.jpg', 0, 1, 1),
(38, 16, '', '', 'Ağrı həkimi - Alqoloq Vüsal Eyvazov Mingəçevirdə xroniki ağrılardan əziyyət çəkən xəstələri qəbul etdi', 'dizmrtsi-1583234858.jpg', 0, 1, 1),
(39, 16, '', '', 'Ağrı həkimi - Alqoloq Vüsal Eyvazov Mingəçevirdə xroniki ağrılardan əziyyət çəkən xəstələri qəbul etdi', 'muayine-1583234858.jpg', 0, 1, 1),
(40, 16, '', '', 'Ağrı həkimi - Alqoloq Vüsal Eyvazov Mingəçevirdə xroniki ağrılardan əziyyət çəkən xəstələri qəbul etdi', 'vusaleyvazovmingecevirde-1583234858.jpg', 0, 1, 1),
(41, 16, '', '', 'Ağrı həkimi - Alqoloq Vüsal Eyvazov Mingəçevirdə xroniki ağrılardan əziyyət çəkən xəstələri qəbul etdi', 'vusaleyvazovmuayinede-1583234858.jpg', 0, 1, 1),
(42, 17, '', '', 'Dr. Vüsal Eyvazov "Səni axtarıram" verilişində xroniki ağrılardan əziyyət çəkən insanların şikayətlərini dinləyir', 'dr-vusal-eyvazov-seni-axtariram-verilisinde-1583516594.jpg', 0, 1, 1),
(43, 17, '', '', 'Dr. Vüsal Eyvazov "Səni axtarıram" verilişində xroniki ağrılardan əziyyət çəkən insanların şikayətlərini dinləyir', 'dr-vusal-eyvazov-seni-axtariram-verilisinde1-1583516594.jpg', 0, 1, 1),
(44, 17, '', '', 'Dr. Vüsal Eyvazov "Səni axtarıram" verilişində xroniki ağrılardan əziyyət çəkən insanların şikayətlərini dinləyir', 'dr-vusal-eyvazov-seni-axtariram-verilisinde2-1583516594.jpg', 0, 1, 1),
(45, 17, '', '', 'Dr. Vüsal Eyvazov "Səni axtarıram" verilişində xroniki ağrılardan əziyyət çəkən insanların şikayətlərini dinləyir', 'dr-vusal-eyvazov-seni-axtariram-verilisinde3-1583516594.jpg', 0, 1, 1),
(46, 17, '', '', 'Dr. Vüsal Eyvazov "Səni axtarıram" verilişində xroniki ağrılardan əziyyət çəkən insanların şikayətlərini dinləyir', 'dr-vusal-eyvazov-seni-axtariram-verilisinde5-1583516594.jpg', 0, 1, 1),
(47, 17, '', '', 'Dr. Vüsal Eyvazov "Səni axtarıram" verilişində xroniki ağrılardan əziyyət çəkən insanların şikayətlərini dinləyir', 'dr-vusal-eyvazov-seni-axtariram-verilisinde44-1583516594.jpg', 0, 1, 1),
(48, 18, '', '', 'Oynaq yeyilmələri üçün kök hüceyrə müalicəsi', 'alinankokhuceyreler-1583931441.jpg', 0, 1, 1),
(49, 18, '', '', 'Oynaq yeyilmələri üçün kök hüceyrə müalicəsi', 'kokhuceyre-1583931441.jpg', 0, 1, 1),
(50, 18, '', '', 'Oynaq yeyilmələri üçün kök hüceyrə müalicəsi', 'kokhuceyremualicesi-1583931441.jpg', 0, 1, 1),
(51, 18, '', '', 'Oynaq yeyilmələri üçün kök hüceyrə müalicəsi', 'kokhuceyremualicesiqarindanpiy-1583931441.jpg', 0, 1, 1),
(52, 18, '', '', 'Oynaq yeyilmələri üçün kök hüceyrə müalicəsi', 'kokhuceyreproseduru-1583931441.jpg', 0, 1, 1),
(53, 19, '', '', 'Beldə disk yırtığı səbəbi ilə yaranan ağrıların aradan qaldırılması üçün həyata keçirilən Radiofrekansla Dorsal Qanqlion Bloku prosedurundan fotolar', '1006718775914467114667681096506658202320896n-1590567606.jpg', 0, 1, 1),
(54, 19, '', '', 'Beldə disk yırtığı səbəbi ilə yaranan ağrıların aradan qaldırılması üçün həyata keçirilən Radiofrekansla Dorsal Qanqlion Bloku prosedurundan fotolar', '1008021175914465181334542755558713971441664n-1590567606.jpg', 0, 1, 1),
(55, 19, '', '', 'Beldə disk yırtığı səbəbi ilə yaranan ağrıların aradan qaldırılması üçün həyata keçirilən Radiofrekansla Dorsal Qanqlion Bloku prosedurundan fotolar', 'belagrilarininemeliyyatsizmualicesi-1590567606.jpg', 0, 1, 1),
(56, 19, '', '', 'Beldə disk yırtığı səbəbi ilə yaranan ağrıların aradan qaldırılması üçün həyata keçirilən Radiofrekansla Dorsal Qanqlion Bloku prosedurundan fotolar', 'diskyirtigi-1590567606.jpg', 0, 1, 1),
(57, 19, '', '', 'Beldə disk yırtığı səbəbi ilə yaranan ağrıların aradan qaldırılması üçün həyata keçirilən Radiofrekansla Dorsal Qanqlion Bloku prosedurundan fotolar', 'diskyirtigininemeliyyatsizmualicesi-1590567606.jpg', 0, 1, 1),
(58, 19, '', '', 'Beldə disk yırtığı səbəbi ilə yaranan ağrıların aradan qaldırılması üçün həyata keçirilən Radiofrekansla Dorsal Qanqlion Bloku prosedurundan fotolar', 'dorsalqanqlionbloku-1590567606.jpg', 0, 1, 1),
(59, 19, '', '', 'Beldə disk yırtığı səbəbi ilə yaranan ağrıların aradan qaldırılması üçün həyata keçirilən Radiofrekansla Dorsal Qanqlion Bloku prosedurundan fotolar', 'steroidinyeksiyasi-1590567606.jpg', 0, 1, 1),
(60, 19, '', '', 'Beldə disk yırtığı səbəbi ilə yaranan ağrıların aradan qaldırılması üçün həyata keçirilən Radiofrekansla Dorsal Qanqlion Bloku prosedurundan fotolar', 'vusaleyvazov-1590567606.jpg', 0, 1, 1),
(61, 10, '', '', 'asdsadad', 'veysel-dr-1-1618652332.jpg', 0, 15, 1),
(62, 20, '', '', 'dfdsfsdf', 'about-breadcrumb-1634651618.jpg', 0, 1, 1),
(63, 20, '', '', 'fdfdss', 'cavidseferli-1634651626.jpg', 0, 2, 1);



-- ---------------------------------------------------------
--
-- Table structure for table : `products`
--
-- ---------------------------------------------------------

CREATE TABLE `products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` varchar(255) NOT NULL,
  `author_id` int(11) NOT NULL,
  `datetime` int(11) NOT NULL,
  `name_en` varchar(255) NOT NULL,
  `name_ru` varchar(255) NOT NULL,
  `name_az` varchar(255) NOT NULL,
  `keywords_en` varchar(255) NOT NULL,
  `keywords_ru` varchar(255) NOT NULL,
  `keywords_az` varchar(255) NOT NULL,
  `short_text_en` varchar(500) NOT NULL,
  `short_text_ru` varchar(500) NOT NULL,
  `short_text_az` text NOT NULL,
  `full_text_en` text NOT NULL,
  `full_text_ru` text NOT NULL,
  `full_text_az` text NOT NULL,
  `image` varchar(255) NOT NULL,
  `read_count` int(11) NOT NULL DEFAULT 0,
  `comment_count` int(11) NOT NULL DEFAULT 0,
  `flash` tinyint(1) NOT NULL,
  `active` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `kateqoriya` (`category_id`)
) ENGINE=MyISAM AUTO_INCREMENT=62 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `category_id`, `author_id`, `datetime`, `name_en`, `name_ru`, `name_az`, `keywords_en`, `keywords_ru`, `keywords_az`, `short_text_en`, `short_text_ru`, `short_text_az`, `full_text_en`, `full_text_ru`, `full_text_az`, `image`, `read_count`, `comment_count`, `flash`, `active`) VALUES
(2, '5-9-14', 0, 1562397387, 'ADAFUL 4', 'ADAFUL 4', '', '', '', '', '', '', '', '<p><strong>ADAFUL 4</strong> - consists of vitamin-mineral complexes and this product is involved in the regulation of many metabolic processes in the body. Eliminates problems with iodine and folic acid deficiency. It improves mood, calms, eliminates fatigue. Helps normal pregnancy, is involved in the development of the nervous system of the fetus, reduces uterine contractility and convulsive contraction of peripheral muscles.</p>\n<p><strong>Release form:</strong> N 30 capsules</p>', '<p><strong>ADAFUL 4 -</strong> состоит из витаминно-минеральных комплексов и участвует в регуляции многих обменных процессов в организме. Устраняет проблемы с дефицитом йода и фолиевой кислоты. Улучшает настроение, успокаивает, устроняет усталость. Помогает нормальному течениию беременности, участвует в развитии нервной системы плода, уменьшает сократительную способность матки и судорожное сокрашение периферических мышц.</p>\n<p><strong>Форма выпуска: </strong>№30 капсула</p>', '', 'adaful-4---17-1565007627.07-1565007627.19-1565007627.png', 0, 0, 0, 1),
(3, '5-10', 0, 1562938964, 'ADAKİT', 'ADAKİT', '', '', '', '', '', '', '', '<p><strong>ADAKIT</strong> is a combined product. It is used to treat iron deficient anemia. It acts as a biocatalyst in the body and forms the majority of Hb and other enzymes. It helps to eliminate the iron deficiency required for the synthesis of Hb and other globulin enzymes and stimulates erythropoiesis. Fe + 2 fumarate helps to recover the amount of iron in the blood, together with Fe + 2 transferrin in the blood serum, Hb plays a role in the formation of myoglobin and helps the organism to accumulate in their stores.</p>\n<p><strong>Release form:</strong> 30 ml drops</p>', '<p><strong>ADAKİT</strong> комбинированное средство используется для лечения железодефицитной анемии, которая действует как биокатализатор для организмов и является основной частью Hb и других ферментов, которые помогают уменьшить дефицит железа и стимулировать эритропоз, важный для синтеза Hb и других ферментов глобулина. Fe2 + фумарат помогает восстановить количество железа в крови. В сочетании с переносом в сыворотку крови Fe + 2 участвует в образовании Hb, миоглобина и помогает организму накапливаться в депо.</p>\n<p><strong>Форма выпуска</strong>: 30 ml капли</p>', '', 'adakit---17-1565007588.07-1565007588.19-1565007588.png', 0, 0, 0, 1),
(4, '3-5-10', 0, 1562941516, 'ADAL+', 'ADAL+', '', '', '', '', '', '', '', '<p><strong>ADAL +</strong> is a combination of vitamins which regulates important metabolic processes in the body. Vitamin D contributes to the absorption of calcium from the intestines, vitamin K2 activates Matrix GLA protein, which is necessary for the absorption of bones and calcium denatat accumulated in blood and tissues. For this reason, ADAL + not only absorbs calcium from the intestines, but also delivers it to the bones. This gives more effective effect on the treatment and prevention of rickets, osteoporosis. ADAL + helps to cure clinical diseases like diabetes, rheumatic diseases, depression and so on.</p>\n<p><strong>Release form:</strong> 25 ml spray</p>', '<p><strong>ADAL +</strong> это комбинация витаминов каторая регулирует важные обменные процессы в организме. Витамин D способствует высасывание кальция из кишечника, витамин K2 активирует белок Matrix GLA, который необходим для поглощения костей и дентата кальция, накопленного в крови и тканях. По этой причине АДАЛ + не только поглощает кальций из кишечника, но и доставляет его в кости. Это дает более эффективное влияние на лечение и профилактику рахита, остеопороза. АДАЛ + помогает излечить клиническое заболевания как сахарной диабет, ревматические заболевания, депрессия и так далее.</p>\n<p><strong>Форма выпуска</strong>: 25 мл спрей</p>', '', 'adal-17-1565007556.07-1565007556.19-1565007556.png', 0, 0, 0, 1),
(9, '4-7', 0, 1562943472, 'ADELAS', 'ADELAS', '', '', '', '', '', '', '', '<p><strong>ADELAS</strong> has a calming, antimetrical, tocoly effect.<br />It eliminates the symptoms of nausea and vomiting during gastrointestinal, nervous diseases, and also eliminates the symptoms of tonus during pregnancy. The active ingredient of ginger extract inhibits the vomiting reflex. As part of magnesia and vitamin B6 reduces nervous tension and symptoms of neurosis.</p>\n<p><strong>Release form: </strong>№20 tablets</p>', '<p><strong>ADELAS</strong> обладает успокаивающим, антиметическим, токолитеским действием. <br />Он устраняет симптомы тошноты и рвоты во время желудочно-кишечных, нервных заболеваний, а также во время беременности устраняет симптомы тонуса. Действующее вещество экстракта имбиря тормозит продимость рвотного рефлекса. В составе магнезиум и витамин В6 уменьшает нервное перенапряжение и симптомы неврозности.</p>\n<p><strong>Форма выпуска: </strong>№ 20 таблет</p>', '', 'adelas---17-1565006932.07-1565006932.19-1565006932.png', 0, 0, 0, 1),
(5, '3-5-7-10', 0, 1562941961, 'ADECAL', 'ADECAL', '', '', '', '', '', '', '', '<p><strong>ADECAL</strong> is a complex remedy for rickets and bone injuries, and is also intended to restore calcium deficiency during intensive development. It consists of vitamins and minerals that will regulate ossification processes. At the same time, it eliminates the nervous activity and muscular weakness associated with hypocalcemia.</p>\n<p><strong>Release form</strong>: 150 ml syrup</p>', '<p><strong>АDECAL</strong> комплексное средство от рахита и травм костей, а также предназначен для восстановления дефицита кальция при интенсивном развитии. Он состоит из витаминов и минералов, которые будут регулировать процессы окостенения. В то же время устраняет нервную активность и мышечную слабость связанные с гипокальциемией.</p>\n<p><strong>Форма выпуска: </strong>150 мл сироп</p>', '', 'adecal-17-1565007521.07-1565007521.19-1565007521.png', 0, 0, 0, 1),
(6, '9-10', 0, 1562942231, 'ADEGAM', 'ADEGAM', '', '', '', '', '', '', '', '<p><strong>ADEGAM</strong> has a nootropic, sedative, neuroprotective, antiepileptic effect. It eliminates the symptoms of hyperactivity, encephalopathy in children, night sleep disorders, memory deficiency and enuresis. Improves the function of nerve cells, increases nerve conduction. Neutralizes symptoms such as neurosis, excitability and tearfulness.</p>\n<p><strong>Release form: </strong>120 ml syrup</p>', '<p><strong>ADEGAM</strong> - обладает ноотропным, седативным, нейропротекторным, противоэпилептическим действием.<br /> Он устраняет симптомы гиперактивности, энцефалопатии у детей, нарушения ночного сна, дефицита памяти и энуреза. Улучшает работу нервных клеток, повышает нервную проводимость. Сводит на нет такие симптомы как неврозность, возбудительность и плаксивость.</p>\n<p><strong>Форма выпуска</strong>: 120 мл сироп</p>', '', 'adegam-17-1565007491.07-1565007491.-1565007491.19-1565007491.png', 0, 0, 0, 1),
(7, 9, 0, 1562942702, 'ADEGAM PLUS', 'ADEGAM PLUS', '', '', '', '', '', '', '', '<p><strong>ADEGAM PLUS</strong> has a nootropic, cerebroprotective, angioprotective, antiaggregant and microcirculation enhancing effect. It is used to treat disorders of the central nervous system, encephalopathy, sleep disorders, epilepsy, tics, which are observed in various mental disorders. It improves the central and peripheral blood circulation, prevents hypoxia. Improves mood by increasing serotonin level.</p>\n<p><strong>Release form: </strong>№30 tablets</p>', '<p><strong>ADEGAM PLUS</strong> обладает ноотропным, церебропротекторным, ангиопротекторным, антиагрегантным и усиливающим микроциркуляцию эффектом. Он используется для лечения расстройств центральной нервной системы, энцефалопатии, нарушений сна, эпилепсии, тиков, энуреза, наблюдаемых при различных психических расстройствах. Улучшает центральную и периферическое кровообращение, предотвращает гипоксию. Улучшает настроение за счет повышения уровня серотонина.</p>\n<p><strong>Форма выпуска</strong>: №30 таблет</p>', '', 'adegam-plus---17-1565007362.07-1565007362.19-1565007362.png', 0, 0, 0, 1),
(8, '3-5-7-10', 0, 1562943007, 'ADEL 3', 'ADEL 3', '', '', '', '', '', '', '', '<p><strong>Adel 3</strong> contains vitamin D3 in the form of cholecalciferol, which is 25% more active than ergocalciferol. Adele 3 increases calcium absorption in the intestines and reabsorption of phosphorus in the renal canals. Normalizes the formation of the skeleton, protects the structure of bones. Calcium ions in the blood regulate skeletal muscle tone, myocardial function, transmission of nerve impulses and blood coagulation. Normalizes the function of the thyroid gland, the immune system and affects the production of lymphokines.</p>\n<p><strong>Release form</strong>: 15 ml drops</p>', '<p><strong>Adel 3</strong> содержит витамин Д3 в виде холекальциферола, который на 25% более активен, чем эргокальциферол. Адель 3 увеличивает всасывание кальция в кишечнике и реабсорбцию фосфора в почечных каналах. Нормализует формирование скелета, обеспечивает защиту структуры костей. Ионы кальция в крови регулируют тонус скелетных мышц, функции миокарда, передачу нервных импульсов и свертывание крови. Нормализует функцию щитовидной железы, иммунной системы и влияет на выработку лимфокинов.</p>\n<p><strong>Форма выпуска</strong>: 15 мл капли</p>', '', 'adel-3-17-1565007127.07-1565007127.19-1565007127.png', 0, 0, 0, 1),
(34, '14-17', 0, 1563780427, 'TAYT VAG 3', 'TAYT VAG 3', '', '', '', '', '', '', '', '<p><strong>TAYT VAG </strong>is a disposable shower for vaginal and external genital hygiene. Due to its unique composition, it has antiseptic, anti-inflammatory, antifungal effects and improves vaginal microflora. Tayt vag reduces burning sensation, itching and unpleasant smell. With regular use, it cleans the vagina from the secretions and restores vaginal microbiocenosis. It is ideally combined with other devices (candles, spirals, gels, etc.).</p>\n<p><strong>Release form</strong>: 3 vials</p>', '<p><strong>TAYT VAG </strong> одноразовый душ для гигиены влагалища и наружных половых органов. Благодаря уникальному составу обладает антисептическим, противовоспалительным, противогрибковым и улучшающим микрофлору влагалища действиями. Тайт ваг уменьшает чувства жжения, зуда и неприятный запах. При регулярном применение очищает влагалище от выделений и восстанавливает микробиоциноз вагины. Идеально сочетается с другими средствами (свечи, спирали, гели и т.д).</p>\n<p><strong>Форма выпуска: </strong>3 флаконы</p>', '', 'tayt-vag-3-1563782723.png', 0, 0, 0, 1),
(10, '4-8', 0, 1562943803, 'ADELİV', 'ADELİV', '', '', '', '', '', '', '', '<p><strong>ADENLIV</strong> has hepatoprotective, detoxification, antioxidant and membrane-protective action. It removes toxins, nitrogen compounds and salts of heavy metals from the body. Restores damaged liver cells, stimulates the synthesis of phospholipids and proteins, enhances the development of liver cells, restores liver function, prevents the formation of gall bladder and prevents the formation of stones in the gall bladder.</p>\n<p><strong>Release form</strong>: № 30 capsule</p>', '<p><strong>ADELİV</strong> обладает гепатопротектoрным, детоксикационном, антиоксидантным и мембранопротекторное действием. Он выводит из организма токсины, азотные соединения и соли тяжелых металлов. Восстанавливает поврежденные клетки печени, стимулирует синтез фосфолипидов и белков, усиливает развитие клеток печени, восстанавливает функцию печени, предотвращает образование желчного пузыря и предотвращает образование камней в желчном пузыре.</p>\n<p><strong>Форма выпуска: </strong>№30 капсулы</p>', '', 'adenliv---17-1565006903.07-1565006903.19-1565006903.png', 0, 0, 0, 1),
(11, '9-10', 0, 1562944205, 'ADAKARNİT', 'ADAKARNİT', '', '', '', '', '', '', '', '<p><strong>ADKARNIT </strong>- a complex product with amino acids. Participates in important metabolic processes in the body of the child, accelerates the growth of weight and height, improves psychomotor activity, improves memory and perception. It is recommended for speech disorders, mental retardation, hyperactivity, sleep disorders, lack of weight and height.</p>\n<p><strong>Release form</strong>:120 ml syrup</p>', '<p><strong>ADAKARNİT</strong> - комплексное средство с аминными кислотами. Участвует в важных обменных процессах в организме ребенка, ускоряет рост веса и роста, улучшает психомоторную деятельность, улучшает память и восприятие. Рекомендуется при нарушениях речи, умственной отсталости, гиперактивности, нарушениях сна, дефиците веса и роста.</p>\n<p><strong>Форма выпуска: </strong>120 мл сироп</p>', '', 'adkarnit-17-1565080925.07-1565080925.19-1565080925.png', 0, 0, 0, 1),
(12, '4-7-10', 0, 1562944542, 'ADOBİL', 'ADOBİL', '', '', '', '', '', '', '', '<p><strong>ADOBİL</strong> is a synbiotic product in drop form. Restores the microflora of the gastrointestinal tract. Due to its liquid content, microflora develops rapidly and prevents constipation, diarrhea, eliminates bloating. It is comfortable and practical to use in children under 1 year helps to relieve bloating and pain.</p>\n<p><strong>Release form</strong>: 10 ml drops</p>', '<p>Капли <strong>ADOBİL</strong> являtтся синбиотическим препаратом.восстанавливает микрофлору желудочно-кишечного тракта. Благодаря жидкой формы выпуска микрофлора быстро размножается и предотвращает запоры, диарею , имеет удобное и практическое применение. При применение детям до года уменьшает газообразование и симптомы колики.</p>\n<p><strong>Форма выпуска</strong>: 10 мл капли</p>', '', 'adobil-17-1565006022.07-1565006022.19-1565006022.png', 0, 0, 0, 1),
(13, '5-8-14', 0, 1563007148, 'ADOFA', '', '', '', '', '', '', '', '', '<p><strong>ADOFA</strong> regulates reproductive function. It reduces the risk of pregnancy, plays a role in restoring hormone deficiency and contributes to the healthy development of the fetus and nervous system. Provides normal spermatogenesis in men.</p>\n<p><strong>Release form</strong>: № 30 tablets</p>', '<p><strong>ADOFA</strong> регулирует репродуктивную функцию. Снижает риск беременности, играет роль в восстановлении гормонального дефицита и способствует здоровому развитию плода и нервной системы. Обеспечивает нормальный сперматогенез у мужчин.</p>\n<p><strong>Форма выпуска</strong>: № 30 таблетки</p>', '', 'adofa---17-1565005867.07-1565005867.19-1565005867.png', 0, 0, 0, 1),
(14, 5, 0, 1563007377, 'ADOFER', 'ADOFER', '', '', '', '', '', '', '', '<p><strong>ADOFER</strong> is an antianemic agent that prevents hemoglobin deficiency in the blood. Due to the iron in microcapsules, it is used in the treatment and prevention of iron deficiency anemia. Innovative Adofer in vegetarian capsules, easily absorbable through the gastrointestinal tract and has high efficiency. Adofer negates the following symptoms, such as headache, fatigue, loss of appetite, hair loss and stratification of nails.</p>\n<p><strong>Release form</strong>: №30 capsules</p>', '<p><strong>ADOFER</strong> является антианемическим средством, которое предотвращает дефицит гемоглобина в крови. За счет железа находяшегося в микрокапсулах применяется в лечении и профилактике железодефицитной анемии. Инновационный Aрасфасован в вегетарианские капсулы, легковсасывающийся через желудочно-кишечный тракт и обладает высокой эффективностью. Адофер сводит на нет следующие симптомы, такие как головная боль, усталость, потеря аппетита, выпадение волос и раслоение ногтей.</p>\n<p><strong>Форма выпуска</strong>: №30 капсулы</p>', '', 'adofer---17-1565005797.07-1565005797.19-1565005797.png', 0, 0, 0, 1),
(15, 5, 0, 1563007741, 'ADOİR-F', 'ADOİR-F', '', '', '', '', '', '', '', '<p><strong>ADOIR-F</strong> is an antianemic agent. The form of fumarate iron is more stable than other iron salts, it does not give the taste of metal in the mouth and has a high bioavailability. one of the other causes of anemia is a lack of folic acid. ADOIR-F due to optimal dose content eliminates folic acid deficiency.</p>\n<p><strong>Release form</strong>: №30 tablets</p>', '<p><strong>ADOİR-F</strong> является антианемическим средством. Форма фумарата железа является более стабильной, чем другие соли железа, она не дает вкус металла во рту и обладает высокой биодоступности. одна из других причин анемии, нехватка фолиевой кислоты. Адоир Ф благодаря содержании оптимальной дозы устраняет дефицит фолиевой кислоты.</p>\n<p><strong>Форма выпуска</strong>: №30 таблетки</p>', '', 'adoir-f-17-1565005741.07-1565005741.19-1565005741.png', 0, 0, 0, 1),
(16, '5-10', 0, 1563008060, 'ADOİR-K', 'ADOİR-K', '', '', '', '', '', '', '', '<p><strong>ADOİR-K</strong> - the combined agent is used to treat iron deficiency anemia, which acts as a biocatalyst for organisms and is a major part of Hb and other enzymes that help reduce iron deficiency and stimulate erythroposis, important for the synthesis of Hb and other globulin enzymes. Fe2 + fumarate helps restore the amount of iron in the blood. In combination with serum transfer, Fe + 2 participates in the formation of Hb, myoglobin and helps the body accumulate in the storage.</p>\n<p><strong>Release form</strong>: 150 ml syrup</p>', '<p><strong>ADOİR-K</strong> комбинированное средство используется для лечения железодефицитной анемии, которая действует как биокатализатор для организмов и является основной частью Hb и других ферментов, которые помогают уменьшить дефицит железа и стимулировать эритропоз, важный для синтеза Hb и других ферментов глобулина. Fe2 + фумарат помогает восстановить количество железа в крови. В сочетании с переносом в сыворотку крови Fe + 2 участвует в образовании Hb, миоглобина и помогает организму накапливаться в депо.</p>\n<p><strong>Форма выпуска</strong>: 150 мл сироп</p>', '', 'adoir-k-17-1565005700.07-1565005700.19-1565005700.png', 0, 0, 0, 1),
(17, '4-10-17', 0, 1563009826, 'ADOLA', 'ADOLA', '', '', '', '', '', '', '', '<p><strong>ADOLA</strong> has local anti-inflammatory, antibacterial, antispasmodic, laxative and antihelminthic effects. Due to the plants, Adola is recommended for the treatment of rectal and hemorrhoid fractures due to astringent, wound healing, antibacterial, anti-inflammatory effects.</p>\n<p><strong>Release form</strong>: №3 rectal oil 10 ml</p>', '<p><strong>ADOLA </strong>- ето местные противовоспалительные, антибактериальные, спазмолитические, слабительные средства. За счет растений входящий в состав Адола рекомендуется для лечения трещинах прямой кишки и геморроя из-за вяжущих, ранозаживляюших, антибактериальных, протисвоспалительных эффектов.</p>\n<p><strong>Форма выпуска</strong>: №3 ректальное масло 10 мл</p>', '', 'adola-17-1565005666.07-1565005666.19-1565005666.png', 0, 0, 0, 1),
(18, '10-17', 0, 1563009841, 'ADOLİN', 'ADOLİN', '', '', '', '', '', '', '', '<p><strong>ADOLİN</strong>, has local anti-inflammatory, antibacterial, antispasmodic, laxative and antihelminthic effects. At the expense of plants, part of it eliminates worms and their eggs.</p>\n<p><strong>Release form</strong>: №3 rectal oil 4,5 ml</p>', '<p><strong>ADOLİN,</strong> ето местные противовоспалительные, антибактериальные, спазмолитические, слабительные и противоглистное средства. За счет растений входящий в состав устроняет глисты и их яйца.</p>\n<p><strong>Форма выпуска</strong>: №3 ректальное масло 4,5 мл</p>', '', 'adolin-17-1565005621.07-1565005621.19-1565005621.png', 0, 0, 0, 1),
(19, '5-9-10', 0, 1563010241, 'ADOMAX', 'ADOMAX', '', '', '', '', '', '', '', '<p><strong>ADOMAX</strong> - is a comprehensive tool for indispensable nutrition, normal growth and development of the child&single_quot;s body. The presence in the composition of the necessary vitamins in the optimal dose, increase growth and provide intensive development. Adomax also eliminates mental impairment, improving perception and memory in children.</p>\n<p><strong>Release form</strong>: 120 syrup</p>', '<p><strong>ADOMAX</strong> - это комплексное средство для незаменимого питания, нормального роста и развития детского организма. Наличие в составе необходимых витаминов в оптимальной дозе, повышают рост и обеспечивают интенсивное развитие. Adomax также устраняет умственные нарушения, улучшая восприятие и память у детей.</p>\n<p><strong>Форма выпуска</strong>: 120 мл сироп</p>', '', 'adomax-17-1565005541.07-1565005541.19-1565005541.png', 0, 0, 0, 1),
(20, '5-7-8-10', 0, 1563010553, 'ADOMEGA', 'ADOMEGA', '', '', '', '', '', '', '', '<p><strong>ADOMEGA</strong> is a vitamin-mineral syrup with fish oil but without fish taste (tropical fruit flavor) and smell. It has metabolic, appetite and growth, resistance to infections, improving visual function and mental performance of actions. Doses of all components contained in adomeg are calculated on recommended daily doses. It is used in the treatment of chronic infectious diseases in the rehabilitation period, with hypotrophy and lack of growth, with visual acuity, with hyperactivity and mental retardation.</p>\n<p><strong>Release form</strong>: 150 ml syrup</p>', '<p><strong>АDOMEGA</strong>- это витаминно-минеральный сироп с рыбим жиром но без рыбного вкуса (тропический фруктовый вкус) и запаха. Он обладает метаболическим, повыщающий аппетит и рост, устойчивость к инфекциям , улучшающий зрительную функцию и умственную работаспособность действиями. Дозы всех компонентов, содержащихся в адомеге, расчитаны на рекомендованные суточные дозы.используется в лечении хронических инфекционных заболеваях в периоде реабилитации, при гипотрофии и недостаточности роста, при нарушении остроты зрения, при гиперактивности и умственной отсталости.</p>\n<p><strong>Форма выпуска</strong>: 150 мл сироп</p>', '', 'adomega-17-1565005493.07-1565005493.19-1565005493.png', 0, 0, 0, 1),
(21, '6-10', 0, 1563012092, 'ADONİN', 'ADONİN', '', '', '', '', '', '', '', '<p><strong>ADONİN</strong> nasal drops are a combination of 2 components with 3% NaCl and N-acetylcysteine. Adonin has anti-inflammatory, mucolytic, antibacterial and anti-allergic effects. Adonin is available for all age groups. Adonin reduces swelling of the mucous membrane, dilutes thick sputum and easily removes it from the nasal cavity. Unlike other nasal drops, Adonin is not addictive and can be used for a long time with allergies.</p>\n<p><strong>Release form</strong>: 15 ml nasal drops</p>', '<p><strong>ADONİN</strong> капли для носа представляет собой комбинацию 2-х компонентов с 3% NaCl и N-ацетилцистеином. Адонин обладает противоспалительным, муколитическим, антибактериальным и антиаллергическим действием. При использовании препарата доступны все возрастные группы. Адонин уменьшает отек слизистой оболочки, разжижает густую мокроту и легко удаляет его из полости носа. В отличие от других капель для носа, Адонин не вызывает привыкания и может использоваться в течение длительного времени при аллергиях.</p>\n<p><strong>Форма выпуска</strong>: 15 мл капли в нос</p>', '', 'adonin---17-1564581961.07-1564581961.19-1564581961.png', 0, 0, 0, 1),
(22, '6-7-10', 0, 1563013314, 'ADORPİN', 'ADORPİN', '', '', '', '', '', '', '', '<p><strong>ADORPİN</strong>- throat spray with a standardized extract of propolis, extract of mallow and chamomile. It activates immunity against infections, antibacterial effect on microbes, has an antiviral effect against viruses, locally prevents inflammation and reduces pain in the throat. Alcohol-free propolis can be used for allergic patients.</p>\n<p><strong>Release form</strong>: 30 ml oral spray</p>', '<p><strong>ADORPİN</strong>&nbsp;- спрей для горла со стандартизированным экстрактом прополиса, экстрактом мальвы и ромашки. Активирует иммунитет против инфекций, антибактериально действует на микробы, оказывает антивирусный эффект против вирусов, локально предотвращает воспаление и уменьшает боль в горле. Очищенный от аллергенов прополис можно применять аллергичным пациентам.</p>\n<p><strong>Форма выпуска</strong>: 30 мл оральный спрей</p>', '', 'adorpin---17-1564581923.07-1564581923.19-1564581923.png', 0, 0, 0, 1),
(23, '4-10', 0, 1563013674, 'ADORA', 'ADORA', '', '', '', '', '', '', '', '<p><strong>ADORA</strong> contributes to the natural formation of normal microflora and intestinal function, as well as create an optimal environment in the intestine for the action of digestive enzymes. In addition, they ensure the correct formation of immunity and help reduce the risk of developing infectious diseases, the possibility of manifestation of atopic dermatitis.</p>\n<p><strong>Release form</strong>: №10 capsules</p>', '<p><strong>ADORA</strong> способствуют естественному формированию нормальной микрофлоры и функции кишечника, а также создают оптимальную среду в кишечнике для действия пищеварительных ферментов. Кроме того, обеспечивают правильное формирование иммунитета и помогают снизить риск развития инфекционных заболеваний, возможность проявления атопического дерматита.</p>\n<p><strong>Форма выпуска</strong>: №10 капсулы</p>', '', 'adora---17-1564581834.07-1564581834.19-1564581834.png', 0, 0, 0, 1),
(24, 3, 0, 1563016653, 'ADORTA', 'ADORTA', '', '', '', '', '', '', '', '<p><strong>ADORTA</strong> is developed to restore the structure of bones and joints, as well as to increase motor function. Glucosamine and chondroitin are the main structural elements of cartilage that ensure the restoration of joints. Prevents degeneration in the joints, reduces inflammation and pain. Adotra provides bone resistance, accelerates the recovery of fractures.</p>\n<p><strong>Release form</strong>: №30 tablets</p>', '<p><strong>ADORTA</strong> предназначен для восстановления структуры костей и суставов, а также для увеличения двигательной функции. Глюкозамин и хондроитин являются основными структурными элементами хряща, которые обеспечивают восстановление суставов. Предотвращает дегенерацию в суставах, уменьшает на воспаление и боль. Адотра обеспечивает сопротивление костей, ускоряет восстановление переломов.</p>\n<p><strong>Форма выпуска</strong>: №30 таблетки</p>', '', 'adorta---17-1564581753.07-1564581753.19-1564581753.png', 0, 0, 0, 1),
(25, 3, 0, 1563016654, 'ADORTA GEL', 'ADORTA GEL', '', '', '', '', '', '', '', '<p><strong>ADORTA GEL</strong> l is intended for local action of restoring bone and articular structure and increasing its physical activity. Glucosamine and chondroitin are the main structural elements of cartilage that ensure the restoration of joints. It contains complex ingredients to prevent joint degeneration, has anti-inflammatory and analgesic effects. Adotra gel provides bone resistance, accelerates the recovery of fractures.</p>\n<p><strong>Release form</strong>: 50 gr gel</p>', '<p><strong>ADORTA ГЕЛЬ</strong> предназначен для местного действие восстановливаюший костно-суставной структуры и повышения ее двигательной активности. Глюкозамин и хондроитин являются основными структурными элементами хряща, которые обеспечивают восстановление суставов. Содержит комплексные ингредиенты для предотвращения дегенерации суставов, обладает противовоспалительным и обезболивающим действиями. Адотра гель обеспечивает сопротивление костей, ускоряет восстановление переломов.</p>\n<p><strong>Форма выпуска</strong>: 50 гр гель</p>', '', 'adorta-gel---17-1564581694.07-1564581694.19-1564581694.png', 0, 0, 0, 1),
(26, 9, 0, 1563017265, 'ADOSAL', 'ADOSAL', '', '', '', '', '', '', '', '<p><strong>ADOSAL</strong> consists of complex ingredients with a sedative, neuroprotective, antidepressant action. It is used to treat disorders of the central nervous system, encephalopathy, sleep disorders, neurosis-like states, and tics observed in various mental disorders. It improves the central nervous system and peripheral circulation, prevents hypoxia. Improves mood by increasing serotonin levels. Prevents symptoms like neurosis, excitability and tearfulness.</p>\n<p><strong>Release form</strong>: №20 tablets</p>', '<p><strong>ADOSAL</strong> состоит из комплексных ингредиентов с седативным, нейропротекторным, антидепрессантным действием. Применяется для лечения расстройств центральной нервной системы, энцефалопатии, нарушений сна, неврозаподобгых состаяниях, тиков, наблюдаемых при различных психических расстройствах. Улучшает центральную нервную систему и периферическое кровообращение, предотвращает гипоксию. Улучшает настроение за счет повышения уровня серотонина. Предотвращает симптомы как неврозность, возбудительность и плаксивость.</p>\n<p><strong>Форма выпуска</strong>: №20 таблетки</p>', '', 'adosal---17-1564581645.07-1564581645.19-1564581645.png', 0, 0, 0, 1),
(27, '5-7-8-14', 0, 1563017471, 'ADOVİN', 'ADOVİN', '', '', '', '', '', '', '', '<p><strong>ADOVIN</strong> is rich in vitamins, minerals, trace elements and omega-3, necessary for the normal functioning of the body. It controls the intensity of the metabolic process, increases the body&single_quot;s resistance to adverse environmental factors and boosts immunity, improves eyesight and is recommended for the prevention of cardiovascular diseases, rheumatism and skin diseases, including rehabilitation.</p>\n<p><strong>Release form</strong>: №40 capsules</p>', '<p><strong>ADOVİN</strong> богат витаминами, минералами, микроэлементами и омега-3, необходимыми для нормального функционирования организма. Он контролирует интенсивность обменного процесса, повышает сопротивляемость организма к неблагоприятным факторам окружающей среды и повышает иммунитет, улучшает зрение и рекомендуется для профилактики сердечно-сосудистых заболеваний, ревматизма и кожных заболеваний, включая реабилитацию.</p>\n<p><strong>Форма выпуска</strong>: №40 капсулы</p>', '', 'adovin---17-1564581611.07-1564581611.19-1564581611.png', 0, 0, 0, 1),
(28, '14-19', 0, 1563018692, 'ADUROL', 'ADURAL', '', '', '', '', '', '', '', '<p><span title=""><strong>ADUROL</strong> has anti-inflammatory, uroseptic and urine-producing effects, restoring damaged mucous membranes of the urinary tract.</span> <span title="">Due to its diuretic effect, it allows microbes to be washed away from the urinary tract.</span> <span title="">During the destruction of bacteria in the urinary tract, the bacteria block the lectin layer, separating the mucous membranes with an anti-adhesion effect and removing them by urine.</span> <span title="">It increases the resistance of the organism to infections by stimulating the immune system, normalizing the pH of the urine by dividing free radicals by antioxidant effect.</span></p>\n<p><span title=""><strong>Release form</strong>: №30 capsules</span></p>', '<p><strong>ADUROL</strong> обладает противовоспалительным, уросептическим, мочегонным эффектами, восстанавливает поврежденную слизистую оболочку мочевыводящих путей. Благодаря мочегонному эффекту микробы вымываются из мочевыводящих путей. Устраняя бактерии из мочевых путей, блокируют слой лектина бактерий и удаляют их через мочу. Стимулирует иммунную систему для повышения устойчивости организма к инфекциям, обладает антиоксидантными свойствами, блокирует свободные радикалы, восстанавливает рН мочи.</p>\n<p><strong>Форма выпуска</strong>: №30 капсулы</p>', '', 'adurol---17-1564581572.07-1564581572.19-1564581572.png', 0, 0, 0, 1),
(29, '5-7-13', 0, 1563019130, 'ESDADA', 'ESDADA', '', '', '', '', '', '', '', '<p><strong>ESDADA</strong> is rich in vitamins, minerals, trace elements, carotenoids lutein, necessary for the normal functioning of the body. It controls the intensity of the metabolic process, activates the immune system, increases the body&single_quot;s resistance to adverse environmental factors, and the minerals contained in it provide acid-base regulators, water-salt metabolism. Restores the lost vitamin, mineral, antioxidant balance in chronic diseases, various diets.</p>\n<p><strong>Release form</strong>: №30 capsules</p>', '<p><strong>ESDADA</strong> богата витаминами, минералами, микроэлементами, каротиноидами лютеином, необходимыми для нормального функционирования организма. Он контролирует интенсивность обменного процесса, активизирует иммунную систему, повышает устойчивость организма к неблагоприятным факторам окружающей среды, а содержащиеся в нем минералы обеспечивают кислотно-щелочные регуляторы, водно-солевой обмен. Восстанавливает утраченный витаминный, минеральный, антиоксидантный баланс при хронических заболеваниях, различных диетах.</p>\n<p><strong>Форма выпуска</strong>: №30 капсулы</p>', '', 'esdada---17-1564581530.07-1564581530.19-1564581530.png', 0, 0, 0, 1),
(30, '14-19', 0, 1563019396, 'FORTED', 'FORTED', '', '', '', '', '', '', '', '<p><strong>FORTED</strong> combined urological agent with uroseptic, diuretic, litholytic, lithokinetic and nephroprotective action. Thanks to natural ingredients it has a strong bactericidal effect. As a result of the diuretic effect, it accelerates the removal of bacteria and clears urinary tract infections. Due to the content of potassium citrate, it peaches urine and helps remove oxalate stones.</p>\n<p><strong>Release form</strong>: №30 tablets</p>', '<p><strong>FORTED</strong> комбинированное урологическое средство с уросептическим, мочегонным, литолитическим, литокинетическим и нефропротекторным действием. Благодаря натуральным ингредиентам обладает сильным бактерицидным эффектом. В результате мочегонного эффекта, он ускоряет удаление бактерий и очищает от инфекций мочевыводящих путей,Благодаря содержанию цитрата калия он ошелачивает мочу и способствует удалению оксалатных камней,</p>\n<p><strong>Форма выпуска</strong>: №30 таблетки</p>', '', 'forted---17-1564581496.07-1564581496.19-1564581496.png', 0, 0, 0, 1),
(31, '9-10', 0, 1563019845, 'NEUROAD', 'NEUROAD', '', '', '', '', '', '', '', '<p><span title=""><strong>NEUROAD</strong> has a combined sedative, neuroprotective, antispasmodic effect, regulates the function of the central nervous system.</span> <span title="">Normalizes the process of awakening when braking.</span> <span title="">Improves central and peripheral circulation.</span> <span title="">Reduces the risk of dizziness, relieves hypertension, causing vascular and diuretic effects.</span> <span title="">Reduces gastrointestinal spasm.</span></p>\n<p><span title=""><strong>Release form</strong>: 30 ml drops</span></p>', '<p><strong>NEUROPAD</strong> обладает комбинированным седативным, нейропротекторным, спазмолитическим действием, регулирует функцию центральной нервной системы. Нормализует процессы пробуждения при торможении. Улучшает центральное и периферическое кровообращение. Снижает риск головокружения, снимает гипертонию, вызывая сосудистые и мочегонные действия. Уменьшает спазм желудочно-кишечного тракта.</p>\n<p><strong>Форма выпуска</strong>: 30 мл капли</p>', '', 'neuroad---17-1564581465.07-1564581465.19-1564581465.png', 0, 0, 0, 1),
(32, '3-5', 0, 1563020278, 'OSTEAD', 'OSTEAD', '', '', '', '', '', '', '', '<p><strong>OSTEAD</strong> is designed to fully form and protect bone mass. It is important for the normal functioning of many enzymatic processes, muscles, bones and the nervous system due to its minerals. In particular, Chromium improves the level of dehydroepiandrosterone and is involved in the treatment of osteoporosis, it is also boron for regulating parathyroid hormone responsible for the exchange of calcium, phosphorus, magnesium and vitamin D.<br />Ostead also strengthens tendons, provides normal protein synthesis and collagen formation.</p>\n<p><strong>Release form</strong>: №30 tablets</p>', '<p><strong>OSTEAD</strong> предназначен для полного формирования и защиты костной массы. Он важен для нормального функционирования многих ферментативных процессов, мышц, костей и нервной системы благодаря своим минералам. В частности, хрому улучшающий уровень дегидроэпиандростерона и участвующему в лечении остеопороза, он также бору для регулирования паратгормона отвечающий за обмен кальция, фосфора, магния и витамина D. <br />Оstead также укрепляет сухожилия, обеспечивает нормальный синтез белка и образование коллагена.</p>\n<p><strong>Форма выпуска</strong>: №30 таблетки</p>', '', 'ostead---17-1564581389.07-1564581389.19-1564581389.png', 0, 0, 0, 1),
(33, '14-15-17', 0, 1563020920, 'TAYT PLUS', 'TAYT PLUS', '', '', '', '', '', '', '', '<p>Thanks to the plants contained in <strong>TAYT PLUS,</strong> it provides antiseptic, anti-edema, wound healing and antimicrobial effect in the vaginal area. Antimicrobial, anti-fungal and anti-virus effect in the presence of many plants by increasing the synergism, allows high effects during the use of vaginal tightening effects were observed.</p>\n<p><strong>Release form</strong>: 50 ml gel</p>', '<p>Благодаря растениям входящие в состав <strong>TAYT PLUS</strong> оказывает местное противоспалительное, противотековое, улучшающий регенерацию, антисептическое и противомикробное действие во влагалище. Наличие в составе одномоментно нескольких растений обладающие антибактериальным, противогрибковым, противовирусным действиями позволяет получить высокий синергистический эффект При применении наблюдается также сужение влагалища.</p>\n<p><strong>Форма выпуска</strong>: 50 мл гель</p>', '', 'tayt-plus---17-1564581280.07-1564581280.19-1564581280.png', 0, 0, 0, 1),
(35, '14-17', 0, 1563782753, 'TAYT VAG', 'TAYT VAG', '', '', '', '', '', '', '', '<p><strong>TAYT VAG </strong>is a disposable shower for vaginal and external genital hygiene. Due to its unique composition, it has antiseptic, anti-inflammatory, antifungal effects and improves vaginal microflora. Tayt vag reduces burning sensation, itching and unpleasant smell. With regular use, it cleans the vagina from the secretions and restores vaginal microbiocenosis. It is ideally combined with other devices (candles, spirals, gels, etc.).</p>\n<p><strong>Release form</strong>: 5 vials</p>', '<p><strong>TAYT VAG </strong>одноразовый душ для гигиены влагалища и наружных половых органов. Благодаря уникальному составу обладает антисептическим, противовоспалительным, противогрибковым и улучшающим микрофлору влагалища действиями. Тайт ваг уменьшает чувства жжения, зуда и неприятный запах. При регулярном применение очищает влагалище от выделений и восстанавливает микробиоциноз вагины. Идеально сочетается с другими средствами (свечи, спирали, гели и т.д).</p>\n<p><span><strong>Форма выпуска</strong>: 5 </span>флаконы</p>', '', 'tayt-vag-5-1563782888.png', 0, 0, 0, 1),
(36, '6-10', 0, 1565091850, 'TION 3', 'TİON 3', '', '', '', '', '', '', '', '<p><strong>TION 3 </strong> is using as a medical device in nasal cavity sanitation. The use of nasal aspirator is recommended for the baby to breathe comfortably before going to bed, especially with the time interval you consume before eating. <strong>Tion 3</strong> nasal aspirator is designed to conveniently remove nasal excretion from the nose. <span title="">Tion 3 is present in the filter that makes the nasal aspirator hygienic.</span> <span title="">Thanks to the ultra-soft tip, Tion 3 nasal aspirator cleans the baby&single_quot;s nose without causing it.The specificity of the Tion 3 aspirant is that it has three additional ends with the aspirator.These disposable tips are available as a 3-pack.The removal of the mucus from nose also helps prevent some complications. Tion 3 nasal aspirator is used after physiological, hypertonic, or ocean water (Oretal) solutions. These solutions facilitate the removal of nasal secretions from the baby&single_quot;s nose. It should be used under control on newborns. For hygienic reasons, aspirator&single_quot;s tips are single-use.</span></p>\n<p><span title=""><br /></span></p>\n<p><strong>Release form</strong>: Nasal aspirator with 3 soft tips</p>', '<p>Используется в качестве медицинского оборудования для санации полости носаспользование аспиратора для носа рекомендуется в течение промежутка времени, который вы считаете подходящим перед едой, особенно перед сном, чтобы ребенок мог дышать с комфортом. Носовой аспиратор <strong>TİON 3</strong> предназначен для легкого очищения носа от носа. Носовой аспиратор TİON 3 имеет гигиенический фильтр. Благодаря ультрамягким насадкам, назальный аспиратор TİON 3 очищает нос ребенка. Особенность аспиратора TİON 3 состоит в том, что у аспиратора есть три дополнительных конца. Эти одинарные концы доступны в виде 3-х упаковок. Получение носового прохода из носа также помогает предотвратить некоторые осложнения. Носовой аспиратор TİON 3 используется после физиологических, гипертонических или океанических водных растворов (Oretal). Эти решения позволяют легко удалить носовой ход из носа ребенка. Гигиенически, советы аспиратора были использованы в одиночку.</p>\n<p>&nbsp;</p>\n<p><strong>Форма выпуска</strong>: Носовой аспиратор с 3 мягкими наконечниками</p>', '', 'tion-3-1565091923.png', 0, 0, 0, 1),
(39, 6, 0, 1565186760, 'ESOL', 'ESOL', '', '', '', '', '', '', '', '<p><strong>ESOL</strong> is a composition that maintains a normal balance between the nasal cavity and sinuses. ESOL cleanses the nasal cavity from mucus. Washing the nose with Esol&nbsp; is an effective treatment and prevention of the development of acute respiratory diseases. Esol is effective for washing the nose at home for both adults and children at any age, it is allowed during pregnancy. Eliminates edema, hyperemia of the nasal cavity, improves nasal breathing. Its also developed for nasal hygiene.</p>\n<p><strong>Release form</strong>: 20 pcs solution mix packages</p>', '<p><strong>ESOL</strong> - это состав, поддерживающий нормальный пн баланс&nbsp; полости носа и пазух. ESOL очищает носовую полость от слизи. Промывание носа Esol содержающим раствором, является эффективным лечением и профилактикой развития острых респираторных заболеваний. Esol эффективен для промывания носа в домашних условиях и для взрослых, и для детей в любом возрасте, разрешен во время беременности. Устраняет отек, гиперемию носовой полости, улучшает носовой дыхание. Также предназначен для гигиены носовой полости.</p>\n<p><strong>Форма выпуска</strong>: пакеты для приготовления раствора по 20 штук</p>', '', 'esol-1565186828.png', 0, 0, 0, 1),
(37, 6, 0, 1565098613, 'VELORAL', 'VELORAL', '', '', '', '', '', '', '', '<p><strong>VELORAL</strong> is using for nasal and sinus cavity cleaning as a medical remedy.<br />How to use:<br />Step 1: Open the bottle of Veloral 240 ml and add water (warmish or room temperature) to the specified point.<br />Step 2: Add the powder from the Veloral pack to the bottle filled with water. A package should be added to 240 ml of water. Close the lid cover firmly. Hold the hole in the cover with your hand.<br />Step 3: Bring your head straight to the front, keep your mouth open, and then maximize the hole in the lid cover to your nose.<br />Step 4: Hand-squeeze the plastic vial. You will then see the flow of water through the other nostrils. You can perform this procedure several times in your nostril. You can exhale and hold while performing the operation. To complete the process, &frac14; or &frac12; of the vial should be emptied.<br />Step 5: Steps 3 and 4 should be applied to the other nostrils.<br />Step 6: After the procedure is completed, quickly exhale the residual waste in the nasal cavity and do not reuse the residual solution in the vial. The procedure should be done once a day.</p>\n<p>&nbsp;</p>\n<p><strong>Release form</strong>: 5 packets +240 ml vial</p>', '<p><strong>VELORAL</strong> используется для очистки полости носа и пазухи в качестве лечебного средства.<br />Как пользоваться:<br />Шаг 1: Откройте флакон Veloral на 240 мл и добавьте воду (теплой или комнатной температуры) до указанной точки.<br />Шаг 2: Добавьте порошок из пакета Veloral в бутылку с водой. В пакет следует добавить до 240 мл воды. Плотно закройте крышку. Держите отверстие в крышке рукой.<br />Шаг 3: Подведите голову прямо вперед, держите рот открытым, а затем увеличьте отверстие в крышке до носа.<br />Шаг 4: Сожмите вручную пластиковый флакон. Затем вы увидите поток воды через другие ноздри. Вы можете выполнить эту процедуру несколько раз в ноздрю. Вы можете выдохнуть и удерживать во время выполнения операции. Для завершения процесса, &frac14; или &frac12; флакона должны быть опорожнены.<br />Шаг 5: Шаги 3 и 4 должны быть применены к другим ноздрям.<br />Шаг 6: После завершения процедуры быстро выдохните остаточные отходы в полости носа и не используйте повторно остаточный раствор во флаконе. Процедура должна проводиться один раз в день.</p>\n<p>&nbsp;</p>\n<p><strong>Форма выпуска</strong>: 5 пакетиков + 240 мл флакон</p>', '', 'veloral-1565098593.png', 0, 0, 0, 1),
(38, '6-10', 0, 1565167465, 'VELORAL KIDS', 'VELORAL KIDS', '', '', '', '', '', '', '', '<p><strong>VELORAL KIDS</strong> is using for nasal and sinus cavity cleaning as a medical remedy.<br />How to use:<br />Step 1: Open the bottle of Veloral 120 ml and add water (warmish or room temperature) to the specified point.<br />Step 2: Add the powder from the Veloral kids pack to the bottle filled with water. A package should be added to 120 ml of water. Close the lid cover firmly. Hold the hole in the cover with your hand.<br />Step 3: Bring your head straight to the front, keep your mouth open, and then maximize the hole in the lid cover to your nose.<br />Step 4: Hand-squeeze the plastic vial. You will then see the flow of water through the other nostrils. You can perform this procedure several times in your nostril. You can exhale and hold while performing the operation. To complete the process, &frac14; or &frac12; of the vial should be emptied.<br />Step 5: Steps 3 and 4 should be applied to the other nostrils.<br />Step 6: After the procedure is completed, quickly exhale the residual waste in the nasal cavity and do not reuse the residual solution in the vial. The procedure should be done once a day.</p>\n<p>&nbsp;</p>\n<p><strong>Release form</strong>: 5 packets +120 ml vial</p>', '<p><strong>VELORAL KIDS</strong> используется для очистки полости носа и пазухи в качестве лечебного средства.<br />Как пользоваться:<br />Шаг 1: Откройте флакон Veloral kids на 120 мл и добавьте воду (теплой или комнатной температуры) до указанной точки.<br />Шаг 2: Добавьте порошок из пакета Veloral в бутылку с водой. В пакет следует добавить до 120 мл воды. Плотно закройте крышку. Держите отверстие в крышке рукой.<br />Шаг 3: Подведите голову прямо вперед, держите рот открытым, а затем увеличьте отверстие в крышке до носа.<br />Шаг 4: Сожмите вручную пластиковый флакон. Затем вы увидите поток воды через другие ноздри. Вы можете выполнить эту процедуру несколько раз в ноздрю. Вы можете выдохнуть и удерживать во время выполнения операции. Для завершения процесса, &frac14; или &frac12; флакона должны быть опорожнены.<br />Шаг 5: Шаги 3 и 4 должны быть применены к другим ноздрям.<br />Шаг 6: После завершения процедуры быстро выдохните остаточные отходы в полости носа и не используйте повторно остаточный раствор во флаконе. Процедура должна проводиться один раз в день.</p>\n<p>&nbsp;</p>\n<p><strong>Форма выпуска</strong>: 5 пакетиков + 120 мл флакон</p>', '', 'veloral-kids-1565168038.png', 0, 0, 0, 1),
(40, '6-10', 0, 1565264412, 'ESOL KIDS', 'ESOL KIDS', '', '', '', '', '', '', '', '<p><strong>ESOL KIDS&nbsp;</strong>is a composition that maintains a normal balance between the nasal cavity and sinuses. Esol kids cleanses the nasal cavity from mucus. Washing the nose with Esol kids is an effective treatment and prevention of the development of acute respiratory diseases. Esol kids is effective for washing the nose at home for both adults and children at any age, it is allowed during pregnancy. Eliminates edema, hyperemia of the nasal cavity, improves nasal breathing. Its also developed for nasal hygiene.</p>\n<p><strong>Release form</strong>: 20 pcs solution mix packages</p>', '<p><strong>ESOL&nbsp;</strong>- это состав, поддерживающий нормальный пн баланс полости носа и пазух. Esol kids очищает носовую полость от слизи. Промывание носа Esol kids содержающим раствором, является эффективным лечением и профилактикой развития острых респираторных заболеваний. Esol kids эффективен для промывания носа в домашних условиях и для взрослых, и для детей в любом возрасте, разрешен во время беременности. Устраняет отек, гиперемию носовой полости, улучшает носовой дыхание. Также предназначен для гигиены носовой полости.</p>\n<p><strong>Форма выпуска</strong>: пакеты для приготовления раствора по 20 штук</p>', '', 'esol-kids-1565265552.png', 0, 0, 0, 1),
(41, 6, 0, 1565265818, 'ORETAL', 'ORETAL', '', '', '', '', '', '', '', '<p><strong>ORETAL</strong> -&nbsp;is an ocean water for nose cleaning. Ocean water is a natural remedy for the prevention and treatment of rhinitis. It is rich in minerals, moisturizes the nasal mucosa, accelerates the recovery process, helps eliminate swelling and inflammation, and improves the function of small capillaries. It also has antiseptic properties.</p>\n<p><strong>Release form</strong>:&nbsp;5ml x 10 pcs one dose vials</p>', '<p><strong>ORETAL</strong> - это oкеаническая вода для чистки носа. Океаническая вода является естественным средством для профилактики и лечения насморка. Он богат минералами, увлажняет слизистую оболочку носа, ускоряет процесс выздоровления, помогает устранить отеки и воспаления, а также улучшает функцию мелких капилляров. Он также обладает антисептическими свойствами.</p>\n<p><strong>Форма выпуска</strong>: 5 мл х 10 флаконов по одной дозе</p>', '', 'oretal-1565267138.png', 0, 0, 0, 1),
(42, 3, 0, 1565269799, 'ADEKSOL', 'ADEKSOL', '', '', '', '', '', '', '', '<p><strong>Aerosol foam ADEKSOL</strong> has anti-inflammatory effect, improves microcirculation, has local anesthetic and analgesic effects. It is easy to use, it is absorbed immediately and does not leave a mark and oil. Adeksol helps fight arthritis, arthrosis and rheumatism, relieves pain during inflammation of joints, muscles, restores mobility after trauma, skin and tissue regeneration, stimulates blood supply,relieves muscle tension in sedentary lifestyles.</p>\n<p><strong>Release form</strong>: 150 ml aerosol foam</p>', '<p><strong>Аэрозольная пена&nbsp;ADEKSOL</strong>&nbsp;обладает противовоспалительным эффектом, улучшает микроциркуляцию, оказывает местное анестезирующее и обезболивающее действие. Благодаря пенистой форме&nbsp;Адексол помогает бороться с артритом, артрозом и ревматизмом, снимает боль при воспалениях суставов, мышц, восстанавливает подвижность после травм, регенерацию кожи и тканей, стимулирует кровоснабжение, снимает мышечное напряжение при малоподвижном образе жизни.</p>\n<p><strong>Форма выпуск</strong>а: 150 мл аэрозольной пены</p>', '', 'adeksol-aerosol-foam-150-ml-700x700-1565271059.png', 0, 0, 0, 1),
(43, 11, 0, 1566812529, 'APLECON', 'APLECON', '', '', '', '', '', '', '', '<p><strong>APLECON</strong> is a gentle cream for nipples. It moisturizes and soothes sensitive nipples especially for pregnant and lactating women. It is advisable to use after each shower to reduce tension during pregnancy. The cream is soothing, softening, antiseptic, enhancing the elasticity and healing properties of olive oil and lanol. Free of flavor, odorless &amp; colorless safe for both baby and mother. During breastfeeding, the cream should be used after cleansing the breast with mother milk.</p>\n<p><strong>Release form</strong>: 30 gr cream</p>', '<p><strong>APLECON</strong> - это нежный крем для сосков. Увлажняет и успокаивает чувствительные соски, особенно для беременных и кормящих женщин. Рекомендуется использовать после каждого душа, чтобы уменьшить напряжение во время беременности. Крем успокаивающий, смягчающий, антисептический, усиливающий эластичность и целебные свойства оливкового масла и ланола. Без аромата, без запаха и цвета безопасен для малыша и матери. Во время грудного вскармливания крем следует использовать после очищения груди с помощью материнского молока.</p>\n<p><strong>Форма выпуска</strong>: 30 г крема</p>', '', 'aplecon-1566812541.jpg', 0, 0, 0, 1),
(44, 14, 0, 1566818520, 'AUR FEMIGAR', 'AUR FEMIGAR', '', '', '', '', '', '', '', '<p><strong>AUR FEMIGAR</strong> disposable combination vaginal shower is designed for personal hygiene. It has antiseptic, anti-inflammatory, decongestant, antifungal, wound healing effects. The solution contains 1.25% acetic acid, which can adjust the pH of the vagina from 3 to 5. Thanks to the appropriate pH and acetic acid, it helps to treat &ldquo;bacterial vaginitis&rdquo; and &ldquo;cervical erosion&rdquo;. During bacterial vaginitis, conditionally pathogenic microflora turns into pathogenic. It contains tea tree oil, which acts as an antiseptic against pathogenic bacteria. Aur femigar contains Aloe Vera to reduce burning and itching.</p>\n<p><strong>Release form</strong>: 100 ml disposable vaginal douche</p>', '<p><strong>AUR FEMIGAR </strong>- Одноразовый комбинированный вагинальный душ Aur Femigar предназначен для личной гигиены. Обладает антисептическим, противовоспалительным, противоотечным, антифунгальным, ранозаживляющим действиями. Раствор содержит 1,25% уксусную кислоту, которая может регулировать рН влагалища от 3 до 5. Благодаря соответствующему pH и уксусной кислоте, помогает лечить &laquo;бактериальный вагинит&raquo; и &laquo;эрозию шейки матки&raquo;. Во время бактериального вагинита условно-патогенная микрофлора превращается в патогенную. В составе имеется масло чайного дерева, который действует как антисептик против патогенных бактерий. Aur Femigar содержит Алоэ Веру для уменьшения жжения и зуда.</p>\n<p><strong>Форма выпуска</strong>: 100 мл одноразовый вагинальный душ</p>', '', 'aur-femigar-1566818557.jpg', 0, 0, 0, 1),
(45, 14, 0, 1566819136, 'AUR FOAM', 'AUR FOAM', '', '', '', '', '', '', '', '<p><strong>AUR FOAM - </strong>daily cleansing of the genitalia with a soap can cause dysbiosis. For these purposes, we offer intimate Aurfoam soap. It has is an antiseptic product specially designed for soft cleansing of external genitalia. Its active ingredient is Hexamidine Dezetionate, which is very effective against bacteria, fungi and unpleasant odors. The soft consistency and specially selected formulation correspond to the natural structure of the pH of the genital organs and do not cause dysbiosis when purified. Gives freshness, cleanliness and comfort when used throughout the day. Suitable for frequent and long-term use.</p>\n<p><strong>Release form</strong> : 200 ml foam</p>', '<p><strong>AUR FOAM</strong> - Ежедневная очистка обычным мылом наружных половых органов приводит к дизбактериозу. Для таких целей предлагаем пену Аур фоам для гениталий . Это антисептический продукт, специально разработанный для бережной очистки наружных половых органов. Её активным компотентом является Гексамидин Дезетионат очень эффективен против бактерий, грибков и неприятных запахов. Мягкая консистенция и специально подобранная формула совместима с естественной структурой pH в области гениталий, при очистке которой не вызывает дисбиоз. При использовании в течение дня поддерживает свежесть, ощущение чистоты и комфорт. Подходит для частого и длительного использования.</p>\n<p><strong>Форма выпуска</strong>: 200 мл пены</p>', '', 'aurfoam-1566820372.jpg', 0, 0, 0, 1),
(46, 14, 0, 1566820475, 'AUR LACT', 'AUR LACT', '', '', '', '', '', '', '', '<p><strong>AUR LACT</strong> is daily cream for the genital area, it has delicate and soft consistency with a special formula, rich in aloe vera extract, tea tree oil and lactic acid. Lactic acid restores the vaginal microflora and supports its pH in the range from 3.8 to 4.5. Tea tree oil has an antiseptic effect and reduces irritation and burning caused by itching and dryness in the genital area. Aloe vera has anti-inflammatory and antiseptic effects. Thanks to this composition, it is used to protection of external genital area.</p>\n<p><strong>Release form</strong>: 100 ml vaginal cream</p>', '<p><strong>AUR LACT</strong> ето ежедневный крем для генитальной области, крем нежной и мягкой консистенции с особой формулой, богатый экстрактом алоэ веры, маслом чайного дерева и молочной кислотой. Молочная кислота восстанавливает микрофлору влагалища и поддерживает ее Рн в пределах от 3,8 до 4,5. Масло чайного дерева обладает антисептическим эффектом и уменьшает раздражение и жжение, вызванные зудом и сухостью в области половых органов. Алоэ вера обладает противовоспалительным и антисептическим действиями. Благодаря такому составу используется для защиты области наружных половых</p>\n<p><strong>Форма выпуск</strong><span><strong>а</strong>: 100 мл вагинальный крем</span></p>', '', 'aurlact-1566821448.jpg', 0, 0, 0, 1),
(47, 14, 0, 1566821575, 'AUR SEDA', 'AUR SEDA', '', '', '', '', '', '', '', '<p><strong>AUR SEDA</strong> is a genital cleansing soap. It contains sodium bicarbonate, which has a thinning effect. If a woman has thick discharge, it is ideal for them. Aur Seda was developed by specialists for cleaning the female genital organs from fungal and bacterial vaginitis. Aur Seda protects the genitals from germs causing inflammatory processes.</p>\n<p><strong>Release form</strong>: 100 ml disposable vaginal douche</p>', '<p><strong>AUR SEDA</strong> это очищающее мыло для половых органов. Он в составе имеет натрий бикарбонат, обладающий разжижающим действием. Если у женщины имеются густые выделения, он им идеально подходит. Aur seda разработана специалистами для чистки женских половых органов при грибковом и бактериальном вагините. Aur seda защищает половые органы от микробов вызывающие воспалительные процессы.</p>\n<p><strong>Форма выпуск</strong><span><strong>а</strong>: 100 мл одноразовый вагинальный душ</span></p>', '', 'aur-sedaa-1566822186.jpg', 0, 0, 0, 1),
(48, 14, 0, 1566822283, 'AUR TİGHT', 'AUR TİGHT', '', '', '', '', '', '', '', '<p><strong>AUR TİGHT</strong> is a disposable vaginal shower with antiseptic, disinfectant, bactericidal action. With regular use, it reduces the vaginal lumen, because potassium sulfate is present in the composition. It contains a component called aluminum sulfate, which helps women with enuresis (urinary incontinence) after multiple births. It also contains potassium sulfate, with regular use of which improves sexual quality and orgasm. It has a bactericidal and disinfecting effect due to the content of benzalkonium chloride in the composition. Benzalkonium chloride also has antifungal (Candida albicans), antiprotozoal (Chlamydia, Trichomonas vaginalis) and local contraceptive (spermatocidal) actions; inactivates viruses that cause Herpes Simplex. This shower protects a woman from sexually transmitted diseases.</p>\n<p><strong>Release form</strong>: 100 ml disposable vaginal douche</p>', '<p><strong>AUR TİGHT - </strong>Это одноразовый душ для влагалища, обладающий антисептическим, дезинфицирующим, бактерицидным действиями. При регулярном использовании уменьшает просвет влагалища, потому что в составе имеется сульфат калия. В составе есть компонент под названием сульфат алюминия, который помогает женщинам страдающим энурезом (недержанием мочи) после многоплодных родов. Также содержит сульфат калия, при регулярном использовании которого улучщается сексуальное качество и оргазм. Бактерицидное и дезинфицирующее действие оказывает из-за содержания в составе бензалкония хлорида. Бензалконий хлорид обладает также противогрибковым (Candida albicans), антипротозойным (Chlamydia ,Trichomonas vaginalis) и местное контрацептивным (сперматоцидное) действиями; инактивирует вирусы, вызывающие простой герпес (Herpes simplex). Этот душ защищает женщину от венерических болезней.</p>\n<p><strong>Форма выпуска</strong>: 100 мл одноразовый вагинальный душ</p>', '', 'aurtight-1566824104.jpg', 0, 0, 0, 1),
(56, 10, 0, 1567691772, 'BABY MERRY', 'BABY MERRY', '', '', '', '', '', '', '', '<p><strong>BABY MERRY</strong> is a product containing a combination of trace elements in the form of sodium and potassium chloride, trisodium citrate. Baby Merry has a detoxifying, restoring acid-base balance, disturbed due to the loss of electrolytes during vomiting, diarrhea, poisoning, and excessive sweating. Due to its unique composition, metabolic acidosis is correcting.</p>\n<p><strong>Release form</strong>: 150 ml oral solution</p>', '<p><strong>BABY MERRY</strong> это средство содержащее комбинацию микроэлементов в виде натрий и калий хлорида, тринатрий цитрата. Baby Merry обладает детоксикационным, восстановливающим кислотно-щелочную равновесию, нарушенная, вследствие потери электролитов при рвоте, диарее, отравлениях, обильном потоотделении. Из-за содержания уникального состава способствует коррекцию метаболического ацидоза.</p>\n<p><strong>Форма выпуска</strong>: 150 мл пероральный раствор</p>', '', 'baby-merry-1567692192.jpg', 0, 0, 0, 1),
(49, 14, 0, 1566824122, 'AUR VİRA', 'AUR VİRA', '', '', '', '', '', '', '', '<p><strong>AUR VIRA - </strong>daily genital Cleansing soap gently cleanses the external genital area while moisturizing. It is effective against bad odors caused by bacteria. Specially developed formula with rose extract for a long time leaves a feeling of freshness, does not dry the delicate skin of the genitals. The soap is designed for daily hygiene of the intimate area, and therefore compatible with the natural pH in the genital area.</p>\n<p><strong>Release form</strong>: 125 gr of a cleaning soap</p>', '<p>Ежедневное очищающее мыло <strong>AUR VİRA</strong> для гениталий деликатно очищает внешнюю область гениталий, одновременно увлажняя. Это эффективно против неприятных запахов, вызванных бактериями. Специально разработанная формула с экстрактом розы длительное время оставляет ощущения свежести, не сушит нежную кожу гениталий. Мыло расчитано для ежедневной гигиены интимной зоны, и поэтому совместима с естественной pH в области гениталий.</p>\n<p><strong>Форма выпуска</strong>: 125 гр чистящего мыла</p>', '', 'aurvira-1566824616.jpg', 0, 0, 0, 1),
(50, 11, 0, 1566824655, 'BELOVIN', 'BELOVIN', '', '', '', '', '', '', '', '<p><strong>BELOVIN</strong> is a firming cream against stretch marks. When used regularly, it helps to reduce the appearance of cracks in the skin and helps prevent the appearance of new stretch marks. Effective for cracks caused by pregnancy and weight gain. Belovine contains special oils such as almond oil, olive oil extracts and aloe vera to keep your skin soft and supple. These oils contain a lot of linoleic and oleic acids, vitamins A, F, E and B2, magnesium, phosphorus, zinc, carotenes and many other useful substances that nourish and strengthen the skin.</p>\n<p><strong>Release form</strong>: 30 gr cream</p>', '<p><strong>BELOVIN</strong> это укрепляющий крем против растяжек . При регулярном использовании помогает уменьшить появление трещин на коже и помогает предотвратить появление новых растяжек. Эффективен при трещинах, вызванных беременностью и увеличением веса. Беловин содержит специальные масла, такие как миндальное масло, экстракты оливкового масла и алоэ вера, чтобы сохранить кожу мягкой и эластичной. В составе этих масел содержится много линолевой и олеиновой кислот, витамины А, F,Е и В2, магний, фосфор, цинк, каротины и многие другие полезные вещества, питающие и укрепляющие кожу.</p>\n<p><strong>Форма выпуск</strong><span><strong>а</strong>: 30 г крем</span></p>', '', 'belovin-1566825367.jpg', 0, 0, 0, 1),
(51, 4, 0, 1566825394, 'ENOMOMAX', 'ENOMOMAX', '', '', '', '', '', '', '', '<p><strong>ENOMOMAX</strong> is a rectal device that has an irritating effect on the mucous membrane of the rectum and reflex stimulation of the intestinal motility, helping to exacerbate the mass of the stool instantly and without pain. Enomomax is used by men and women over 12 years of age and can be used twice a day if needed. It is not recommended to use more than seven days.</p>\n<p><strong>Release form</strong>: 6,75 gr glycerol rectal solution</p>', '<p><strong>ENOMOMAX</strong> - это слабительное средство, оказывающее легкое раздражающее воздействие на слизистую прямой кишки и рефлекторно стимулирующее двигательную активность кишечника, кроме этого, препарат смягчает каловые массы, что способствует их более быстрому и безболезненному выведению.<br />Enomomax используется мужчинами и женщинами старше 12 лет, при необходимости может применяться два раза в день. Использование клизмы более семи дней не рекомендуется.</p>\n<p><strong>Форма выпуска</strong>: 6,75 гр глицерина ректального раствора</p>', '', 'enomomax-1566826894.jpg', 0, 0, 0, 1),
(52, 14, 0, 1566826950, 'FEMIAUR', 'FEMIAUR', '', '', '', '', '', '', '', '<p><strong>FEMIAUR</strong> -Disposable vaginal douche has been specially designed for vaginal hygiene. It contains 10% povidone iodine as an active ingredient. It has antiseptic, antiviral and antibacterial properties. It is used for bacterial, chlamydial, ureaplasma and mycoplasma vaginitis. Femiaur, unlike other antiseptics, normalizes the acidity of the vaginal environment, which creates the conditions for the rapid restoration of the normal microflora of the vagina, which is an important factor in the absence of relapse of the vaginal infection after treatment. It has no side effects due to its active organic ingredients.</p>\n<p><strong>Release form</strong>: 5 ml x 10 ampoules</p>', '<p><strong>FEMIAUR </strong>-одноразовый вагинальный душ был специально разработан для гигиены влагалища. Он содержит 10% йода повидона в качестве активного ингредиента. Обладает антисептическими, противовирусными и антибактериальными свойствами. Применяется при бактериальной, хламидийной, уреаплазменной и микоплазменной вагинитах . Фемиаур в отличие от других антисептиков, нормализует кислотность вагинальной среды, чем создает условия для быстрого восстановления нормальной микрофлоры влагалища, что является важным фактором отсутствия рецидивов вагинальной инфекции после лечения. Он не проявляет побочных эффектов благодаря своим активным органическим ингредиентам.</p>\n<p><strong>Форма выпуска</strong>: 5 мл х 10 ампул</p>', '', 'femiaur-1566827951.jpg', 0, 0, 0, 1),
(53, 4, 0, 1566885560, 'RECTOMAX', 'RECTOMAX', '', '', '', '', '', '', '', '<p><strong>RECTOMAX</strong> is an enema for cleansing the intestines from feces. Rectal solution is suitable for adults and young people over 12 years old. Suitable for professional use before rectal surgery, after prolonged constipation, before colonoscopy, reduces rectal tension and soreness before surgery. Not applicable for daily use.</p>\n<p><strong>Release form</strong>: 118 ml laxative saline solution</p>', '<p><strong>RECTOMAX - </strong>это клизма для ичищения кишечника от каловых масс. Ректальный раствор подходит для взрослых и молодых людей старше 12 лет. Подходит для профессионального использования перед ректальными операциями, после длительного запора, перед колоноскопией, Уменьшает напряжение прямой кишки и болезненность перед операцией. Не применяется для ежедневного использования.</p>\n<p><strong>Форма выпуска</strong>: 118 мл слабительный солевой раствор</p>', '', 'rectomax-1566887518.jpg', 0, 0, 0, 1),
(54, 14, 0, 1566893274, 'AUR FRESH', 'AUR FRESH', '', '', '', '', '', '', '', '<p><strong>AUR FRESH</strong> intimate area daily cleanser has anti-inflammatory, antibacterial and antifungal, deodorizing effects. Aur Fresh provides hygiene of the external genital organs, refreshes and gives comfort throughout the day. With the help of chamomile extract Aur Fresh gently cleanses and moisturizes, reduces inflammation in the external genital area. Its special formula, adjusted to pH 4.5, is compatible with the natural structure of the pH of the genital area. The sensation of freshness, which begins immediately, continues throughout the day.</p>\n<p><strong>Release form</strong>: 275 ml daily cleaning liquid</p>', '<p>Ежедневное очищающее средством <strong>AUR FRESH</strong>&nbsp;для интимной зоны обладает противовоспалительным, антибактериальным и противогрибковым, дезодорирующими действиями. Aur Fresh обеспечивает гигиену наружных половых органов, освежает и дарит комфорт в течение дня. С помощью экстракта ромашки Aur Fresh мягко очищает и увлажняет , уменьшает воспаление в областе наружных половых органов. Его специальная формула, настроенная на pH 4,5, совместима с естественной структурой pH области гениталий. Ощущение свежести, которое начинается сразу же, продолжается в течение дня.</p>\n<p><strong>Форма выпуска</strong>: 275 мл ежедневной чистящей жидкости</p>', '', 'aur-freshshhsh-1566893934.jpg', 0, 0, 0, 1),
(55, 14, 0, 1566969766, 'AUR SOD', 'AUR SOD', '', '', '', '', '', '', '', '<p><strong>AUR SOD</strong> is a disposable vaginal shower with 0.025% carbonate and 2% sodium bicarbonate which can adjust the pH of the solution between 8-9. This helps in relieving symptoms of vulvar vaginitis. Usually, women suffer from symptoms of vulvovaginitis during menopause. Aur sod is widely used by both women of childbearing and women during menopause. Thanks to the alkaline solution, the shower reduces burning and dryness in the vagina. It has antiseptic, antiviral and antibacterial properties. Contains aloe vera which helps reduce burning sensation and itching.</p>\n<p><strong>Release form</strong>: 100 ml of vaginal soap</p>', '<p><strong>AUR SOD</strong>&nbsp;это одноразовый вагинальный душ с 0,025% -ым карбонатом и 2%-ым бикарбонат натрия&nbsp; которые могут регулировать рН раствора между 8-9. Это помогает в облегчении симптомов при вульве-вагинитах. Обычно симптомами вульвовагинита страдают женщины во время менопаузы. Aur sod широко используется как женщинами детородного, так и женщинами во время менопаузы. Благодаря щелочному раствору, душ уменьшает жжение и сухость во влагалище. Он обладает антисептическими, противовирусными и антибактериальными свойствами. Содержит алоэ веру который помогает уменьшить жжение и зуд.</p>\n<p><strong>Форма выпуска</strong>: 100 мл вагинального мыла</p>', '', 'aursod-1566970486.jpg', 0, 0, 0, 1),
(57, 10, 0, 1567759595, 'BABY MİX 5 (Apple flavored)', 'BABY MİX 5 (Cо вкусом яблока)', '', '', '', '', '', '', '', '<p><strong>BABY MIX 5</strong> has a calming and polluting, antispasmodic effect thanks to its unique formula with natural active and effective ingredients. Baby Mix 5 also contains the active ingredient fennel, which has an antispasmodic effect on the smooth muscles of the intestines, which supports digestion, and is therefore widely used for spastic colic and digestive disorders.</p>\n<p><strong>Release form</strong>: 150 ml syrup</p>', '<p><strong>BABY MIX</strong> <strong>5</strong> благодаря уникальной формуле с натуральными активными и эффективными ингредиентами, обладает успокоивающим и ветрогонным, спазмолитическими действиями. Baby Mix 5 содержит активный компонент фенхель, который также способствует перевариванию, обладая спазмолитическим действием, особенно в отношении гладкой мускулатуры кишечника и поэтому широко применяется при спастических коликах и при расстройствах пищеварения.</p>\n<p><strong>Форма выпуска</strong>: 150 мл сироп</p>', '', 'baby-mix-5-apple-1567759578.jpg', 0, 0, 0, 1),
(58, 10, 0, 1567769483, 'BABY MIX 5 (Strawberry flavoured)', 'BABY MİX 5  (Со вкусом клубники)', '', '', '', '', '', '', '', '<p><strong>BABY MIX</strong><span> has a calming and polluting, antispasmodic effect thanks to its unique formula with natural active and effective ingredients. Baby Mix also contains the active ingredient fennel, which has an antispasmodic effect on the smooth muscles of the intestines, which supports digestion, and is therefore widely used for spastic colic and digestive disorders.</span></p>\n<p><span><strong>Release form</strong><span>: 150 ml syrup</span></span></p>', '<p><strong>BABY MIX </strong>благодаря уникальной формуле с натуральными активными и эффективными ингредиентами, обладает успокоивающим и ветрогонным, спазмолитическими действиями. Baby Mix содержит активный компонент фенхель, который также способствует перевариванию, обладая спазмолитическим действием, особенно в отношении гладкой мускулатуры кишечника и поэтому широко применяется при спастических коликах и при расстройствах пищеварения.</p>\n<p><strong>Форма выпуска:</strong> 150 мл сироп</p>', '', 'baby-mix-5-strawberry-1567769920.jpg', 0, 0, 0, 1),
(59, 10, 0, 1567770429, 'BABY MIX 5  (Banana flavoured)', 'BABY MIX 5 (Банановый ароматизированный)', '', '', '', '', '', '', '', '<p><strong>BABY MIX 5&nbsp;</strong>has a calming and polluting, antispasmodic effect thanks to its unique formula with natural active and effective ingredients. Baby Mix 5 also contains the active ingredient fennel, which has an antispasmodic effect on the smooth muscles of the intestines, which supports digestion, and is therefore widely used for spastic colic and digestive disorders.</p>\n<p><strong>Release form</strong>: 150 ml syrup</p>', '<p><strong>BABY MIX&nbsp;5</strong>&nbsp;благодаря уникальной формуле с натуральными активными и эффективными ингредиентами, обладает успокоивающим и ветрогонным, спазмолитическими действиями. Baby Mix 5 содержит активный компонент фенхель, который также способствует перевариванию, обладая спазмолитическим действием, особенно в отношении гладкой мускулатуры кишечника и поэтому широко применяется при спастических коликах и при расстройствах пищеварения.</p>\n<p><strong>Форма выпуска</strong>: 150 мл сироп</p>', '', 'baby-mix-5-banana-1567770728.jpg', 0, 0, 0, 1),
(60, 10, 0, 1567770787, 'BABY MİX 5 (Pineapple flavoured)', 'BABY MİX 5 (Со вкусом ананас)', '', '', '', '', '', '', '', '<p><strong>BABY MIX 5&nbsp;</strong>has a calming and polluting, antispasmodic effect thanks to its unique formula with natural active and effective ingredients. Baby Mix 5 also contains the active ingredient fennel, which has an antispasmodic effect on the smooth muscles of the intestines, which supports digestion, and is therefore widely used for spastic colic and digestive disorders.</p>\n<p><strong>Release form</strong>: 150 ml syrup</p>', '<p><strong>BABY MIX&nbsp;5&nbsp;</strong>благодаря уникальной формуле с натуральными активными и эффективными ингредиентами, обладает успокоивающим и ветрогонным, спазмолитическими действиями. Baby Mix 5 содержит активный компонент фенхель, который также способствует перевариванию, обладая спазмолитическим действием, особенно в отношении гладкой мускулатуры кишечника и поэтому широко применяется при спастических коликах и при расстройствах пищеварения.</p>\n<p><strong>Форма выпуска</strong>: 150 мл сироп</p>', '', 'baby-mix-5-pineapple-1567771447.jpg', 0, 0, 0, 1),
(61, 10, 0, 1567771494, 'BABY MIX (Orange flavoured)', 'BABY MIX 5 (Со вкусом апельсина)', '', '', '', '', '', '', '', '<p><strong>BABY MIX 5</strong>&nbsp;has a calming and polluting, antispasmodic effect thanks to its unique formula with natural active and effective ingredients. Baby Mix 5 also contains the active ingredient fennel, which has an antispasmodic effect on the smooth muscles of the intestines, which supports digestion, and is therefore widely used for spastic colic and digestive disorders.</p>\n<p><strong>Release form</strong>: 150 ml syrup</p>', '<p><strong>BABY MIX&nbsp;5</strong>&nbsp;благодаря уникальной формуле с натуральными активными и эффективными ингредиентами, обладает успокоивающим и ветрогонным, спазмолитическими действиями. Baby Mix 5 содержит активный компонент фенхель, который также способствует перевариванию, обладая спазмолитическим действием, особенно в отношении гладкой мускулатуры кишечника и поэтому широко применяется при спастических коликах и при расстройствах пищеварения.</p>\n<p><strong>Форма выпуска</strong>: 150 мл сироп</p>', '', 'baby-mix-5-orange-1567771673.jpg', 0, 0, 0, 1);



-- ---------------------------------------------------------
--
-- Table structure for table : `products2`
--
-- ---------------------------------------------------------

CREATE TABLE `products2` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` varchar(255) NOT NULL,
  `author_id` int(11) NOT NULL,
  `datetime` int(11) NOT NULL,
  `name_en` varchar(255) NOT NULL,
  `name_ru` varchar(255) NOT NULL,
  `name_az` varchar(255) NOT NULL,
  `keywords_en` varchar(255) NOT NULL,
  `keywords_ru` varchar(255) NOT NULL,
  `keywords_az` varchar(255) NOT NULL,
  `short_text_en` varchar(500) NOT NULL,
  `short_text_ru` varchar(500) NOT NULL,
  `short_text_az` text NOT NULL,
  `full_text_en` text NOT NULL,
  `full_text_ru` text NOT NULL,
  `full_text_az` text NOT NULL,
  `image` varchar(255) NOT NULL,
  `read_count` int(11) NOT NULL DEFAULT 0,
  `comment_count` int(11) NOT NULL DEFAULT 0,
  `flash` tinyint(1) NOT NULL,
  `active` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `kateqoriya` (`category_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `products2`
--

INSERT INTO `products2` (`id`, `category_id`, `author_id`, `datetime`, `name_en`, `name_ru`, `name_az`, `keywords_en`, `keywords_ru`, `keywords_az`, `short_text_en`, `short_text_ru`, `short_text_az`, `full_text_en`, `full_text_ru`, `full_text_az`, `image`, `read_count`, `comment_count`, `flash`, `active`) VALUES
(1, 3, 0, 1562397196, '', '', '', '', '', '', '', '', '', '', '', '', 'product-grey-7-1562397243.jpg', 0, 0, 1, 0),
(2, 3, 0, 1562397375, '', '', '', '', '', '', '', '', '', '', '', '', 'product-grey-7-1562397375.jpg', 0, 0, 0, 0);



-- ---------------------------------------------------------
--
-- Table structure for table : `questions`
--
-- ---------------------------------------------------------

CREATE TABLE `questions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) NOT NULL,
  `question_en` varchar(255) DEFAULT NULL,
  `question_ru` varchar(255) DEFAULT NULL,
  `question_az` varchar(255) NOT NULL,
  `answer_en` varchar(255) DEFAULT NULL,
  `answer_ru` varchar(255) DEFAULT NULL,
  `answer_az` varchar(255) NOT NULL,
  `datetime` int(11) NOT NULL,
  `tip` tinyint(1) NOT NULL COMMENT '0=>one, 1=>many',
  `vote_count` int(11) NOT NULL,
  `active` tinyint(1) DEFAULT 0,
  `position` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `questions`
--

INSERT INTO `questions` (`id`, `parent_id`, `question_en`, `question_ru`, `question_az`, `answer_en`, `answer_ru`, `answer_az`, `datetime`, `tip`, `vote_count`, `active`, `position`) VALUES
(8, 6, '', '', '', '', '', '', 1503552581, 0, 0, 1, 2),
(6, 0, '', '', 'iii', '', '', '', 1503552261, 1, 0, 1, 1),
(7, 6, '', '', '', '', '', '', 1503552559, 0, 0, 1, 1);



-- ---------------------------------------------------------
--
-- Table structure for table : `questions_ip`
--
-- ---------------------------------------------------------

CREATE TABLE `questions_ip` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip` varchar(15) NOT NULL,
  `question_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;



-- ---------------------------------------------------------
--
-- Table structure for table : `services`
--
-- ---------------------------------------------------------

CREATE TABLE `services` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name_en` varchar(100) NOT NULL,
  `name_ru` varchar(100) NOT NULL,
  `name_az` varchar(255) NOT NULL,
  `short_text_en` varchar(255) NOT NULL,
  `short_text_ru` varchar(255) NOT NULL,
  `short_text_az` text NOT NULL,
  `full_text_en` text NOT NULL,
  `full_text_ru` text NOT NULL,
  `full_text_az` text NOT NULL,
  `image` varchar(100) NOT NULL DEFAULT '0',
  `position` int(11) NOT NULL,
  `active` int(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `services`
--

INSERT INTO `services` (`id`, `name_en`, `name_ru`, `name_az`, `short_text_en`, `short_text_ru`, `short_text_az`, `full_text_en`, `full_text_ru`, `full_text_az`, `image`, `position`, `active`) VALUES
(1, '', 'Heart Specialist ru 1', 'Uşaqlığın adiomiozu', '', 'Take a trivial example, which of us ever undertakes laborious physical exercise except to obtain ru 1', 'Take a trivial example, which of us ever undertakes laborious physical exercise except to obtain 1', '', '<p>Take a trivial example, which of us ever undertakes laborious physical exercise except to obtain Take a trivial example, which of us ever undertakes laborious physical exercise except to obtain Take a trivial example, which of us ever undertakes laborious physical exercise except to obtain Take a trivial example, which of us ever undertakes laborious physical exercise except to obtain Take a trivial example, which of us ever undertakes laborious physical exercise except to obtain Take a trivial example, which of us ever undertakes laborious physical exercise except to obtain Take a trivial example, which of us ever undertakes laborious physical exercise except to obtain ru 1</p>', '<p><span>Take a trivial example, which of us ever undertakes laborious physical exercise except to obtain <span>Take a trivial example, which of us ever undertakes laborious physical exercise except to obtain <span>Take a trivial example, which of us ever undertakes laborious physical exercise except to obtain <span>Take a trivial example, which of us ever undertakes laborious physical exercise except to obtain <span>Take a trivial example, which of us ever undertakes laborious physical exercise except to obtain <span>Take a trivial example, which of us ever undertakes laborious physical exercise except to obtain <span>Take a trivial example, which of us ever undertakes laborious physical exercise except to obtain 1</span></span></span></span></span></span></span></p>', 'usagliginmiomasi-1619543255.png', 13, 1),
(2, '', '', 'Uşaqlığın mioması', '', '', 'Will give you a complete account of the system, and expound tactual teachings great explorer', '', '', '<p><span>Will give you a complete account of the system, and expound tactual teachings great explorer <span>Will give you a complete account of the system, and expound tactual teachings great explorer <span>Will give you a complete account of the system, and expound tactual teachings great explorer <span>Will give you a complete account of the system, and expound tactual teachings great explorer <span>Will give you a complete account of the system, and expound tactual teachings great explorer1</span></span></span></span></span></p>', 'usagliginmiomasi-1619543223.png', 14, 1),
(3, '', '', 'Endometriyanın polipi', '', '', '', '', '', '', 'usagliginmiomasi-1619543278.png', 12, 1),
(4, '', '', 'Yumurtalıq kistası', '', '', '', '', '', '', 'usagliginmiomasi-1619543295.png', 11, 1),
(5, '', '', 'Uşaqlıq boynunun polipi', '', '', 'UŞAQLIQ POLİPLƏRİ NƏDİR? UŞAQLIQ POLİPLƏRİNİN SƏBƏBLƏRİ, ƏLAMƏTLƏRİ VƏ MÜALİCƏSİ\n\nQadınlarda menstruasiya dövrünün pozulmasının vacib səbəblərindən biri olan uşaqlıq polipləri nədir? Uşaqlıq poliplərinin səbəbləri, simptomları və müalicəsi ilə bağlı bütün məlumatları məqaləmizdə oxuya bilərsiniz.', '', '', '<p><span style="font-size: 18px; color: #000000;"><strong>UŞAQLIQ POLİPLƏRİ NƏDİR? UŞAQLIQ POLİPLƏRİNİN SƏBƏBLƏRİ, ƏLAMƏTLƏRİ VƏ MÜALİCƏSİ </strong></span></p>\n<p><span style="font-size: 16px; color: #000000;"><strong>Qadınlarda menstruasiya dövrünün pozulmasının vacib səbəblərindən biri olan uşaqlıq polipləri nədir? Uşaqlıq poliplərinin səbəbləri, simptomları və müalicəsi ilə bağlı bütün məlumatları məqaləmizdə oxuya bilərsiniz.</strong></span></p>\n<p><span style="font-size: 16px; color: #000000;">Bu məqaləmizdə əksəriyyəti 1-2 sm böyüklüyündə olan bəzən isə böyüklüyü 10 sm-ə qədər böyüyən, xərçəngə çevrilmə ehtimalı demək olar ki olmayan və ciddi sağlamlıq problemləri yaratmayan uşaqlıq polipləri haqqında bilməli olduğunuz məlumatları ətraflı şəkildə qeyd edəcəyik.</span></p>\n<p>&nbsp;</p>\n<p><span style="font-size: 16px; color: #000000;"><strong>UŞAQLIQ POLİPLƏRİ NƏDİR?</strong></span></p>\n<p><span style="font-size: 16px; color: #000000;">Uşaqlıq polipləri uşaqlığın daxili divarına və uşaqlıq boşluğuna doğru uzanan böyümələrdir. Uşaqlığın (endometriya) astarındakı hüceyrələrin həddindən artıq böyüməsi eyni zamanda endometrium polipləri olaraq da bilinən uşaqlıq poliplərinin meydana gəlməsinə səbəb olur. Bu poliplər çox zaman xərçəng riski daşımır (xoş xassəlidir), lakin bəziləri xərçənglı ola bilər və ya xərçəngə (prekanseroz poliplər) çevrilə bilər.</span></p>\n<p><span style="font-size: 16px; color: #000000;">Uşaqlıq poliplərinin ölçüsü bir-iki millimetrdən (susam toxumu qədər) bir neçə santimetrə qədər (golf topu övə ya daha böyük) ola bilər. Çox zaman uşaqlıq divarına nazik bir sapla bağlı olurlar.</span></p>\n<p><span style="font-size: 16px; color: #000000;">Xəstələrdə eyni anda bir və ya daha çox uşaqlıq polipi yarana bilər. Poliplər əsasən uşaqlıq daxilində qalırlar. Bəzi hallarda isə uşaqlıq boynundan (serviks) vaginaya doğru sürüşürlər. Uşaqlıq polipləri əsasən gənc qadınlarda görülsə də, menopoz dövrünə keçən qadınlarda da çox görülməkdədir.</span></p>\n<p>&nbsp;</p>\n<p><span style="font-size: 16px; color: #000000;"><strong>UŞAQLIQ POLİPLƏRİNİN ƏLAMƏTLƏRİ:</strong></span></p>\n<p><span style="font-size: 16px; color: #000000;">Uşaqlıq poliplərinin əlamətləri aşağıdakılardır:</span></p>\n<ul>\n<li><span style="font-size: 16px;"><strong>Menstrual qanamaların nizamsızlığı</strong></span></li>\n<li><span style="font-size: 16px;"><strong>İki menstruasiya müddəti arasında qanamalar</strong></span></li>\n<li><span style="font-size: 16px;"><strong>Menstrual qanamaların həddindən artıq çoxluğu</strong></span></li>\n<li><span style="font-size: 16px;"><strong>Menopoz dövründə olan vaginal qanamalar</strong></span></li>\n<li><span style="font-size: 16px;"><strong>Sonsuzluq</strong></span></li>\n</ul>\n<p><span style="font-size: 16px; color: #000000;">Poliplər bəzi qadınlarda sadəcə yüngül qanaxma və ya ləkələnmə şəklində, bəzilərində isə ümumiyyətlə heç bir əlamət olmadan yaranır.</span></p>\n<p>&nbsp;</p>\n<p><span style="font-size: 16px; color: #000000;"><strong>UŞAQLIQ POLİPLƏRİNİN SƏBƏBLƏRİ:</strong></span></p>\n<p><span style="font-size: 16px; color: #000000;">Uşaqlıq poliplərinin yaranmasında hormonal amillərin rolu böyükdür. Uşaqlıq polipləri estrogen hormonuna qarşı olduqca həssasdır, yəni qan dövranı zamanı qanda olan estrogenə cavab olaraq böyüyürlər.</span></p>\n<p>&nbsp;</p>\n<p><span style="font-size: 16px; color: #000000;"><strong>UŞAQLIQ POLİPLƏRİNİN MÜALİCƏSİ</strong></span></p>\n<p><span style="font-size: 16px; color: #000000;">Heç bir əlamət göstərməyən kiçik ölçülü poliplər müalicəsiz də yox ola bilərlər. Uşaqlıq xərçəngi yaranma riski yoxdursa, kiçik poliplərin müalicəsinə ehtiyyac yoxdur.</span></p>\n<p><span style="font-size: 16px; color: #000000;"><strong>Dərman</strong></span></p>\n<p><span style="font-size: 16px; color: #000000;">Progestinlər və gonadotropin yaradan hormon agonistləri də daxil olmaqla bəzi hormonal dərmanlar polip əlamətlərini azalda bilərlər. Lakin, bu cür dərmanların qəbulu qısamüddətli həll yoludur. Dərman qəbul etmək dayandırıldığı zaman əlamətlər yenidən təkrarlanır.</span></p>\n<p><span style="font-size: 16px; color: #000000;"><strong>Cərrahi yolla müdaxilə</strong></span></p>\n<p><span style="font-size: 16px; color: #000000;">Uşaqlıq poliplərinin müalicəsi "Histeroskopiya" adlı üsulla asanlıqla həyata keçirilir. Bu prosedur lokal və ya ümumi anesteziy ilə aparılır və təxminən 15-20 dəqiqə çəkir. Uşaqlığa bir kamera vasitəsilə vajinal yolla girilərək qarın nahiyəsinə kəsiyə ehtiyyac qalmadan polip kökü ilə birlikdə çıxarılır. Bu yolla alınan parça patoloji müayinə üçün götürülür. Əksər hallarda poliplərin patoloji dəyərləndirilməsinin nəticəsi xoşxassəli olur.</span></p>\n<p><span style="font-size: 16px; color: #000000;">Polip müalicəsi zamanı erkən diaqnoz qoyulması və müalicənin düzgün planlaşdırılaraq edilməsi menstrual pozğunluğu, cinsi əlaqədən sonra yaranan qanaxma və ağrı hallarını, sonsuzluq kimi problemləri aradan qaldıra bilər.</span></p>\n<p><span style="font-size: 16px; color: #000000;">Nadir hallarda, uşaqlıq poliplərinin təkrarlanma ehtimalı ola bilər. Belə bir vəziyyətlə qarşılaşardığınız zaman yenidən müalicə olunaraq problemi aradan qaldırmaq mümkündür.</span></p>\n<p>&nbsp;</p>', '1-1634213404.png', 1, 1),
(6, '', '', 'Uşaqlıq boynunun eroziyası', '', '', 'Uşaqlıq boynunun daxili səthini örtən epiteliya hüceyrələri glandular xüsusiyyətə yəni ifrazat etmə xüsusiyyətinə malik olduğu halda, vaginanın daxili səth hüceyrələri bu hissəni müxtəlif xarici amillərdən (bakteriya, virus, cinsi əlaqənin "aşındırıcı" təsirlərindən) qorumaq vəzifəsi olan yastı epiteliya hüceyrələridir.', '', '', '<h1 style="text-align: justify;"><span style="font-size: 18px;"><strong>SERVİKAL EROZIYA (UŞAQLIQ BOYNUNUN EROZİYASI)</strong></span></h1>\n<p style="text-align: justify;"><span style="font-size: 14px;">Uşaqlıq boynunun daxili səthini örtən epiteliya hüceyrələri glandular xüsusiyyətə yəni ifrazat etmə xüsusiyyətinə malik olduğu halda, vaginanın daxili səth hüceyrələri bu hissəni müxtəlif xarici amillərdən (bakteriya, virus, cinsi əlaqənin "aşındırıcı" təsirlərindən) qorumaq vəzifəsi olan yastı epiteliya hüceyrələridir. Bu iki fərqli hüceyrə növünün bir birinə yaxın olduğu bölgəyə dəyişilmə zonası ( transformation zone) deyilir.</span></p>\n<p style="text-align: justify;"><span style="font-size: 14px;">Dəyişilmə zonasında bir-birindən fərqli olan bu iki hüceyrə fərqli quruluşlarına və davranış xüsusiyyətlərinə görə<img style="float: right; margin: 10px;" src="/images/upload/image/u%C5%9Faql%C4%B1q%20boynunun%20eroziyas%C4%B1.jpg" alt="" width="512" height="320" /> bir-birləri ilə davamlı olaraq uyğunsuzluq yaşayırlar. Qısaca desək, bu bölgədəki hüceyrələrdən biri digər hüceyrənin sərhədlərini aşaraq o bölgədə öz hakimiyyətini qurmaq istədiyi üçün hüceyrələr burada öz sərhədlərini qorumaq naminə daima müharibə vəziyyətində olurlar. Bu hissədə davamlı olaraq məhv olma və yeniləmə halları təkrarlanmaqdadır.</span></p>\n<p style="text-align: justify;"><span style="font-size: 14px;">İnsanlar arasında "yara" olaraq bilinən bu xəstəlik əslində dəyişilmə zonasında uşaqlıq boynu içərisində sekresiya hüceyrələrinin &ldquo;qalibiyyətidir&rdquo;. Dəyişmə zonasındakı "müharibə" sekretor hüceyrələr tərəfindən qazanılıraq vaginanın skuamöz epiteliya hüceyrələri tərəfindən eroziya ilə "əridilir".Bu ərimə spekulum müayinəsi zamanı uşaqlıq boynuna qırmızılıq verir və bu qızarıqlıq "yara" kimi adlandırılır.</span></p>\n<p style="text-align: justify;"><span style="font-size: 14px;">​Uşaqlıq boynunda vaginanın asidli hissəsindən kənarda yaşayan hüceyrələr ətrafa daşdığı zaman da ifraz etmə xüsusiyyətlərini davam etdirirlər. Sekresiya hüceyrələrinin sayı artdığı üçün ifraz miqdarı da artır və bu da xəstənin axıntı şikayəti ilə qarşı-qarşıya qalmağına səbəb olur.</span></p>\n<p style="text-align: justify;"><span style="font-size: 14px;">Uşaqlıq boynu kanalının təbii sekresiyası qələvi xüsusiyyətlərə malikdir. Vagina isə asidli xüsusiyyətə malikdir. Vaginanı infeksiyalara qarşı qoruyan laktobasilli bakteriyalar sadəcə asidli mühitdə yaşaya bilirlər. Uşaqlıq boynunun artan ifrazatı vaginanın asidli mühitini pozduğu zaman laktobasillərin sağlam şəkildə çoxalmağının qarşısı alınır və bu da vaginada infeksiyanın yaranmasına yol açır.Tez-tez vaginit olan qadınlarda əsas səbəbin uşaqlıq boynu yarası olma ehtimali yüksəkdir.</span></p>\n<p style="text-align: justify;"><span style="font-size: 14px;">Uşaqlıq boynu "yarası" axıntı problemindən başqa heç bir şikayət yaratmaya bilir və əksər hallarda müayinə zamanı təsadüfən aşkar edilir. Bəzi qadınlarda cinsi əlaqə zamanı qanaxmaya səbəb olur. Uşaqlıq boynu yaraları görünüşlərinə görə xərçəng və ya xərçəng öncəsi lezyonlarla qarışdırıla bildiyi üçün aşkar edildiyi zaman pap smear testi edilərək dəyərləndirilmə edilir. Eroziya diaqnozu Pap smear testi nəticəsi zamanı təsdiqlənir.</span></p>\n<p style="text-align: justify;"><span style="font-size: 14px;">Eroziya pap smear müayinəsindən sonra şikayətlərə səbəb olarsa, kriyoterapiya (dondurulma üsulu ilə), koterizasiya (yandırılaraq) və ya lazerlə buxarlaşdırılaraq aradan qaldırılması məsləhət görülür.</span></p>\n<p style="text-align: justify;"><span style="font-size: 14px;">Doğum kontrol həblərinin istifadəsi uşaqlıq boynu kanalındakı sekretor hüceyrələrin çoxalmasını asanlaşdırdığı üçün bu həbləri istifadə edən qadınlarda uşaqlıq boynu yaraları nisbətən daha çox görülür.</span></p>', 'usagliginmiomasi-1619543352.png', 2, 1),
(7, '', '', 'Endometrioz', '', '', 'Endometrioz, reproduktiv yaşda olan qadınlarda görülən bir xəstəlikdir. Xəstəlik adını uşaqlığın içərisini əhatələyən və hər ay menstruasiya dövründə qalınlaşaraq tökülən "endometrium" toxumasından alır.', '', '', '<h1 style="text-align: justify;"><span style="font-size: 18px;"><strong>ENDOMETRİOZ (ŞOKOLAD KİSTASI) NƏDİR VƏ NECƏ MÜALİCƏ OLUNUR?</strong></span></h1>\n<p style="text-align: justify;"><span style="font-size: 14px;">Endometrioz, reproduktiv yaşda olan qadınlarda görülən bir xəstəlikdir. Xəstəlik adını uşaqlığın içərisini əhatələyən və hər ay menstruasiya dövründə qalınlaşaraq tökülən "endometrium" toxumasından alır.</span></p>\n<p style="text-align: justify;"><span style="font-size: 14px;">Mündəricat:</span></p>\n<h2 style="text-align: justify;"><span style="font-size: 14px;"><strong>Şokolad kistasının yaranma səbəbi nədir?</strong></span></h2>\n<h2 style="text-align: justify;"><span style="font-size: 14px;"><strong>Şokolad kistasının əlamətləri nələrdir?</strong></span></h2>\n<h2 style="text-align: justify;"><span style="font-size: 14px;"><strong>Endometrioz necə müalicə olunur?</strong></span></h2>\n<h2 style="text-align: justify;"><span style="font-size: 14px;"><strong>Şokolad kisti partlaması nədir və bunu necə başa düşmək olar?</strong></span></h2>\n<p style="text-align: justify;"><span style="font-size: 14px;"><strong><br /></strong></span></p>\n<p style="text-align: justify;"><span style="font-size: 14px;"><strong>Şokolad kistasının yaranma səbəbi nədir?</strong></span></p>\n<p style="text-align: justify;"><span style="font-size: 14px;">Endometrioz, reproduktiv yaşda olan qadınlarda görülən bir xəstəlikdir. Xəstəlik adını uşaqlığın içərisini əhatələyən<img style="float: right; margin: 10px;" src="/images/upload/image/endometrioz_sokalad_kist.jpg" alt="" width="500" height="500" /> və hər ay menstruasiya dövründə qalınlaşaraq tökülən "endometrium" toxumasından alır.</span></p>\n<p style="text-align: justify;"><span style="font-size: 14px;">Endometriozda əslində uşaqlığın daxili qatında olmalı olan endometrium toxuması uşaqlıqdan əlavə bədənin digər hissələrində də olur.</span></p>\n<p style="text-align: justify;"><span style="font-size: 14px;">Uşaqlığın xaricindəki&nbsp; endometriozlar ağrı, sonsuzluq və bəzi digər problemlərə səbəb ola bilir. Endometrioza ən çox rast gəlinən yerlər qarın boşluğu xüsusilə də yumurtalıqlar, uşaqlıq boruları, uşaqlığı dəstəkləyən bağlar, vagina dediyimiz uşaqlıq və anal kanal arasındakı hissə, uşaqlığın xarici və qasıqdır. Menstruasiya dövründə uşaqlıqdakı kimi bu bölgələrdə də qalınlaşma və qanaxma olur. Buna baxmayaraq, uşaqlığı əhatə edən təbəqədən fərqli olaraq uşaqlıq xaricindəki endometriumun bədəni menstrual qan şəklində tərk etmə imkanı yoxdur. Buna görə də öz içərisində qanama şəklində olaraq bu ocaqlardan tökülən qanın ətraf toxumalara ziyan vurması, ətraf toxumalarda iltihabın inkişafı və birləşdirici toxumanın meydana gəlməsi ilə nəticələnir.</span></p>\n<p style="text-align: justify;"><span style="font-size: 14px;">Endometrioz kistaların yerləşdiyi hissəyə görə verdiyi &nbsp;zərərlər də dəyişilir. Endometrioz yumurtalığın üst hissəsində yerləşib kistə çevrildiyi halda &nbsp;endometrioma (şokolad kistası) adlanır.</span></p>\n<p style="text-align: justify;">&nbsp;</p>\n<h2 style="text-align: justify;"><span style="font-size: 14px;"><strong>Şokolad kistasının əlamətləri nələrdir?</strong></span></h2>\n<ul style="text-align: justify;">\n<li>\n<h2><span style="font-size: 14px;">Daimi qasıq ağrısı</span></h2>\n</li>\n<li><span style="font-size: 14px;">Menstruasiya dövründə ağrı</span></li>\n<li><span style="font-size: 14px;">Cinsi əlaqə zamanı qasıq ağrısı</span></li>\n<li><span style="font-size: 14px;">Hamilə qalmamaq</span></li>\n<li><span style="font-size: 14px;">Menstruasiyadan əvvəl ləkə şəklində qanaxma</span></li>\n<li><span style="font-size: 14px;">Qəbizlik - ishal</span></li>\n<li><span style="font-size: 14px;">Tualet ehtiyacı zamanı ağrı</span></li>\n<li><span style="font-size: 14px;">Yan ağrısı, bel ağrısı</span></li>\n<li><span style="font-size: 14px;">Tez-tez sidiyə çıxma və sidikdə qan endometriozun simptomları arasındadır.</span></li>\n</ul>\n<p style="text-align: justify;">&nbsp;</p>\n<h2 style="text-align: justify;"><span style="font-size: 14px;"><strong>Endometrioz necə müalicə olunur?</strong></span></h2>\n<p style="text-align: justify;"><span style="font-size: 14px;">Endometriozun müalicəsi &nbsp;dərman və cərrahi olaraq iki yolla aparılır:</span></p>\n<p style="text-align: justify;"><span style="font-size: 14px;">Dərman müalicəsi: Xəstəliyin erkən mərhələsində menstruasiya ağrısının qarşısını almaq, mensturasiya vaxtını tənzimləmək və endometriotik ocaqları yox etmək üçün istifadə olunan əsas dərmanlar; doğuşa nəzarət həbləri, progestinlər, danazol və GnRH analoqlarıdır.</span></p>\n<p style="text-align: justify;"><span style="font-size: 14px;">Cərrahi üsul: Ağrını azaltmaq və doğuş ehtimalını yüksəltmək üçün cərrahi əməliyyat edilə bilər. Əməliyyatla endometriotik toxumalar çıxarılır və həmin bölgədə əmələ gələn yapışqanlıq sərbəst buraxılır. Əməliyyatın məqsədi normal anatomiyanı yenidən bərpa etməkdir.</span></p>\n<p style="text-align: justify;"><span style="font-size: 14px;">Əksər qadınlarda əməliyyatdan sonra ağrı yox olsa da, &nbsp;40-80% qadında 2 il ərzində &nbsp;ağrı yenidən qayıda bilər.</span></p>\n<p style="text-align: justify;"><span style="font-size: 14px;">Uşaq istəyən qadınlarda reproduktivliyi qoruyan (konservativ) cərrahiyyə əməliyyatı edilə bilmirsə və ya yetərli deyilsə, köməkçi reproduktiv üsullarla (süni mayalanma və ya IVF) hamiləlik yaradılmağa çalışılır.</span></p>\n<p style="text-align: justify;"><span style="font-size: 14px;"><strong>&nbsp;</strong></span></p>\n<h2 style="text-align: justify;"><span style="font-size: 14px;"><strong>Şokolad kisti partlaması nədir və bunu necə başa düşmək olar?</strong></span></h2>\n<p style="text-align: justify;"><span style="font-size: 14px;">Həddindən artıq çox böyüyən endometrioma kistalarında dartılma və ya çəkilmə səbəbi ilə qəfil partlayış (qırılma) meydana gələ bilər. Şokolad kistləri ətrafdakı toxumalara yapışdıqları üçün &nbsp;yapışdıqları orqan və ya toxumaların hərəkəti də bu kistlərin dartılmasına və ya çəkilməsinə səbəb ola bilər.</span></p>\n<p style="text-align: justify;"><span style="font-size: 14px;">Bundan əlavə, kənardan qarın bölgəsinə vurulan zərbələr və ya travmalar da şokolad kistlərinin partlamasına səbəb ola bilər.</span></p>\n<p style="text-align: justify;"><span style="font-size: 14px;">Ən əsas əlaməti birdən birə başlayan &nbsp;və çox şiddətli şəkildə olan qarın ağrısıdır.</span></p>\n<p style="text-align: justify;"><span style="font-size: 14px;">Partlayan şokolad kistası ginekoloqlar tərəfindən təcili əməliyyat tələb edən bir vəziyyətdir. Bu səbəblə &nbsp;kiçik ölçülü kistlərin həkim tərəfindən tövsiyə olunan aralıqlarla mütəmadi olaraq müayinə edilməsi vacibdir. Bu şəkildə reproduktivliyi qorumaq üçün daha erkən tədbirlər alına bilər.</span></p>\n<p style="text-align: justify;">&nbsp;</p>\n<p style="text-align: justify;">&nbsp;</p>\n<div id="gtx-trans" style="position: absolute; left: 359px; top: 1374.76px;">&nbsp;</div>', 'usagliginmiomasi-1619543376.png', 3, 1),
(8, '', '', 'Uşaqlıq boynunun kistaları', '', '', 'Uşaqlıq boynu kistaları servikal kanaldakı sekretor vəzlərinin ucunda infeksiya və ya başqa bir səbəbdən tıxanma yaradan içi dolu bir mayedir. Vəzlərin yaratdığı sekresiya xaric olmadığı üçün tıxanma yaranan hissədə içi dolu kiçik kistlərin yaranmasına səbəb olur. Uşaqlıq yolunda bu kistlərdən eyni anda bir və daha çoxu yarana bilər. Bu kistlərin diametri 2-10 mm arasında dəyişir. Kistlərin içərisində selik adlanan yapışqan maye mövcuddur.', '', '', '<p><span style="font-size: 16px;"><strong>NABOT KİSTALARI (UŞAQLIQ BOYNU KİSTALARI) NƏDİR?</strong></span></p>\n<p><span style="font-size: 16px;">Uşaqlıq boynu kistaları&nbsp;kistaları servikal kanaldakı sekretor vəzlərinin ucunda infeksiya və ya başqa bir səbəbdən tıxanma yaradan içi dolu bir mayedir. Vəzlərin yaratdığı sekresiya xaric olmadığı üçün tıxanma yaranan hissədə içi dolu kiçik kistlərin yaranmasına səbəb olur. Uşaqlıq yolunda bu kistlərdən eyni anda bir və daha çoxu yarana bilər. Bu kistlərin diametri 2-10 mm arasında dəyişir. Kistlərin içərisində selik adlanan yapışqan maye mövcuddur.</span></p>\n<p><span style="font-size: 16px;">Servikal kisatlar olaraq da bilinən bu kisatlara doğuş etmiş analarda daha çox rast gəlinir. Bir çox qadınlarda bu kistaların varlığı heç bir əlamət vermir. Bu kisatların diaqnozu çox zaman həkimlər tərəfindən ginekoloji müayinə zamanı edilir.&nbsp; Uşaqlıq boynu kisatları tez-tez rastlanan xəstəlikdir.</span></p>\n<p><span style="font-size: 16px;">Uşaqlıq boynunda olan kisatlar xərçəng təhlükəsi daşımır. Bu kisatlar əsasən doğuşdan sonra və ya uşaqlıq boynunun travmaya məruz qalması səbəbilə ortaya çıxır. &nbsp;Kistalar əsasən ağ və ya sarı rəngdəd və yumuşaq olurlar. Bu kisatlar demək olar ki heç bir əlamətlə özünü biruzə vermir.</span></p>\n<p><span style="font-size: 16px;"><strong>&nbsp;</strong></span></p>\n<p><span style="font-size: 16px;"><strong>Mündəricat:</strong></span></p>\n<p><span style="font-size: 16px;"><strong>Nabot kistasının əlamətləri nələrdir?</strong></span></p>\n<p><span style="font-size: 16px;"><strong>Nabot kistasının səbəbləri nələrdir?</strong></span></p>\n<p><span style="font-size: 16px;"><strong>Nabot kistasının diaqnozu necə qoyulur?</strong></span></p>\n<p><span style="font-size: 16px;"><strong>Nabot kistasının müalicəsi necədir?</strong></span></p>\n<p><span style="font-size: 16px;"><strong>Nabot kistası hamiləlik üçün təhlükəlidirmi?</strong></span></p>\n<p>&nbsp;</p>\n<p><span style="font-size: 16px;"><strong>Nabot kistasının əlamətləri nələrdir?</strong></span></p>\n<p><span style="font-size: 16px;">Uşaqlıq boynu kistaları xarici servikal divarda meydana gəlir və sağlamlığa mənfi təsir göstərən heç bir əlamət göstərmir. Yaranan narahatlıqlar kistaların ölçüsünə görə dəyişir. Kiçik ölçülü kistalar ağrı və narahatlıq yaratmır. Bununla birlikdə, diametri 8 sm-dən böyük olan kistaların varlığı uşaqlıq xərçəngi və yaxud uşaqlıq boynu xərçənginin əlaməti ola bilər.</span></p>\n<p><span style="font-size: 16px;">Nabot kistalarının əlamətləri aşağıdakılardır:</span></p>\n<p><span style="font-size: 16px;">İki menstruasiya arasında ləkələnmə və ya qanama</span></p>\n<p><span style="font-size: 16px;">Pis qoxulu vaginal axıntı</span></p>\n<p><span style="font-size: 16px;">Qarının alt hissəsində hissedilən təzyiq və ya şişlik</span></p>\n<p><span style="font-size: 16px;">Tez-tez sidiyə getmək</span></p>\n<p><span style="font-size: 16px;">Cinsi əlaqədən sonra yaranan qanaxma</span></p>\n<p><span style="font-size: 16px;">Servikal kistalar bir çox qadında simptomlar görünmədən də meydana gələ bilər.</span></p>\n<p>&nbsp;</p>\n<p><span style="font-size: 16px;"><strong>Nabot kistasının səbəbləri nələrdir?</strong></span></p>\n<p><span style="font-size: 16px;">Uşaqlıq boynunda selik istehsal edən vəzlər mövcuddur və bu vəzlər dəri qatı ilə örtülmüşdür. Nabot kistaların meydana gəlməsinə səbəb olan şərtlər aşağıdakılardır:</span></p>\n<p><span style="font-size: 16px;">Servikal vəzlər o bölgədəki infeksiya və ya iltihabdan qorunmaq üçün yüksək miqdarda selik ifraz edir. Bu vəziyyət təkrarlanaraq sonda tıxanmalara və kistaların yaranmasına gətirib çıxarır. Eyni zamanda cinsi əlaqə yolu ilə keçən infeksiyalar da uşaqlıq boynunda kistaların əmələ gəlməsinə səbəb olur.</span></p>\n<p><span style="font-size: 16px;">Ana olmağa hazırlaşan qadınlarda yaranan hormonal dəyişikliklər uşaqlıq boynu kistalarının yaranmağına səbəb ola bilər. Bu kistalar hormon səviyyəsində yaranan böyük dəyişikliklər nəticəsində meydana çıxır. Hormon dəyişiklikləri hamiləlik, doğuş və ya menopoz dövründə özünü ən yüksək həddə göstərir.</span></p>\n<p><span style="font-size: 16px;">Uşaqlıq boynunu örtən toxumalar zədələndiyi zaman da nabot kistalar yarana bilər. Bədənimiz zədələnmiş bölgələri sağaltmaq üçün yeni toxumalar istehsal edir. Bu toxumalar çoxaldığı zaman da kistalar meydana çıxa bilər.</span></p>\n<p><span style="font-size: 16px;">Uşaqlıq boynu spermanın vaginadan uşaqlığa, aybaşı mayesinin uşaqlıqdan vaginaya axmasını təmin etmək üçün daima açıq olur. Hamiləlik zamanı ana bətnində fetusun inkişafını təmin etmək məqsədilə uşaqlığın ağzı bağlanır. Doğuşdan sonra mukozada yeni toxumalar böyüyür. Toxumalarda həddindən artıq böyümə olduğu zaman vəzlərdə tıxanma meydana gəlir və selik axmadığı üçün də kistalar meydana çıxa bilir.</span></p>\n<p>&nbsp;</p>\n<p><span style="font-size: 16px;"><strong>Nabot kistasının diaqnozu necə qoyulur?</strong></span></p>\n<p><span style="font-size: 16px;">Uşaqlıq boynunun kistləri bir çox səbəbə görə yaranabilər. Ancaq simptomlar bir çox qadında özünü biruzə vermir. Bu kistlərin varlığı çox vaxt rutin ginekoloji müayinələr zamanı aşkarlanır. Nabot kistası aşağıdakı üsullarla diaqnoz edilə bilər:</span></p>\n<p><span style="font-size: 16px;">Kist endoservikal kanala yaxın yerləşdiyi və bu sahədə genişlənmə olduğu zaman çanaq və ya uşaqlıq boynu ultrasəs müayinəsi ilə müəyyən edilə bilər.</span></p>\n<p><span style="font-size: 16px;">Kistin üzərində toxuma yırtığı və ya servikal zədələnmə olub olmadığı qasıq MRT-si ilə müəyyən edilə bilər.</span></p>\n<p><span style="font-size: 16px;">Kistanın ölçüsü kiçik olduğu zaman uşaqlıq boynu kompüter tomoqrafiyası ilə görüntülənə bilər.</span></p>\n<p><span style="font-size: 16px;">Uşaqlıq boynu və vaginanın divarlarını vaginal qasıq ultrasəs müayinəsi ilə incələyə bilən kolposkopiya aləti ilə də nabot kistaların diaqnozu düzgün qoyula bilər.</span></p>\n<p><span style="font-size: 16px;">Cinsi yolla keçən xəstəlikləri təyin etmək və kistaların xərçəng olub olmadığını təyin etmək üçün biopsiya da edilə bilər.</span></p>\n<p>&nbsp;</p>\n<p><span style="font-size: 16px;"><strong>Nabot kistasının müalicəsi necədir?</strong></span></p>\n<p><span style="font-size: 16px;">Uşaqlıq boynunun kistaları yalnız həkim tövsiyəsi və sizin qərarınızla götürülə bilər. Bu kistlərdən xilas olmaq üçün bir neçə üsul mövcuddur. Hansı üsuldan istifadə edəcəyiniz həkim müayinəsi nəticəsində təyin olunur. İstifadə edilən metodlar aşağıdakılardır:</span></p>\n<p><span style="font-size: 16px;">Nabot kistası böyükdürsə kista və ətrafdakı toxumalar endoskopiya ilə cərrahi əməliyyatla götürülə bilər.</span></p>\n<p><span style="font-size: 16px;">Yüksək tezlikli elektrik cərəyanları ilə elektrokimyəvi ablasyon da edilə bilər. Bu prosedur zamanı elektrik cərəyanı servikal bölgədəki anormal kütləni yox edəbilər və ya oradakı mayenin axmağına səbəb ola bilər. Bu prosedurda qan itkisi ən aşağı səviyyədə olur.</span></p>\n<p><span style="font-size: 16px;">Servikal kistaların müalicəsi zamanı çox asan bir üsul olan kriyoterapiya üsulu da istifadə edilə bilər. Bu prosedur zamanı kista dondurula bilər. Eyni zamanda kistanın yox edilməsi üçün maye azotdan da istifadə edilə bilər.</span></p>\n<p><span style="font-size: 16px;">Qanaxma və ya infeksiyaların ağırlaşmalarını azaltmaq üçün lazer terapiyası üsulu da istifadə edilə bilər. Kistlər lazerlə tez və etibarlı şəkildə yox edilə bilər.</span></p>\n<p><span style="font-size: 16px;">Naboth kistalarının müalicəsi məqsədilə istifadə olunan bütün üsullar təhlükəsizdir. Müayinə zamanı xəstənin vəziyyəti, aparılan testlər, həkimin tövsiyələri tətbiq ediləcək müalicə metodunu təyin etmək üçün olduqca əhəmiyyətlidir. Qeyd edək ki, bu kistalar şikayət yaratmırsa müalicəyə ehtiyyac yoxdur.</span></p>\n<p>&nbsp;</p>\n<p><span style="font-size: 16px;"><strong>Nabot kistası hamiləlik üçün təhlükəlidirmi?</strong></span></p>\n<p><span style="font-size: 16px;">Uşaqlıq boynunda yaranan şişliklər hamiləliyə təsir edə bilər. Bu bölgədə böyüyən kistalar uşaqlıq boynunun açılmağına maneə yaradaraq dölün mayalanmasını çətinləşdirə bilər. Qadınlarda yumurtlama zamanı spermanın yumurtaya çatması üçün servikal selikin tərkibi incə və sürüşkən olmalıdır. Selik qalın və yapışqan olarsa, mayalanmaya mənfi təsir göstərə bilər.</span></p>\n<p><span style="font-size: 16px;">Gündəlik həyatda servikal kistalar təhlükə yaratmır və müalicə etdirməyə ehtiyac yoxdur. Bununla birlikdə, riskləri aradan qaldırmaq və yarana biləcək problemlərin qarşısını almaq üçün kistanın ölçüsünü incələmək və mütəmadi izləmək faydalıdır. Böyük kistalar ağrıya səbəb ola bilər.</span></p>\n<p>&nbsp;</p>', 'usagliginmiomasi-1619543389.png', 4, 1),
(9, '', '', 'Uşaqlıq yolunun kistləri', '', '', '', '', '', '', 'usagliginmiomasi-1619543981.png', 7, 1),
(10, '', '', 'Xarici tənasül orqanlarının papilomaları, kandilomaları, kistaları,', '', '', '', '', '', '', 'usagliginmiomasi-1619544020.png', 8, 1),
(11, '', '', 'Uşaqlıq boynunun xərçəngi', '', '', 'Uşaqlıq boynu xərçəngi ildə təxminən 500.000-ə yaxın diaqnozu qoyulan və qadınlarda ən çox görülən 5 xərçəng növündən biridir.\n\nUşaqlıq boynu xərçəngi &single_quot;serviks&single_quot; adlanan uşaqlıq boynunda yaranan xərçəngdir. Serviksin üst səthində olan hüceyrə təbəqəsi anormal hüceyrələrə çevrilərək &single_quot;xərçəng prekursorları&single_quot; (CIN) adlandırılan hüceyrələr meydana gətirir. Xərçəng prekursorları erkən mərhələdə aşkarlanmadığı və müalicə edilmədiyi zaman uşaqlıq boynu xərçənginə çevrilə bilir.', '', '', '<h1 style="text-align: justify;"><span style="font-size: 18px;"><strong>UŞAQLIQ BOYNU</strong><strong>(SERVİKAL)</strong><strong> XƏRÇƏNGi</strong></span></h1>\n<p style="text-align: justify;">&nbsp;</p>\n<h1 style="text-align: justify;"><span style="font-size: 18px;"><strong>Uşaqlıq Boynu Xərçəngi Nədir?</strong></span></h1>\n<p style="text-align: justify;"><span style="font-size: 14px;">Uşaqlıq boynu xərçəngi ildə təxminən 500.000-ə yaxın diaqnozu qoyulan və qadınlarda ən çox görülən 5 xərçəng növündən biridir.</span></p>\n<p style="text-align: justify;"><span style="font-size: 14px;">Uşaqlıq boynu xərçəngi &single_quot;serviks&single_quot; adlanan uşaqlıq boynunda yaranan xərçəngdir. Serviksin üst səthində olan hüceyrə təbəqəsi anormal hüceyrələrə çevrilərək &single_quot;xərçəng prekursorları&single_quot; (CIN) adlandırılan hüceyrələr meydana gətirir. Xərçəng prekursorları erkən mərhələdə aşkarlanmadığı və müalicə edilmədiyi zaman uşaqlıq boynu xərçənginə çevrilə bilir.</span></p>\n<p style="text-align: justify;"><span style="font-size: 14px;">Bu dəyişikliyə əsas səbəb isə &single_quot;HPV&single_quot; olaraq bilinən İnsan Papilloma Virusudur. HPV, həmçinin cinsiyyət orqanında ziyillərin əmələ gəlməsinə səbəb olan bir virusdur. Bu virus cinsi yolla keçir.</span></p>\n<p style="text-align: justify;">&nbsp;</p>\n<p style="text-align: justify;"><span style="font-size: 18px;"><strong>Uşaqlıq Boynu Xərçənginin Əlamətləri</strong></span></p>\n<p style="text-align: justify;"><span style="font-size: 14px;">Uşaqlıq boynu xərçəngi erkən mərhələlərdə heç bir əlamət vermir. Bununla birlikdə, vaginal qanaxma, vajinada dolğunluq və ya kütlə hissi, vaginal axıntı və ağrılı cinsi əlaqə əsas əlamətlərdəndir. Qanaxma, cinsi əlaqə zamanı və ya əlaqədən sonra damcı və pis qoxulu axıntı şəklində özünü biruzə verə bilər.</span></p>\n<p style="text-align: justify;"><span style="font-size: 14px;">Şiş yuxarı hissədə uşaqlıqarası boşluğa, aşağı hissədə vaginaya, yanlara doğru isə qasıq divarına doğru yayıla bilər. Sidik kisəsini və rektumu isə birbaşa ələ keçirə bilər. Bu yayılmalarla əlaqəli olaraq qəbizlik, qanlı idrar, vaginadan idrar və ya nəcis gəlməsi, sidik kanalının genişlənməsi və ya böyrəyin böyüməsi əlamətləri ortaya çıxabilər.</span></p>\n<p style="text-align: justify;"><span style="font-size: 14px;">Xəstəliyin qasıq divarına yayılması zamanı ayaq ağrısı, şiddətli bel və qasıq ağrısı görülə bilər. Eyni zamanda şişkinlik hissi də meydana gələ bilər. Əlavə olaraq çanaq limfa düyünlərinin tutulması, qaraciyər, ağciyər və sümüyə yayılma şəklində uzaq orqan metastazları da yarana bilər. Servikal xərçəng əsasən orta və yaşlı qadınlarda görülsə də, hər yaşda ortaya çıxa bilər.</span></p>\n<p style="text-align: justify;">&nbsp;</p>\n<h2 style="text-align: justify;"><span style="font-size: 14px;"><strong>Uşaqlıq Boynu Xərçənginin Risk Faktorları</strong></span></h2>\n<p style="text-align: justify;"><span style="font-size: 14px;">HPV infeksiyaları uşaqlıq boynunda meydana gələn hüceyrə dəyişikliklərinin ən əsas səbəbidir. HPV virusu cinsi əlaqədən sonra servikal hüceyrələrin içərisinə yerləşir. Qadınların 50-80%-i nə vaxtsa HPV infeksiyası ilə qarşılaşa bilərlər. İmmunitet sistemimiz 12-18 ay ərzində 90% ehtimalla bu cür infeksiyaları yox edə biləcək gücdədir. HPV infeksiyasına yoluxmaq uşaqlıq boynu xərçəngi olmaq demək deyil.<strong></strong></span></p>\n<p style="text-align: justify;"><span style="font-size: 14px;">HPV infeksiyasının xərçəng tipli olanları servikal hüceyrələrdə genetik dəyişikliklər yaradaraq kanserogen dəyişikliklərə səbəb ola bilərlər. Bu təxminən 10-15 illik bir müddətdə baş verir. Bu səbəblə həkimlər müayinələr zamanı xərçəngə çevrilmədən əvvəl bu xəstəliyi aşkarlayıb qarşısını ala bilərlər.</span></p>\n<p style="text-align: justify;">&nbsp;</p>\n<h2 style="text-align: justify;"><span style="font-size: 18px;"><strong>Uşaqlıq </strong><strong>B</strong><strong>oynu Xərçənginin Diaqnoz Metodları</strong></span></h2>\n<p style="text-align: justify;"><span style="font-size: 14px;">İlkin olaraq ginekoloji müayinə zamanı PAP smear testi edilən xəstələrdə anormal test nəticəsi ortaya çıxması ilə<iframe allowFullScreen="allowFullScreen" src="http://www.youtube.com/embed/MIHgInNRKHc" frameborder="0" align="right" width="500" height="280"></iframe> başlayır.</span></p>\n<p style="text-align: justify;"><span style="font-size: 14px;">Anormal PAP smear nəticəsindən sonra, nəticəyə əsasən bir müddət sonra ikinci dəfə PAP smear testi edilə və ya uşaqlıq boynu kolposkopiya adlanan cihazla müayinə edilə bilər. Kolposkopiya zamanı ehtiyyac olduğu təqdirdə biopsiya da edilə bilər.Eyni zamanda uşaqlıq boynu xərçəngindən qorunmaq və erkən diaqnoz qoymaq üçün müntəzəm olaraq PAP smear testindən də istifadə olunur. Bundan əlavə, HPV-DNA adlı müayinə də PAP smear ilə birlikdə və ya tək olaraq istifadə edilə bilən müayinə üsulları arasındadır.</span></p>\n<p style="text-align: justify;"><span style="font-size: 14px;">Normal şərtlərdə 20-30 yaş arası qadınlarda HPV görülmə ehtimalı 30-50% təşkil edir. Bu yaş aralığındakı qadınlara HPV testi edildiyi zaman xəstələrin çoxunda nəticələr müsbət olur və HPV testinin heç bir mənası qalmır.Buna görə də, 20-30 yaş arasındakı qadınların hər üç ildən bir smear testi etmələri məsləhət olunur. Bu yol izləndiyi zaman HPV-nin görülmə ehtimalı sadəcə 7% təşkil edir.</span></p>\n<p style="text-align: justify;"><span style="font-size: 14px;">30 yaşdan sonra PAP smearla edilən sitoloji müayinəyə HPV DNT testi də əlavə edilir. Co-test olaraq bilinən PAPsmear ilə yüksək riskli HPV DNT testinin birlikdə aparıldığı bu müayinə zamanı lazımsız biyopsiya etməyə ehtiyyac qalmır. Bu test xəstələrə müayinələr arası zamanı uzatmaq şansı verir.</span></p>\n<p style="text-align: justify;"><span style="font-size: 14px;">Xəstəliyin diaqnozu zamanı xəstənin narahatlığını azaldan, maddi olaraq daha uyğun olan və müayinənin dəqiqlik dərəcəsini artıran bu testin nəticəsi mənfi olarsa, xəstənin növbəti müayinəsi beş il sonra aparılır.</span></p>\n<p style="text-align: justify;"><span style="font-size: 14px;">Sadəcə PAP smear testi ilə müayinə zamanı isə testin üç ildən bir təkrar edilməsi uyğun hesab edilir.</span></p>\n<p style="text-align: justify;">&nbsp;</p>\n<h2 style="text-align: justify;"><span style="font-size: 18px;"><strong>Uşaqlıq Boynu Xərçəngindən Qorunma Üsulları</strong></span></h2>\n<p style="text-align: justify;"><span style="font-size: 14px;">ü HPV virusu riski peyvəndlə minimuma endirilə bilər. HPV peyvəndi, virusun yaratdığı xərçənglərdən qorunmaq üçün ən etibarlı və təsirli yoludur.</span></p>\n<p style="text-align: justify;"><span style="font-size: 14px;">ü Beynəlxalq səhiyyə təşkilatları 11-12 yaş arasındakı bütün oğlan və qız uşaqlarına iki və ya üç doza olaraq HPV peyvəndi edilməsini tövsiyə edir. Əgər bu yaşlarda peyvənd edilməyibsə, kişilər üçün 21 yaşa qədər, qadınlar üçün isə hər yaşda peyvənd edilə bilər.</span></p>\n<p style="text-align: justify;"><span style="font-size: 14px;">ü 21-65 yaş arası qadınlarda aparılan PAP smear və HPV kimi testlərlə uşaqlıq boynu xərçəngi erkən diaqnoz edilə bilər.</span></p>\n<p style="text-align: justify;"><span style="font-size: 14px;">ü Cinsi olaraq aktiv həyatınız varsa, uşaqlıq boynu xərçəngindən qorunmaq üçün hər dəfə cinsi əlaqə zamanı prezervativ istifadə etməyiniz məsləhət görülür. Bu virus riskini azaltsa da, HPV prezervativin qoruya bilmədiyi hissələrə yoluxa bilər. Buna görə də prezervativlər HPV-yə qarşı tam qorunma təmin edə bilmir. Qarşılıqlı olaraq hər iki tərəfin tək partnyoru olmağı virusun ötürülmə ehtimalını azaldır.</span></p>\n<p style="text-align: justify;">&nbsp;</p>\n<h2 style="text-align: justify;"><span style="font-size: 18px;"><strong>Uşaqlıq Boynu Xərçənginin Müalicə Üsulları</strong></span></h2>\n<p style="text-align: justify;"><span style="font-size: 14px;">Uşaqlıq boynu xərçənginin müalicəsində istifadə olunan üsullar cərrahiyyə və radioterapiya olaraq 2 əsas qrupa bölünür. Radioterapiya uşaqlıq boynu xərçənginin bütün mərhələlərində istifadə ediləbilən bir müalicə üsuludur. İlkin mərhələdə qoyulan diaqnoz zamanı xəstəliyin yayılması hələ çox az olduğu üçün cərrahi müdaxilə ön planda olur.</span></p>\n<p style="text-align: justify;"><span style="font-size: 14px;">Xəstəliyin yayıldığı mərhələlərdə isə əsas müalicə üsulu radioterapiyadır. Cərrahi müdaxilə ilə uşaqlıq boynu hissəsində yerləşən şiş və onun yayıldığı hissələrin təmizlənməsi hədəflənir. Cərrahi müdaxilə şişin ölçüsünə görə aşağıda qeyd edilən kiçik cərrahi üsullardan, bütün uşaqlığın, uşaqlıq boynunun və limfa düyünlərinin çıxarıldığı böyük cərrahi əməliyyatlara qədər fərqli formalarda edilə bilər.</span></p>\n<p style="text-align: justify;">&nbsp;</p>\n<h2 style="text-align: justify;"><span style="font-size: 18px;"><strong>LEEP (Loop electrosurgical procedure)</strong></span></h2>\n<p style="text-align: justify;"><span style="font-size: 14px;">Uşaqlıq boynundakı hüceyrə dəyişikliklərinin diaqnozu və müalicəsində əvəzsiz bir vasitədir. Elektrik enerjisinin toxuma üzərindəki kəsilmə və qanaxmaları dayandırabilmə gücündən istifadə edilərək yaradılan üsuldur.</span></p>\n<h2 style="text-align: justify;"><span style="font-size: 18px;"><strong>Kriyoterapiya</strong></span></h2>\n<p style="text-align: justify;"><span style="font-size: 14px;">Hüceyrələrarası suyu kristallaşdıraraq serviks səthinin zədələnməsi və hüceyrə ölümü ilə nəticələnən bir üsuldur.</span></p>\n<h2 style="text-align: justify;"><span style="font-size: 18px;"><strong>Lazer terapiyası</strong></span></h2>\n<p style="text-align: justify;"><span style="font-size: 14px;">Xərçəngin yayılması zamanı bütün lezyonun görülə biləcəyi və uşaqlıqdaxili küretajın nəticəsinin təmiz olduğu hər vəziyyətdə istifadə edilə bilən üsuldur.</span></p>\n<h2 style="text-align: justify;"><span style="font-size: 18px;"><strong>Konizasiya</strong></span></h2>\n<p style="text-align: justify;"><span style="font-size: 14px;">Uşaqlıq boynunun hüceyrə dəyişikliklərinin müalicəsində böyük rol oynayan, uşaqlıq boynundan konus şəklində bir hissənin çıxarılaraq edildiyi cərrahi bir üsuldur.</span></p>\n<p style="text-align: justify;">&nbsp;</p>\n<h2 style="text-align: justify;"><span style="font-size: 18px;"><strong>BUNLARI BiLiRSiNiZMi?</strong></span></h2>\n<h2 style="text-align: justify;"><span style="font-size: 18px;"><strong>Bəzi HPV növləri xərçəngə səbəb olur</strong></span></h2>\n<p style="text-align: justify;"><span style="font-size: 14px;">Yaşadığımız dövrdə HPV infeksiyasının bəzi köməkçi amillərin təsiri ilə birlikdə uşaqlıq boynu xərçənginin yaranmasına səbəb olduğu bilinir. Bütün servikal xərçənglərin 99,7%-də HPV DNT-si mövcuddur. Dəridə və selikli qişalarda aşkar olunan bu virusun 200-dən çox növü var və bunların 40%-i anus və genital epiteliyada görülür. .Virusa ən əsas yoluxma şəkli cinsi əlaqədir. Son tədqiqatlar göstərir ki, 15 anogenital HPV növü tam olaraq xərçəng yaradır, 3 növü isə xərçəngin əmələ gəlməsində yüksək risk daşıyır. Tədqiqatçılar xərçəngin əmələ gəlməsi üçün uşaqlıq boynunda HPV olmağının lazım olduğunu vurğulasalar da, xərçəngin yaranmasında tək bu virusun kifayət etmədiyi fikri ilə razılaşırlar.</span></p>\n<p style="text-align: justify;">&nbsp;</p>\n<h2 style="text-align: justify;"><span style="font-size: 18px;"><strong>Fərqli Xəstəliklər Eyni Əlamətləri Göstərə Bilər</strong></span></h2>\n<p style="text-align: justify;"><span style="font-size: 14px;">Servikal xərçəngdə xəstəliyin klassik əlamətlərinin çoxu vaginal infeksiya, uşaqlıq mioması və poliplər kimi xərçəng olmayan xoşxassəli şişlər zamanı da görülə bilər. Buna görə bu əlamətlərin altında hansı xəstəliyin yatdığını müəyyən etmək üçün mütləq həkim müayinəsinə ehtiyyac var.</span></p>', 'usagliginmiomasi-1619544034.png', 5, 1),
(12, '', '', 'Yumurtalıq xərçəngi', '', '', 'Ginekoloji xərçənglər arasında uşaqlıq boynu xərçəngindən sonra ikinci yerdə olan yumurtalıq xərçəngi erkən təyin olunmadıqda çox təəssüf ki, ürəkaçan nəticələr əldə edilməyən xərçəng növüdür. Əsasən postmenopauzal dövrdə daha çox rast gəlinən yumurtalıq xərçəngi lazımi müalicələr ilə erkən zamanlarda 80-90 faiz sağala bilən bir xərçəng növüdür. Ancaq gecikdirilmiş mərhələrdə isə sağalma şansı daha da azalır.', '', '', '<p><strong><span style="font-size: 18px;">Yumurtalıq xərçəngi </span></strong></p>\n<p><strong><span style="font-size: 18px;">Yumurtalıq xərçəngi nədir?</span></strong></p>\n<p><strong><span style="font-size: 18px;">Yumurtalıq xərçənginin səbəbləri nələrdir?</span></strong></p>\n<p><strong><span style="font-size: 18px;">Yumurtalıq xərçənginin əlamətləri nələrdir?</span></strong></p>\n<p><strong><span style="font-size: 18px;">Yumurtalıq xərçəngi risk faktorları ?</span></strong></p>\n<p><strong><span style="font-size: 18px;"> Yumurtalıq xərçənginin diaqnozu necə qoyulur?</span></strong></p>\n<p><strong><span style="font-size: 18px;">Yumurtalıq xərçənginin müalicəsi necə aparılır?</span></strong></p>\n<p>&nbsp;</p>\n<p>&nbsp;</p>\n<h1><span style="font-size: 18px;">Yumurtalıq xərçəngi nədir?</span></h1>\n<p><span style="font-size: 14px;"><strong><span><img style="float: left;" src="/images/upload/image/yumurtaliq%20xercengi.jpg" alt="" width="300" height="203" /></span></strong>Ginekoloji xərçənglər arasında uşaqlıq boynu xərçəngindən sonra ikinci yerdə olan yumurtalıq xərçəngi erkən təyin olunmadıqda çox təəssüf ki, ürəkaçan nəticələr əldə edilməyən xərçəng növüdür. Əsasən postmenopauzal dövrdə daha çox rast gəlinən yumurtalıq xərçəngi lazımi müalicələr ilə erkən zamanlarda 80-90 faiz sağala bilən bir xərçəng növüdür. Ancaq gecikdirilmiş mərhələrdə isə sağalma şansı daha da azalır.</span></p>\n<p><span style="font-size: 14px;">Yumurtalıq toxumasında çox sayda fərqli hüceyrə yer alır. Yumurtalığın əsasını təşkil edən epitelyum hüceyrələrində ya da embriyonik dövrə aid hüceyrələrdə meydana gələn və baş verən nəzarətsiz bölünmə və çoxalma nəticəsində törəmə formalaşır. Bu ən çox epitelyum hüceyrələrdən qaynaqlanan törəmələrlə meydana çıxır.<br />Yumurtalıq xərçəngi yaranma səbəbi tam da bəlli olmayan bir xəstəlikdir. Çox təəssüf ki, pasiyentlərin 75 %-i gecikmiş mərhələlərdə həkimə müracət etdikləri üçün neqativ hallar daha çox yaşanır. Çünki gecikmiş mərhələlərdə müraciət etdikdə müalicənin də effektivliyi azalır. Ancaq bu o demək deyil ki, xəstələrin sağalma ehtimalı yoxdur. Qeyd edək ki, yumurtalıq xərçəngində yaş faktoru çox önəmlidir. Bu xəstəliyə daha çox postmenopauzal dövrdə rastlanır. ‼️Əziz xanımlar, əgər premenopauzal və ya postmenopauzal dövrdə hər hansı bir ginekjoloji narahatlığınız varsa, mütləq həkimə müraciət edin. Bu halda bədxassəli və ya xoşxassəli hər hansı bir şiş-tümör aşkarlandıqda mütləq bir onkoginekoloqun müayinəsində olun. Ümumiyyətlə yumurtalıq xərçəngi hər yaşda rast gəlinə bilən bir patalogiyadır. Həmçinin də sonsuzluqdan əziyyət çəkən xanımlarda hormonal müalicələr aldıqları üçün rastlanan hallardır.</span></p>\n<h1><span>Yumurtalıq xərçənginin əlamətləri nələrdir? <img style="margin: 10px; float: right;" src="/images/upload/image/yumurtal%C4%B1q%20x%C9%99rc%C9%99nginin%20elametleri.jpg" alt="" width="300" height="169" /></span></h1>\n<ul>\n<li>\n<p><span style="font-size: 16px;">Aybaşı pozğulmaları;</span></p>\n</li>\n<li>\n<p><span style="font-size: 16px;">Qarının alt hissəsində küt ağrılar;</span></p>\n</li>\n<li>\n<p><span style="font-size: 16px;">Qarında köpmə hissi;</span></p>\n</li>\n<li>\n<p><span style="font-size: 16px;">Qida qəbul etdikdə tez doyma;</span></p>\n</li>\n<li>\n<p><span style="font-size: 16px;">Ümumi halsızlıq;</span></p>\n</li>\n<li>\n<p><span style="font-size: 16px;">Ürəkbulanması;</span></p>\n</li>\n<li>\n<p><span style="font-size: 16px;">Sidik ifrazı aktının tez-tez olması;</span></p>\n</li>\n<li>\n<p><span style="font-size: 16px;">Sidik ifrazı zamanı göynəmə.</span></p>\n</li>\n</ul>\n<h1><span style="font-size: 14px;">Gecikmiş mərhələlərdə:</span></h1>\n<ul>\n<li>\n<p><span style="font-size: 16px;">Qarın həcminin böyüməsi</span></p>\n</li>\n<li>\n<p><span style="font-size: 16px;">Qarında güclü ağrılar; </span></p>\n</li>\n<li>\n<p><span style="font-size: 16px;">Səbəbsiz qaytarma halları;</span></p>\n</li>\n<li>\n<p><span style="font-size: 16px;">Bədən çəkisinin azalması.</span></p>\n</li>\n</ul>\n<p><br /><span style="font-size: 16px;">Dəyərli xanımlar, hər bir halda müayinə və müalicələri geciktirmədikdə sevindirici nəticələr əldə etmək mümkündür.</span></p>\n<h1><span style="font-size: 18px;">Yumurtalıq xərçənginin səbəbləri nələrdir?</span></h1>\n<ul>\n<li>\n<p><span style="font-size: 16px;">Tütün məmulatlarının qəbulu</span></p>\n</li>\n<li>\n<p><span style="font-size: 16px;">Xərçəng riskini artıran içkilərin qəbulu</span></p>\n</li>\n<li>\n<p><span style="font-size: 16px;">Sağlam qidalanmamaq</span></p>\n</li>\n<li>\n<p><span style="font-size: 16px;">Hamiləlikdən qorunmaq üçün istifadə edilən dərmanlar<br /><br /></span></p>\n</li>\n</ul>\n<h1><span style="font-size: 18px;">Yumurtalıq xərçəngi risk faktorları</span></h1>\n<p><span style="font-size: 14px;">Yumurtalıq xərçənginin risk qruplarını təyin etmək biraz çətin olsa da, təxmini olaraq yumurtalıq xərçənginimn yaranma səbəblərindən 5-10 faizi genetika ilə bağlıdır. Bu səbəbdən müayinə zamanı birinci dərəcəli qohumlarda süd vəzi xərçəngi, yumurtalıq xərçəngi, uşaqlıq xərçəngi olub-olmaması araşdırılır. Qeyd edək ki, bu cür qohumları olan sağlam qadınlar da yumurtalıq xərçəngi üçün risk qrupuna daxildirlər.</span></p>\n<h1><span style="font-size: 18px;"> Yumurtalıq xərçənginin diaqnozu necə qoyulur?</span></h1>\n<p><span style="font-size: 14px;"><img style="float: left; margin: 10px;" src="/images/upload/image/yumurtaliq%20xercenginin%20diaqnozu.jpg" alt="" width="300" height="162" /><br />Yumurtalıq xərçənginin erkən diaqnozu vacibdir. Daimi ginekoloji müayinə və qan testləri xəstəliyi aşkar etməyə kömək edir. Cərrahi müdaxilə və biopsiya ilə vaginal ultrasəs müayinəsində aşkar edilən kütlənin hansı quruluşa sahib olduğunu təyin edilə bilər.</span></p>\n<h1><span style="font-size: 18px;">Yumurtalıq xərçənginin müalicə metodları nələrdir?</span></h1>\n<p><span style="font-size: 14px;">Yumurtalıq xərçənginin müalicəsi əməliyyatdır. Əgər xərçəng hüceyrələri yalnız yumurtalıqdadırsa, bu bölgələrdən, qarının içinə yayılıbsa, bütün qarından nümunələr alınaraq <img style="float: right; margin: 10px;" src="/images/upload/image/yumurtal%C4%B1q_xercenginin_mualicesi.jpg" alt="" width="300" height="169" /> xərçəngli bölgələr təyin edilir. Təyin edilən xərçəngli kütlələr əməliyyatla çıxarılır və əməliyyatdan sonra kimyaterapiya prosedurları başlanılır. Əgər kütlənin cərrahi müdaxilə zamanı digər orqanlara zərər verə biləcəyi düşünülərsə, əməliyyatdan əvvək kimyaterapiya edilir. Bu müalicədə əsas məqsəd xərçəng hüceyrələrinin zəiflətmək və əməliyyat zamanı digər orqanlara zərər verməyəcək səviyyəyə gətirməkdir.</span></p>\n<p><span style="font-size: 14px;">Qarın içərisində olan bütün xərçəngli toxumaların çıxarılması olduqca vacibdir. Çünki daha onra həyata keçiriləcək kimyaterapiyada ancaq bu formada müsbət nəticələr əldə edilə bilər. Müalicənin bu formada həyata keçirilməsi xəstənin sağalmasına və yaşama şansının artmasına imkan yaradır. Əməliyyatdan sonra xərçəngin başqa orqanlara yayılıb yayılmaması ilə bağlı testlər aparılır. Əgər xərçəng digər orqanlara da yayılmayıbsa, kimpaterapiyaya ehtiyac olmaya bilər.</span></p>\n<p><span style="font-size: 14px;">Ancaq yayılıbsa, kimyaterapiya və ya radioterapiya nizamlı bir şəkildə həyata keçirilərək xəstəlik müalicə edilir. Bu müalicənin nə qədər vaxt aparacağı xəstəyə görə dəyişir. Əgər xəstəlik erkən dönəmlərdə aşkar edilibsə, xəstələrin sağalma şansı daha yüksəkdir.</span></p>\n<p>&nbsp;</p>\n<p><iframe allowFullScreen="allowFullScreen" src="http://www.youtube.com/embed/UCQjwCKKEdU" frameborder="0" width="425" height="350"></iframe></p>', 'usagliginmiomasi-1619544069.png', 9, 1),
(13, '', '', 'Vulva xərçəngi', '', '', 'Qadınlarda görülən xərçəng növləri arasında yer alan vulva xərçəngi, digər xərçəng növlərində də olduğu kimi erkən diaqnoz qoyulduqda müalicə olunabilir. Qadın genital bölgəsinin xarici səthi vulva adlanır. Vulva, klitoris də daxil olmaq üzrə üretra və vaginanın xarici hissəsini əhatə edən dəri təbəqəsidir.', '', '', '<div data-block="true" data-editor="8u2qi" data-offset-key="5qgm9-0-0">\n<div class="_1mf _1mj" data-offset-key="5qgm9-0-0">\n<h1 class="_1mf _1mj" data-offset-key="b18pc-0-0"><span style="font-size: 16px;" data-offset-key="b18pc-0-0">VULVA XƏRÇƏNGİNİN YARANMA SƏBƏBLƏRİ</span></h1>\n<h1 class="_1mf _1mj" data-offset-key="bnfia-0-0"><span style="font-size: 16px;" data-offset-key="bnfia-0-0">VULVA XƏRÇƏNGİNİN SİMPTOMLARI</span></h1>\n<h1 class="_1mf _1mj" data-offset-key="3c5uu-0-0"><span style="font-size: 16px;" data-offset-key="3c5uu-0-0">VULVA XƏRÇƏNGİNİN DİAQNOSTİKA METODLARI</span></h1>\n<div data-block="true" data-editor="8u2qi" data-offset-key="6re2j-0-0">\n<h1 class="_1mf _1mj" data-offset-key="6re2j-0-0"><span style="font-size: 16px;" data-offset-key="6re2j-0-0">VULVA XƏRÇƏNGİNİN MÜALİCƏSİ</span><br /><br /></h1>\n</div>\n<span style="font-size: 14px;" data-offset-key="5qgm9-0-0">Qadınlarda görülən xərçəng növləri arasında yer alan <a href="https://konulmardanova.az/az/xeber/vulva-xercengi-nedir-elametleri-nelerdir-31" target="_blank">vulva xərçəngi</a>, digər xərçəng növlərində də olduğu kimi erkən diaqnoz qoyulduqda müalicə olunabilir. Qadın genital bölgəsinin xarici səthi vulva adlanır. Vulva, klitoris də<img style="margin: 10px; float: right;" src="/images/upload/image/Vulva%20xercengi.jpg" alt="" width="400" height="209" /> daxil olmaq üzrə üretra və vaginanın xarici hissəsini əhatə edən dəri təbəqəsidir. </span></div>\n</div>\n<div data-block="true" data-editor="8u2qi" data-offset-key="15e2j-0-0">\n<div class="_1mf _1mj" data-offset-key="15e2j-0-0"><span style="font-size: 14px;" data-offset-key="15e2j-0-0">Vulva, quruluş etibarı ilə olduqca həssas bir bölgədir. Bu bölgə də bəzən səbəbsiz ağrılar meydana gələbilir hətta xərçəng halları müşahidə olunur. Bir çox qadın həyatlarının bir dövrü boyunca vulva ağrısı ilə qarşı qarşıya qalmışdır. Çoxu zaman adət dönəmlərində və ya cinsi münasibət zamanı ağrı görüləbilməktədir. Vulva ağrıları hərhansı bir səbəb yox ikən də ortaya çıxabilir və aylarca davam edə bilir. </span></div>\n</div>\n<div data-block="true" data-editor="8u2qi" data-offset-key="8vfal-0-0">\n<div class="_1mf _1mj" data-offset-key="8vfal-0-0"><span style="font-size: 14px;" data-offset-key="8vfal-0-0">Vulva vücudun digər bölümlərinə görə daha həssasdır. Bir çox qadının adət vaxtında yaşadığı ağrılar normal olaraq qəbul edilərkən, bu zaman xaricində də görülən sıx və şiddətli ağrılar üçün həkimə gedilməsi məsləhətdir.</span></div>\n</div>\n<div data-block="true" data-editor="8u2qi" data-offset-key="75ocd-0-0">\n<div class="_1mf _1mj" data-offset-key="75ocd-0-0"><span style="font-size: 14px;" data-offset-key="75ocd-0-0"><br data-text="true" /></span></div>\n</div>\n<div data-block="true" data-editor="8u2qi" data-offset-key="b18pc-0-0">\n<h2 class="_1mf _1mj" data-offset-key="b18pc-0-0"><span style="font-size: 18px;" data-offset-key="b18pc-0-0">VULVA XƏRÇƏNGİNİN YARANMA SƏBƏBLƏRİ</span></h2>\n</div>\n<div data-block="true" data-editor="8u2qi" data-offset-key="fv6jo-0-0">\n<div class="_1mf _1mj" data-offset-key="fv6jo-0-0"><span style="font-size: 14px;" data-offset-key="fv6jo-0-0">Vulva xərçənginin səbəbi hələ tam məlum deil. Vulva xərçəngi də bir çox xərçəng növü kimi, ümumiyyətlə hüceyrələrdəki mutasyonlara bağlı olaraq inkişaf edir.</span></div>\n</div>\n<div data-block="true" data-editor="8u2qi" data-offset-key="2kcu-0-0">\n<div class="_1mf _1mj" data-offset-key="2kcu-0-0"><span style="font-size: 14px;" data-offset-key="2kcu-0-0"><br data-text="true" /></span></div>\n</div>\n<div data-block="true" data-editor="8u2qi" data-offset-key="7vv6v-0-0">\n<div class="_1mf _1mj" data-offset-key="7vv6v-0-0"><span style="font-size: 14px;" data-offset-key="7vv6v-0-0">Xarici genital bölgə olaraq adlandırılan vulvada, şişlərdə ən sıx xarici dodaqlara yerləşməktədir.Vulva xərçənginə səbəb olan amillər tam olaraq bilinməsə də cinsi yolla yoluxan HPV virusunun səbəb olduğu düşünülməktədir. HPV nin cinsi yolla yoluxmasını nəzərə alaraq 11 və 12 yaş arasındakı uşaqlara HPV peyvəndi olunması tövsiyyə olunur.Vulva xərçənginə səbəb olabiləcəyi düşünülən risk faktırlar aşağıdakı kimi sıralanabilir.</span></div>\n</div>\n<div data-block="true" data-editor="8u2qi" data-offset-key="bafjr-0-0">\n<div class="_1mf _1mj" data-offset-key="bafjr-0-0"><span style="font-size: 14px;" data-offset-key="bafjr-0-0">- Qabaqcıl yaş</span></div>\n</div>\n<div data-block="true" data-editor="8u2qi" data-offset-key="57mhr-0-0">\n<div class="_1mf _1mj" data-offset-key="57mhr-0-0"><span style="font-size: 14px;" data-offset-key="57mhr-0-0">- HPV</span></div>\n</div>\n<div data-block="true" data-editor="8u2qi" data-offset-key="1trnr-0-0">\n<div class="_1mf _1mj" data-offset-key="1trnr-0-0"><span style="font-size: 14px;" data-offset-key="1trnr-0-0">- Siqaret istifadəsi</span></div>\n</div>\n<div data-block="true" data-editor="8u2qi" data-offset-key="4o06s-0-0">\n<div class="_1mf _1mj" data-offset-key="4o06s-0-0"><span style="font-size: 14px;" data-offset-key="4o06s-0-0">- HIV</span></div>\n</div>\n<div data-block="true" data-editor="8u2qi" data-offset-key="234g2-0-0">\n<div class="_1mf _1mj" data-offset-key="234g2-0-0"><span style="font-size: 14px;" data-offset-key="234g2-0-0">- Vulvada kimi dəri xəstəlikləri</span></div>\n</div>\n<div data-block="true" data-editor="8u2qi" data-offset-key="ff8en-0-0">\n<div class="_1mf _1mj" data-offset-key="ff8en-0-0"><span style="font-size: 14px;" data-offset-key="ff8en-0-0"><br data-text="true" /></span></div>\n</div>\n<div data-block="true" data-editor="8u2qi" data-offset-key="bnfia-0-0">\n<h2 class="_1mf _1mj" data-offset-key="bnfia-0-0"><span style="font-size: 18px;" data-offset-key="bnfia-0-0">VULVA XƏRÇƏNGİNİN SİMPTOMLARI</span></h2>\n</div>\n<div data-block="true" data-editor="8u2qi" data-offset-key="52nsa-0-0">\n<div class="_1mf _1mj" data-offset-key="52nsa-0-0"><span style="font-size: 14px;" data-offset-key="52nsa-0-0">Vulva xərçəngi özünü ilk mərhələdə bəlli etməsə də ilərləyən zamanda bəzi simptomlarla özünü göstərir.Şiddətli qanama xaricində ilk etbda özünü göstərməyən bu xəstəlik bir neçə il sonar özünü biruzə verir. Vulva xərçəngi, ümumiyyətlə qasıq bölgəsində uzun sürən qaşıntılar və sağalmayan yaralar sonrasında həkimə başvurulmasıyla ortaya çıxar.</span></div>\n</div>\n<div data-block="true" data-editor="8u2qi" data-offset-key="cba90-0-0">\n<div class="_1mf _1mj" data-offset-key="cba90-0-0"><span style="font-size: 14px;" data-offset-key="cba90-0-0">Vulva, bədənin xarici bölgəsində olmasına və görüləbilməsinə rəğmən gec diaqnoz qoyulan xərçəng növlərindən biridir.Burada qadınların bədənlərini yaxşı tanıması və özlərini müainə etmələri erkən diaqnoz baxımından önəmlidir.Bədənlərindəki şişlikləri, dəişiklikləri fərq edərək normal olmayan və ya qeyri &ndash;adi olan halları fərq edərək bir həkimə başvurmaq olduqca önəmlidir. Vulva xərçənginin simptomları aşağıdakı kimidir.</span></div>\n</div>\n<div data-block="true" data-editor="8u2qi" data-offset-key="51n5b-0-0">\n<div class="_1mf _1mj" data-offset-key="51n5b-0-0"><span style="font-size: 14px;" data-offset-key="51n5b-0-0">-Normal olmayan qanamalar</span></div>\n</div>\n<div data-block="true" data-editor="8u2qi" data-offset-key="9f7rg-0-0">\n<div class="_1mf _1mj" data-offset-key="9f7rg-0-0"><span style="font-size: 14px;" data-offset-key="9f7rg-0-0">-Xarici cinsiyyət orqanında qaşınma</span></div>\n</div>\n<div data-block="true" data-editor="8u2qi" data-offset-key="3f5rq-0-0">\n<div class="_1mf _1mj" data-offset-key="3f5rq-0-0"><span style="font-size: 14px;" data-offset-key="3f5rq-0-0">-dəri qaşınması</span></div>\n</div>\n<div data-block="true" data-editor="8u2qi" data-offset-key="8jl3e-0-0">\n<div class="_1mf _1mj" data-offset-key="8jl3e-0-0"><span style="font-size: 14px;" data-offset-key="8jl3e-0-0">-İdrar edərkən ağrı</span></div>\n</div>\n<div data-block="true" data-editor="8u2qi" data-offset-key="46i5d-0-0">\n<div class="_1mf _1mj" data-offset-key="46i5d-0-0"><span style="font-size: 14px;" data-offset-key="46i5d-0-0">-Cinsi münasibət zamanı ağrı</span></div>\n</div>\n<div data-block="true" data-editor="8u2qi" data-offset-key="ecmcs-0-0">\n<div class="_1mf _1mj" data-offset-key="ecmcs-0-0"><span style="font-size: 14px;" data-offset-key="ecmcs-0-0">-Qasıq ağrısı</span></div>\n</div>\n<div data-block="true" data-editor="8u2qi" data-offset-key="eoie8-0-0">\n<div class="_1mf _1mj" data-offset-key="eoie8-0-0"><span style="font-size: 14px;" data-offset-key="eoie8-0-0">-Sağalmayan yaralar</span></div>\n</div>\n<div data-block="true" data-editor="8u2qi" data-offset-key="egme7-0-0">\n<div class="_1mf _1mj" data-offset-key="egme7-0-0"><span style="font-size: 14px;" data-offset-key="egme7-0-0">-Qaşıntı</span></div>\n</div>\n<div data-block="true" data-editor="8u2qi" data-offset-key="94msh-0-0">\n<div class="_1mf _1mj" data-offset-key="94msh-0-0"><span style="font-size: 14px;" data-offset-key="94msh-0-0">-Xarici səthdə şişlik</span></div>\n</div>\n<div data-block="true" data-editor="8u2qi" data-offset-key="1of0-0-0">\n<div class="_1mf _1mj" data-offset-key="1of0-0-0"><span style="font-size: 14px;" data-offset-key="1of0-0-0">-Yanma</span></div>\n</div>\n<div data-block="true" data-editor="8u2qi" data-offset-key="eif1i-0-0">\n<div class="_1mf _1mj" data-offset-key="eif1i-0-0"><span style="font-size: 14px;" data-offset-key="eif1i-0-0">-Siğil</span></div>\n</div>\n<div data-block="true" data-editor="8u2qi" data-offset-key="c5pik-0-0">\n<div class="_1mf _1mj" data-offset-key="c5pik-0-0"><span style="font-size: 14px;" data-offset-key="c5pik-0-0">-Dəridə qalınlaşma</span></div>\n</div>\n<div data-block="true" data-editor="8u2qi" data-offset-key="3c5uu-0-0">\n<h2 class="_1mf _1mj" data-offset-key="3c5uu-0-0"><span style="font-size: 18px;" data-offset-key="3c5uu-0-0">VULVA XƏRÇƏNGİNİN DİAQNOSTİKA METODLARI</span></h2>\n<h2 class="_1mf _1mj" data-offset-key="3c5uu-0-0">&nbsp;</h2>\n</div>\n<div data-block="true" data-editor="8u2qi" data-offset-key="el22i-0-0">\n<div class="_1mf _1mj" data-offset-key="el22i-0-0"><span style="font-size: 14px;" data-offset-key="el22i-0-0">Vulva xərçəngi diaqnozunda öncəliklə xəstəyə fiziki müainə edilir və xəstə tarixi alınır.Daha sonra həkim tərəfindən biyopsi nümunəsi tələb oluna bilər.Vagina xarici səthindəki zədələnmiş toxumaların biopsy örnəkləri alınaraq incələməyə göndərilir.</span></div>\n</div>\n<div data-block="true" data-editor="8u2qi" data-offset-key="31ajr-0-0">\n<div class="_1mf _1mj" data-offset-key="31ajr-0-0"><span style="font-size: 14px;" data-offset-key="31ajr-0-0">Aşkar ediləcək şişlərin böyüklüyü və yayılma vəziyyəti haqqında məlumat sahibi olmaq üçün computer tomoqrafiyası,PET və MR kimi görüntüləmə üsullarıda istənəbilir.Yenə həkimin uyğun görməsi hesabında mesaneye baxılan sistoskopi və qalın bağırsağa baxılan proktoskopi kimi əməliyyatlar aparabilər.Ayrıca taam qan analizi ilə xəstədə HIV və ya HIP olub olmadığ araşdırılır.</span></div>\n</div>\n<div data-block="true" data-editor="8u2qi" data-offset-key="espoe-0-0">\n<div class="_1mf _1mj" data-offset-key="espoe-0-0"><span style="font-size: 14px;" data-offset-key="espoe-0-0"><br data-text="true" /></span></div>\n</div>\n<div data-block="true" data-editor="8u2qi" data-offset-key="6re2j-0-0">\n<h2 class="_1mf _1mj" data-offset-key="6re2j-0-0"><span style="font-size: 18px;" data-offset-key="6re2j-0-0">VULVA XƏRÇƏNGİNİN MÜALİCƏSİ</span></h2>\n</div>\n<div data-block="true" data-editor="8u2qi" data-offset-key="1bvlb-0-0">\n<div class="_1mf _1mj" data-offset-key="1bvlb-0-0"><span style="font-size: 14px;" data-offset-key="1bvlb-0-0">Hər xərçəng növündə olduğu kimi vulva xərçənginin müalicəsi də insanın yaşı,halı və xərçəngin mərhələsinə görə dəişiklik göstərir.Vulva xərçəngi cərrahi, radyoterapi və kemoterapi ilə ya da üçünün eyni vaxtda birləşməsi ilə müalicə edilə bilər.</span></div>\n</div>\n<div data-block="true" data-editor="8u2qi" data-offset-key="49elk-0-0">\n<div class="_1mf _1mj" data-offset-key="49elk-0-0"><strong><span style="font-size: 14px;" data-offset-key="49elk-0-0">CƏRRAHİ</span></strong></div>\n</div>\n<div data-block="true" data-editor="8u2qi" data-offset-key="db08v-0-0">\n<div class="_1mf _1mj" data-offset-key="db08v-0-0"><span style="font-size: 14px;" data-offset-key="db08v-0-0">Vulva xərçəngində cərrahi əməliyyat yayıldığı sahəyə və ölçüyə görə dəişilə bilər.Vulva cərrahisi xərçəngin yayılma mərhələsinə görə müəyyən bir bölgənin və ya bütün bölgənin ələ alınmasını əhatə edə bilər.Ümumiyyətlə çox ağır keçməyən bu cərrahi prosesdə xəstə bir neçə gün xəstəxana mühitində dincəldikdən sonra evə buraxılır.</span></div>\n</div>\n<div data-block="true" data-editor="8u2qi" data-offset-key="ep5de-0-0">\n<div class="_1mf _1mj" data-offset-key="ep5de-0-0"><strong><span style="font-size: 14px;" data-offset-key="ep5de-0-0">RADYOTERAPİ</span></strong></div>\n</div>\n<div data-block="true" data-editor="8u2qi" data-offset-key="eb3jd-0-0">\n<div class="_1mf _1mj" data-offset-key="eb3jd-0-0"><span style="font-size: 14px;" data-offset-key="eb3jd-0-0">Vulva xərçəngində radyoterapi müalicəsi tək başına ediləbiləcəyi kimi cərrahi prosedur öncəsində və sonrasında da edilir.Cərrahi öncəsində verilən radyoterapi xərçəngin kiçilməsini və əməliyyatın daha asan keçməsini sağlayır.Cərrahi sonrası isə, xərçəngli bölgəyə və ya yayılım göstərən bölgələrə radyoterapi tetbiq olunur.</span></div>\n</div>\n<div data-block="true" data-editor="8u2qi" data-offset-key="1gh7q-0-0">\n<div class="_1mf _1mj" data-offset-key="1gh7q-0-0"><strong><span style="font-size: 14px;" data-offset-key="1gh7q-0-0">KEMOTERAPİ</span></strong></div>\n</div>\n<div data-block="true" data-editor="8u2qi" data-offset-key="6ieml-0-0">\n<div class="_1mf _1mj" data-offset-key="6ieml-0-0"><span style="font-size: 14px;" data-offset-key="6ieml-0-0">Kemoterapi dermanlarıda iynə əməliyyatından əvvəl və sonrasında xəstənin vəziyyətini nəzərə alaraq müəyyən dozalar verilir.Ümumilikdə radyoterapi və cərrahi əməliyyatlar tək müalicə olunmayan hallarda istifadə olunur.Eyni zamanda ilk mərhələlərdə aşağı doza kemoterapiylə də müalicə üsulları tətbiq olunur.</span></div>\n</div>', 'usagliginmiomasi-1619544092.png', 10, 1),
(14, '', '', 'Bütün ginekoloji xəstəliklər', '', '', '', '', '', '', 'usagliginmiomasi-1619544428.png', 15, 1),
(15, '', '', 'Bartolin vəzi kistləri', '', '', '', '', '', '', 'usagliginmiomasi-1619544530.png', 16, 1),
(18, '', '', 'Uşaqlıq cismi xərçəngi ( endometrial xərçəg)', '', '', 'Endometrium uşaqlığın daxili səthini örtən, hər aybaşı zamanı bir qatı tökülərək yaşanabiləcək hamiləlik üçün yenidən hazırlanan və hamiləlik baş tutduğu zaman dölün inkişafını təmin edən ciftin tutunduğu orqandır. Bu orqandan yaranan xərçənglərə endometrial xərçəng(uşaqlıq cismi xərçəngi) deyilir.', '', '', '<h1 align="center"><span style="font-size: 18px;"><strong>UŞAQLIQ CİSMİ XƏRÇƏNGİ (ENDOMETRİAL XƏRÇƏNG)</strong></span></h1>\n<p><span style="font-size: 14px;">Endometrium uşaqlığın daxili səthini örtən, hər aybaşı zamanı bir qatı tökülərək yaşanabiləcək hamiləlik üçün yenidən hazırlanan və hamiləlik baş tutduğu zaman dölün inkişafını təmin edən ciftin tutunduğu orqandır. Bu orqandan yaranan xərçənglərə endometrial xərçəng(uşaqlıq cismi xərçəngi) deyilir.</span></p>\n<p>&nbsp;</p>\n<p><span style="font-size: 18px;"><strong>YARANMA SƏBƏBLƏRİ</strong></span></p>\n<p><span style="font-size: 14px;">Xərçəng xəstəliyi zamanı hüceyrələrin mutasiya etməsi ilə sağlam hüceyrələr anormal hüceyrələrə çevrilir. Sağlam hüceyrələr öz vəzifələrini icra etdikdən bir müddət sonra ölərək yerinə yeni sağlam hüceyrələrin gəlməsinə imkan verir.</span></p>\n<p><span style="font-size: 14px;">Anormal hüceyrələrdə isə vəziyyət tamamilə bədənin nəzarətindən çıxır. Anormal hüceyrələr böyüyür, çoxalır və müəyyən bir müddətdən sonra daha da çoxalaraq nəzarətdən çıxırlar.</span></p>\n<p><span style="font-size: 14px;">Qadın orqanının ən vacib iki hormonu olan progesteron və estrogen hormonlarındakı balanssızlıqlar endometriuma da təsir edərək orada dəyişikliklərə səbəb olur. Orqanizmdə progesteron və estrogen hormonlarında balanssızlığa yol açan və ya şəkər, polikistik yumurtalıq, aybaşı pozğunluğu, piylənmə və gec menopoz kimi hormon səviyyələrinə birbaşa təsir edə bilən amillər endometrial xərçəngə səbəb ola bilir.</span></p>\n<p><span style="font-size: 14px;">Bunlara əlavə olaraq endometrial xərçəngin meydana gəlməsində aşağıdakı amillər də təsir edir:</span></p>\n<p>&nbsp;</p>\n<ul>\n<li><span style="font-size: 14px;">12 yaşdan əvvəl aybaşı olmaq(menarş)</span></li>\n<li><span style="font-size: 14px;">Menstrual pozuntular</span></li>\n<li><span style="font-size: 14px;">Doğuş etməmək</span></li>\n<li><span style="font-size: 14px;">Piylənmə</span></li>\n<li><span style="font-size: 14px;">Hipertoniya</span></li>\n<li><span style="font-size: 14px;">Döş xərçəngi keçirənlər</span></li>\n<li><span style="font-size: 14px;">Yumurtalıq xərçəngi keçirənlər</span></li>\n<li><span style="font-size: 14px;">Mədə xərçəngi keçirənlər</span></li>\n<li><span style="font-size: 14px;">İncə bağırsaq xərçəngi keçirənlər</span></li>\n<li><span style="font-size: 14px;">Bağırsaq xərçəngi keçirənlər</span></li>\n<li><span style="font-size: 14px;">Dəri xərçəngi növlərindən birini keçirənlər</span></li>\n<li><span style="font-size: 14px;">Ailəsində xərçəng xəstəliyi olanlar</span></li>\n<li><span style="font-size: 14px;">Hepatobiliyer sistem (qaraciyər və ya öd kisəsi) xərçəngi olmaq</span></li>\n</ul>\n<p>&nbsp;</p>\n<p><span style="font-size: 14px;"><strong>ƏLAMƏTLƏR</strong></span></p>\n<p><span style="font-size: 14px;">Uşaqlıq cismi xərçəngi daha çox aybaşından əlavə və ya menopoz sonrası qanaxma ilə ortaya çıxır və erkən diaqnoz edildikdə müalicəyə cavab verir. Xüsusilə, menopozda olan qadınlar müayinələrini davamlı etdirməli və anormal qanaxmalar meydana gəldikdə bir mütəxəssis tərəfindən müayinə edilməlidirlər.</span></p>\n<p><span style="font-size: 14px;">Uşaqlıq cismi xərçənginin simptomları aşağıdakılardır:</span></p>\n<ul>\n<li><span style="font-size: 14px;">Menopozdan sonra vaginal qanaxma</span></li>\n<li><span style="font-size: 14px;">İki aybaşı arasında qanaxma</span></li>\n<li><span style="font-size: 14px;">Vaginadan anormal və ya qanlı axıntı gəlməsi</span></li>\n<li><span style="font-size: 14px;">Qasıq ağrısı</span></li>\n<li><span style="font-size: 14px;">Cinsi əlaqə zamanı ağrı</span></li>\n</ul>\n<p>&nbsp;</p>\n<p><span style="font-size: 14px;"><strong>DİAQNOSTİKA METODLARI</strong></span></p>\n<p><span style="font-size: 14px;">Uşaqlıq cismi xərçəngi erkən mərhələdə diaqnozu qoyula bilən xərçəng növüdür. Əsasən menstruasiyadan əlavə anormal qanaxma ilə özünü göstərir. Menstruasiyadan əlavə və ya menopozdan sonrakı qanaxmalar zamanı, qarının alt hissəsində ağrı zamanı və cinsi əlaqə zamanı ağrı olduğu hallarda qadınlar ginekoloq tərəfindən müayinə edilməlidir.</span></p>\n<p><span style="font-size: 14px;">Həkiminiz ailənizdə olmuş xəstəliklərlə birlikdə sizin xəstəlik tarixinizi də öyrənərək araşdıracaq, bunun nəticəsində sizdən aşağıdakı müayinələrdən birini və ya bir neçəsini tələb edə bilər:</span></p>\n<p><span style="font-size: 14px;">Endometrial xərçəngin diaqnozu zamanı xəstəyə toxumadan bir nümunə götürərək biopsiya üsulu tətbiq edilir. Endometrial xərçənglərdə istifadə olunan bəzi diaqnostik metodlar bunlardır:</span></p>\n<p>&nbsp;</p>\n<p><span style="font-size: 14px;"><strong>Ultrasonoqrafiya</strong></span></p>\n<p><span style="font-size: 14px;">Əsasən müayinənin bir hissəsi olaraq tətbiq olunan bu üsul zamanı vaginaya yerləşdirilən ultrasəs cihazı ilə uşaqlığın iç hissəsinə baxılır.</span></p>\n<p>&nbsp;</p>\n<p><span style="font-size: 14px;"><strong>Endometrial biopsiya</strong></span></p>\n<p><span style="font-size: 14px;">Uşaqlıq yolundan götürülmüş toxuma nümunəsidir. Bəzi xəstələrdə müayinə zamanı belə biopsiya edilməsi uyğundur.</span></p>\n<p>&nbsp;</p>\n<p><span style="font-size: 14px;"><strong>Histeroskopiya</strong></span></p>\n<p><span style="font-size: 14px;">Vaginal yolla uşaqlığın daxilinə kamera yerləşdirilərək edilən müayinə metodudur. Bu prosedur zamanı da biopsiya edilə bilər.</span></p>\n<p>&nbsp;</p>\n<p><span style="font-size: 14px;"><strong>CA-125</strong></span></p>\n<p><span style="font-size: 14px;">Endometrial xərçəngin diaqnozu ilə yanaşı müalicə zamanı nəticəni qiymətləndirmək üçün də istifadə edilən qan testidir.</span></p>\n<p>&nbsp;</p>\n<p><span style="font-size: 14px;"><strong>MÜALİCƏ ÜSULLARI</strong></span></p>\n<p><span style="font-size: 14px;">Uşaqlıq cismi xərçəngləri cərrahi, radioterapiya, kimyaterapiya və hormon terapiyası kimi fərqli müalicə üsullarından istifadə edilərək həyata keçirilir.</span></p>\n<p>&nbsp;</p>\n<p><span style="font-size: 14px;"><strong>Cərrahi müalicə</strong></span></p>\n<p><span style="font-size: 14px;">Cərrahi müalicə endometrial xərçəng müalicəsinin əsasını təşkil edir. Açıq şəkildə aparıldığı kimi laparoskopik üsulla qapalı şəkildə də aparıla bilən cərrahi üsul uşaqlığın çıxarılmasından qarın membranından biopsiya alınmasına qədər dəyişik şəkildə edilə bilər.</span></p>\n<p>&nbsp;</p>\n<p><span style="font-size: 14px;"><strong>Radioterapiya</strong></span></p>\n<p><span style="font-size: 14px;">Əməliyyatdan əvvəl şişin kiçildilməsi üçün, əməliyyatdan sonra və ya əməliyyatın həyata keçirilə bilmədiyi və xərçəngin yayıldığı hallarda kütlələri azaltmaq üçün istifadə edilən bir müalicə növüdür.</span></p>\n<p>&nbsp;</p>\n<p><span style="font-size: 14px;"><strong>Kimyaterapiya</strong></span></p>\n<p><span style="font-size: 14px;">Əməliyyatı dəstəkləmək üçün və ya cərrahi üsulun həyata keçirilə bilmədiyi və xərçəngin yayıldığı hallarda istifadə edilən bir müalicə növüdür. Eyni zamanda xəstəyə tətbiq olunan ilk müalicədən sonra xəstəliyin yayılmasının qarşısını alır.</span></p>\n<p>&nbsp;</p>\n<p><span style="font-size: 14px;"><strong>Hormonal Terapiya</strong></span></p>\n<p><span style="font-size: 14px;">Müayinələr nəticəsində hormon reseptorları (sensorları) tapılan şişlər üçün istifadə edilə bilən bir müalicə üsuludur.<strong></strong></span></p>', 'usagliginmiomasi-1622234673.png', 6, 1);



-- ---------------------------------------------------------
--
-- Table structure for table : `settings`
--
-- ---------------------------------------------------------

CREATE TABLE `settings` (
  `id` tinyint(4) NOT NULL AUTO_INCREMENT,
  `admin_name` varchar(255) NOT NULL,
  `title_` varchar(255) NOT NULL,
  `keywords_` varchar(255) NOT NULL,
  `description_` varchar(255) NOT NULL,
  `currency` tinyint(1) NOT NULL,
  `wheather` tinyint(1) NOT NULL,
  `namaz` tinyint(1) NOT NULL,
  `admin_with_role` tinyint(1) NOT NULL,
  `include_site_langs` tinyint(1) NOT NULL,
  `want_license_pass_change` tinyint(1) NOT NULL,
  `image_logo` varchar(255) NOT NULL,
  `image_fav` varchar(255) NOT NULL,
  `default_page` varchar(50) NOT NULL,
  `image_crop` tinyint(1) NOT NULL,
  `license_key` varchar(255) NOT NULL,
  `last_backup` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `admin_name`, `title_`, `keywords_`, `description_`, `currency`, `wheather`, `namaz`, `admin_with_role`, `include_site_langs`, `want_license_pass_change`, `image_logo`, `image_fav`, `default_page`, `image_crop`, `license_key`, `last_backup`) VALUES
(1, 'Admin Panel', 'Elite Admin', '', '', 0, 0, 0, 0, 0, 0, 'edik-1515503844.png', 'favicon-1515568701.png', 'menus', 0, '1e176f4648643465b4363c95561e0bba', 1635529955);



-- ---------------------------------------------------------
--
-- Table structure for table : `settings_inner`
--
-- ---------------------------------------------------------

CREATE TABLE `settings_inner` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `table_name` varchar(50) NOT NULL,
  `parent_id_available` tinyint(1) NOT NULL,
  `position_available` tinyint(1) NOT NULL,
  `position_desc` tinyint(1) NOT NULL COMMENT '0=>asc, 1=>desc',
  `position_depends_parent_id` tinyint(1) NOT NULL,
  `multiselect_available` tinyint(1) NOT NULL,
  `active_available` tinyint(1) NOT NULL,
  `edit_available` tinyint(1) NOT NULL,
  `delete_available` tinyint(1) NOT NULL,
  `show_per_page_available` tinyint(1) NOT NULL,
  `print_available` tinyint(1) NOT NULL,
  `add_new_available` tinyint(1) NOT NULL,
  `paginator_available` tinyint(1) NOT NULL,
  `category_available` tinyint(1) NOT NULL,
  `upload_important` tinyint(1) NOT NULL,
  `show_datacount` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=170 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `settings_inner`
--

INSERT INTO `settings_inner` (`id`, `table_name`, `parent_id_available`, `position_available`, `position_desc`, `position_depends_parent_id`, `multiselect_available`, `active_available`, `edit_available`, `delete_available`, `show_per_page_available`, `print_available`, `add_new_available`, `paginator_available`, `category_available`, `upload_important`, `show_datacount`) VALUES
(81, 'employees', 0, 1, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1),
(73, 'videogallery', 0, 1, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1),
(74, 'users', 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1),
(152, 'cash_desks', 0, 1, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1),
(76, 'admins', 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 1),
(77, 'contacts', 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0),
(78, 'sliders', 0, 1, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1),
(79, 'banners', 0, 1, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1),
(80, 'partners', 0, 1, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1),
(137, 'banks', 0, 1, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1),
(63, 'home_page', 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0),
(64, 'description', 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0),
(65, 'subscribers', 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1),
(66, 'menus', 1, 1, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1),
(67, 'categories', 0, 1, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1),
(68, 'news', 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1),
(69, 'faq_categories', 0, 1, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1),
(70, 'faq', 0, 1, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1),
(71, 'about', 0, 0, 0, 0, 1, 0, 1, 1, 0, 1, 0, 0, 0, 0, 0),
(72, 'photo_albums', 0, 1, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1),
(82, 'services', 0, 1, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1),
(83, 'links', 0, 1, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1),
(84, 'authors', 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1),
(85, 'fb_admins', 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 1),
(92, 'documents', 0, 1, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1),
(87, 'letters', 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 1),
(88, 'comments', 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1),
(89, 'questions', 0, 1, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1),
(90, 'langs', 0, 1, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1),
(153, 'our_cash_desks', 0, 1, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1),
(139, 'admin_roles', 0, 1, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1),
(138, 'settings_inner', 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 1),
(140, 'settings', 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 1),
(147, 'image_cropper', 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0),
(148, 'photo_albums_gallery', 1, 1, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1),
(151, 'index', 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 1),
(154, 'payments', 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 1),
(155, 'money_balance', 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 1),
(156, 'user_programs', 1, 0, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1),
(157, 'workers', 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 1),
(158, 'news_gallery', 1, 1, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1),
(159, 'countries', 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 1),
(160, 'products', 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1),
(161, 'categories2', 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 1),
(162, 'products2', 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1),
(163, 'patients', 0, 1, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1),
(164, 'methods', 0, 1, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1),
(165, 'users_contact', 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 1),
(166, 'appointment', 0, 0, 0, 0, 1, 0, 1, 1, 1, 1, 0, 1, 0, 0, 1),
(169, 'appointment_users', 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 1);



-- ---------------------------------------------------------
--
-- Table structure for table : `sliders`
--
-- ---------------------------------------------------------

CREATE TABLE `sliders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name_en` varchar(255) NOT NULL,
  `name_ru` varchar(255) NOT NULL,
  `name_az` varchar(255) NOT NULL,
  `title_en` varchar(250) NOT NULL,
  `title_ru` varchar(250) NOT NULL,
  `title_az` varchar(250) NOT NULL,
  `text_en` text NOT NULL,
  `text_ru` text NOT NULL,
  `text_az` text NOT NULL,
  `image` varchar(255) NOT NULL DEFAULT '0',
  `url` varchar(255) NOT NULL,
  `target` varchar(255) NOT NULL,
  `position` int(11) NOT NULL,
  `active` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `sliders`
--

INSERT INTO `sliders` (`id`, `name_en`, `name_ru`, `name_az`, `title_en`, `title_ru`, `title_az`, `text_en`, `text_ru`, `text_az`, `image`, `url`, `target`, `position`, `active`) VALUES
(1, '', 'Medical & Health Tips Solutions ru', 'Onkoginekoloq Könül Mərdanova', '', '', '', '', 'We are a professional health & medical care services provider institutions. 25 years serve every kinds of people very carefully & Patient happy ru', 'Hər kəs bilsin, həyat davam etsin!', 'onkoginekoloqkonulmardanova-1619890406.jpg', 'https://www.youtube.com/watch?v=4ChVuRXcgkc', '', 1, 1),
(3, '', 'wqeqwe', 'Könül   Mərdanova', '', '', '', '', 'wqewqewqewq', 'Onkoloq-ginekoloq', 'onkoloqginekolokkonul-1-1619035603.png', 'https://www.youtube.com/watch?v=4ChVuRXcgkc', '', 2, 1);



-- ---------------------------------------------------------
--
-- Table structure for table : `subscribers`
--
-- ---------------------------------------------------------

CREATE TABLE `subscribers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `email` varchar(255) NOT NULL,
  `active` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;



-- ---------------------------------------------------------
--
-- Table structure for table : `user_programs`
--
-- ---------------------------------------------------------

CREATE TABLE `user_programs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `login` varchar(50) NOT NULL,
  `pass` varchar(50) NOT NULL,
  `email` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `mobile` varchar(255) NOT NULL,
  `role_id` int(11) NOT NULL,
  `permissions` text NOT NULL,
  `settings` varchar(500) NOT NULL,
  `full_list_access` varchar(500) NOT NULL,
  `price` int(11) NOT NULL,
  `expire_time` int(11) NOT NULL,
  `active` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;



-- ---------------------------------------------------------
--
-- Table structure for table : `users`
--
-- ---------------------------------------------------------

CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `login` varchar(50) NOT NULL,
  `pass` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `about` varchar(255) NOT NULL,
  `gender` tinyint(1) NOT NULL COMMENT '0=>female, 1=>male',
  `mobile` varchar(50) NOT NULL,
  `create_date` int(11) NOT NULL,
  `birthday` int(11) NOT NULL,
  `last_visit` int(11) NOT NULL,
  `ip` varchar(15) NOT NULL,
  `image` varchar(255) NOT NULL,
  `activation` tinyint(1) NOT NULL COMMENT 'for email activation',
  `active` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `login`, `pass`, `email`, `about`, `gender`, `mobile`, `create_date`, `birthday`, `last_visit`, `ip`, `image`, `activation`, `active`) VALUES
(2, 'Elnur Alizade', 'Develop', '14e1b600b1fd579f47433b88e8d85291', 'elnur-sun17@mail.ru', 'test', 1, '050 443 00 50', 1357331929, -14400, 0, '', '', 1, 1);



-- ---------------------------------------------------------
--
-- Table structure for table : `videogallery`
--
-- ---------------------------------------------------------

CREATE TABLE `videogallery` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name_en` varchar(255) NOT NULL,
  `name_ru` varchar(255) NOT NULL,
  `name_az` varchar(255) NOT NULL,
  `title_en` varchar(255) NOT NULL,
  `title_ru` varchar(255) NOT NULL,
  `title_az` varchar(255) NOT NULL,
  `video_url` varchar(255) NOT NULL,
  `position` int(11) NOT NULL,
  `active` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=31 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `videogallery`
--

INSERT INTO `videogallery` (`id`, `name_en`, `name_ru`, `name_az`, `title_en`, `title_ru`, `title_az`, `video_url`, `position`, `active`) VALUES
(24, '', '', 'Onkoginekoloq Dr. Könül Mərdanova', '', '', 'Sentyabr Ginekoloji xərçənglər haqqında maariflərdirmə ayı kimi - Onkoginekoloq Könül Mərdanova', 'https://www.youtube.com/watch?v=KEjXMjSau-Q&t=315s', 14, 1),
(25, '', '', 'Onkoginekoloq Dr. Könül Mərdanova', '', '', 'Uşaqlıq boynunda eroziya', 'https://www.youtube.com/watch?v=-3svJbJhcj0', 15, 1),
(26, '', '', 'Onkoginekoloq Dr. Könül Mərdanova', '', '', 'Şəkər xəstələri ginekoloji xərçənglərin risk qruplarına daxildirlərmi?', 'https://www.youtube.com/watch?v=u2XF6tWytec&t=4s', 16, 1),
(22, '', '', 'Onkoginekoloq Dr. Könül Mərdanova', '', '', 'Milli Onkologiya Mərkəzinin Ginekologiya bölməsində gündəlik iş prosesi', 'https://www.youtube.com/watch?v=Qeir4NvoqZU', 12, 0),
(23, '', '', 'Onkoginekoloq Dr. Könül Mərdanova', '', '', 'Milli Onkologiya Mərkəzi - Ginekologiya bölməsi', 'https://www.youtube.com/watch?v=IMRSO1BNYKA', 13, 1),
(3, '', 'Износ хряща тазобедренного сустава', 'Onkoginekoloq Dr. Könül Mərdanova', '', 'Отзыв Ирады ханум, страдающей от износа хряща тазобедренного сустава, о стволовых клетках', 'Onkoginekoloq Dr. Könül Mərdanova', 'https://www.youtube.com/watch?v=4ChVuRXcgkc', 6, 1),
(20, '', '', 'Onkoginekoloq Dr. Könül Mərdanova', '', '', 'Uşaqlığın patoloji qanaxmaları - Onkoginekoloq Dr. Könül Mərdanova', 'https://www.youtube.com/watch?v=inBPSawvjYg&t=1s', 10, 1),
(21, '', '', 'Onkoginekoloq Dr. Könül Mərdanova', '', '', 'Uşaqlıq boynunun xoşxassəli patologiyaları nələrdir?', 'https://www.youtube.com/watch?v=UXqHEPALoYc&t=18s', 11, 1),
(17, '', '', 'Onkoginekoloq Dr. Könül Mərdanova', '', '', 'Histeroskopiya polipektomiya əməliyyatı', 'https://www.youtube.com/watch?v=-j8tux8qZ_I', 7, 1),
(18, '', '', 'Onkoginekoloq Dr. Könül Mərdanova', '', '', 'ONKOGINEKOLOQA NƏ VAXT MÜRACİƏT EDİLMƏLİDİR? - Onkoloq Dr. Könül Mərdanova', 'https://www.youtube.com/watch?v=uCAGJRS3Tt4', 8, 0),
(19, '', '', 'Onkoginekoloq Dr. Könül Mərdanova', '', '', 'Histeroskopiya müayinəsi nədir? Hansı hallarda histeroskopiya müayinəsi həyata keçirilir?', 'https://www.youtube.com/watch?v=CqMK4gTRC4w', 9, 1),
(11, '', 'Процедура с применением стволовых клеток', 'Onkoginekoloq Dr. Könül Mərdanova', '', 'Отзыв Тамары ханум, пациентки получившей пользу от процедур с применением стволовых клеток', 'Pap smear testi nədir?', 'https://www.youtube.com/watch?v=MIHgInNRKHc', 1, 1),
(12, '', 'Диагностический фаcетный блок', 'Onkoginekoloq Dr. Könül Mərdanova', '', 'Отзыв пациента, страдающего болями в области головы и шеи, после процедуры', 'Uşaqlıq boynunun xoşxassəli xəstəlikləri zamanı nələrə diqqət etməliyik?', 'https://www.youtube.com/watch?v=PMgv_o-Lh_I', 2, 1),
(13, '', 'Эпидуральный катетер с перманентной помпой (туннельный эпидуральный катетер)', 'Onkoginekoloq Dr. Könül Mərdanova', '', 'Отзыв пациента, страдающего от раковых болей, после процедуры', 'Yumurtalıq xərçənginin əlamətləri və müayinə metodları', 'https://www.youtube.com/watch?v=UCQjwCKKEdU', 3, 1),
(15, '', '', 'Onkoginekoloq Dr. Könül Mərdanova', '', '', 'Kolposkopiya nədir? Kolposkopiya Ginekoloji müayinələrdə nə üçün vacibdir?', 'https://www.youtube.com/watch?v=GzDryYioDaE&t=5s', 4, 1),
(16, '', '', 'Onkoginekoloq Dr. Könül Mərdanova', '', '', 'Onkoginekoloq Dr. Könül Mərdanova', 'https://www.youtube.com/watch?v=4ChVuRXcgkc', 5, 1),
(27, '', '', 'Onkoginekoloq Dr. Könül Mərdanova', '', '', 'Onkoloji xəstəlik şübhəsi zamanı kolposkopiya müayinəsi', 'https://www.youtube.com/watch?v=tdpPJR2oEHg', 17, 1),
(28, '', '', 'Onkoginekoloq Dr. Könül Mərdanova', '', '', 'Onkoginekoloji xəstəlik səbəbilə vaxtında həkimə müraciət edərək sağalan xəstəmiz', 'https://www.youtube.com/watch?v=_okz_LWlVeA&t=39s', 18, 1),
(29, '', '', 'Onkoginekoloq Dr. Könül Mərdanova', '', '', 'Uşaqlıq boynunun xərçəngi -Milli Onkologiya Mərkəzinin Onkoginekoloqu Könül Mərdanova', 'https://www.youtube.com/watch?v=my9laZzEYbw', 19, 0),
(30, '', '', 'Onkoginekoloq Dr. Könül Mərdanova', '', '', 'Uşaqlıq boynunun bədxassəli törəmələri', 'https://www.youtube.com/watch?v=IhFFYyEz54g', 20, 1);



-- ---------------------------------------------------------
--
-- Table structure for table : `videogallery_1`
--
-- ---------------------------------------------------------

CREATE TABLE `videogallery_1` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name_en` varchar(255) NOT NULL,
  `name_ru` varchar(255) NOT NULL,
  `name_az` varchar(255) NOT NULL,
  `video_url` varchar(255) NOT NULL,
  `position` int(11) NOT NULL,
  `active` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=37 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `videogallery_1`
--

INSERT INTO `videogallery_1` (`id`, `name_en`, `name_ru`, `name_az`, `video_url`, `position`, `active`) VALUES
(36, '', '', 'Kolposkopiya nədir? Kolposkopiya Ginekoloji müayinələrdə nə üçün vacibdir?', 'https://www.youtube.com/watch?v=GzDryYioDaE', 5, 1),
(35, '', '', 'YUMURTALIQ XƏRÇƏNGİNİN ƏLAMƏTLƏRİ VƏ MÜAYİNƏ METODLARI - ONKLOGİNEKOLOQ DR. KÖNÜL MARDANOVA', 'https://www.youtube.com/watch?v=UCQjwCKKEdU', 4, 1),
(32, '', '', 'Onkoginekoloq Könül Mərdanova - tanıtım çarxı', 'https://www.youtube.com/watch?v=4ChVuRXcgkc', 1, 1),
(33, '', '', 'Pap Smear testi nədir, kimlərə Pap test edilə bilər ? - Onkoginekoloq Könül Mərdanova', 'https://www.youtube.com/watch?v=MIHgInNRKHc&t=3s', 2, 1),
(34, '', '', 'UŞAQLIQ BOYNUNUN XOŞXASSƏLİ XƏSTƏLİKLƏRİ ZAMANI NƏLƏRƏ DİQQƏT ETMƏLİYİK?', 'https://www.youtube.com/watch?v=PMgv_o-Lh_I', 3, 1);



-- ---------------------------------------------------------
--
-- Table structure for table : `wheather`
--
-- ---------------------------------------------------------

CREATE TABLE `wheather` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `baki` varchar(255) NOT NULL,
  `naxcivan` varchar(255) NOT NULL,
  `sumqayit` varchar(255) NOT NULL,
  `gence` varchar(255) NOT NULL,
  `lenkeran` varchar(255) NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `wheather`
--

INSERT INTO `wheather` (`id`, `baki`, `naxcivan`, `sumqayit`, `gence`, `lenkeran`, `date`) VALUES
(1, '28```18', '0-0', '0-0', '', '', '2015-09-01');


/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;